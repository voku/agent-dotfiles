from pathlib import Path
import subprocess,json,hashlib,time
repo=Path('/workspace/agent-dotfiles');root=Path('/workspace/scratch/dotfiles-experiments');prefix=root/'pinned-shell-1e6e69b';sha='1e6e69bbf4bb0342acc4a42bca54cb00b418cb8d';records=[]
def run(a):
 t=time.monotonic();p=subprocess.run(a,cwd=repo,capture_output=True,text=True);records.append({'argv':a,'exit':p.returncode,'seconds':time.monotonic()-t,'stdout':p.stdout,'stderr':p.stderr});(root/'merged-cold-shell.json').write_text(json.dumps({'source':sha,'records':records},indent=2));assert p.returncode==0,p.stdout+p.stderr;return p.stdout
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==sha
run([str(repo/'install.sh'),'--prefix',str(prefix),'--revision',sha]);run([str(repo/'install.sh'),'verify','--prefix',str(prefix),'--revision',sha]);doctor=json.loads(run([str(prefix/'bin/agent-dotfiles'),'doctor','--strict']));assert doctor['version']=='0.4.0'
source=root/'loop-current';path='src/Init/InitToolsCommand.php';raw=(source/path).read_bytes();parts=raw.split(b'\n');lines=[p+b'\n' for p in parts[:-1]]+([parts[-1]] if parts[-1] else [])
for shell,flags,profile in [('bash',['--noprofile','--norc'],'.bashrc'),('zsh',['-f'],'.zshrc')]:
 result=json.loads(run(['env','-u','BASH_ENV','-u','ZDOTDIR',shell,*flags,'-c','. "$1/$3" || exit $?; agent_read src/Init/InitToolsCommand.php --root "$2" --start 14 --end 40 || exit $?; agent_deactivate || exit $?; ! typeset -f agent_read >/dev/null','consumer',str(prefix),str(source),profile]));assert result['sha256']==hashlib.sha256(raw).hexdigest();assert result['content'].encode()==b''.join(lines[13:40]);assert result['content_bytes']==len(result['content'].encode());assert not result['truncated']
run([str(repo/'install.sh'),'verify','--prefix',str(prefix),'--revision',sha])
print('Merged exact-pin Bash/Zsh source/hash/doctor/deactivation PASS; isolated prefix retained for explicit fresh-shell usage.')
