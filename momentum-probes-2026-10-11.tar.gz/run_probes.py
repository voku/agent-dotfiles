from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path('/workspace/scratch/dotfiles-experiments');source=root/'loop-current';records=[]
env=os.environ.copy();env['PATH']='/workspace/.cloud-setup/bin:'+env['PATH'];env['PHPRC']='/workspace/.cloud-setup/php.ini';env.pop('CODEX_HOME',None)
cli=['/workspace/.cloud-setup/bin/php',str(source/'bin/agent-loop')]
def run(label,args,cwd):
 start=time.monotonic();p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True);record={'label':label,'argv':args,'cwd':str(cwd),'exit':p.returncode,'seconds':time.monotonic()-start,'stdout':p.stdout,'stderr':p.stderr};records.append(record);(root/'probe-receipts.json').write_text(json.dumps(records,indent=2));print(label,p.returncode,round(record['seconds'],3),flush=True);return p
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert sha=='fad403a209d7d9f4438bf7036ce962780f44938c'
for name in ['fresh-project','fresh project with spaces','fresh-Δ-project']:
 p=root/name;p.mkdir(exist_ok=False)
 for label,args in [('scaffold',['init','scaffold']),('learning-empty',['learn','validate','--root','.agent-loop/learning']),('first-capture',['learn','finding-capture','--task','TASK-1501','--by','codex','--observation','Isolated bootstrap probe, not a production Finding','--hypothesis','Scaffold creates owner-recognized zero-record storage','--evidence','Source '+sha]),('learning-one',['learn','validate','--root','.agent-loop/learning'])]:
  r=run(name+':'+label,cli+args,p);assert r.returncode==0, r.stdout+r.stderr
 r=run(name+':scaffold-repeat',cli+['init','scaffold'],p);assert r.returncode==0
run('scaffold-owner-regressions',['/workspace/.cloud-setup/bin/php',str(source/'vendor/bin/phpunit'),str(source/'tests/InitScaffoldOwnerBoundaryTest.php')],source)
run('preplan-without-map',cli+['enter','DOGFOOD-637','--format=json'],source)
r=run('fresh-real-PHP-map',cli+['map','build','--root','.','--paths','src,tests','--out','.agent-loop/map/php-symbols.json'],source);assert r.returncode==0,r.stderr
run('map-staleness-owner',cli+['map','stale','--index','.agent-loop/map/php-symbols.json'],source)
run('preplan-with-fresh-map',cli+['enter','DOGFOOD-637','--format=json'],source)
run('owner-structural-context',cli+['map','context',r'voku\AgentLoop\Init\InitScaffoldCommand::run','--index','.agent-loop/map/php-symbols.json','--format=json','--max-files','8','--max-callers','5','--max-callees','5','--max-tests','5'],source)
(root/'probe-runtime.json').write_text(json.dumps({'loop_source':sha,'lock_sha256':hashlib.sha256((source/'composer.lock').read_bytes()).hexdigest(),'installed_dependencies_sha256':hashlib.sha256((source/'vendor/composer/installed.json').read_bytes()).hexdigest(),'benchmark_runtime_replaced':False,'model_tokens':None,'fixtures':'three explicitly isolated fresh project directories, candidate Findings remain unverified; no active guidance promotion'},indent=2))
