# Validation Plan

## Required Validation

### Task Validation

```bash
python3 -m unittest discover -s tests -v
```

```bash
python3 -m compileall -q agent_dotfiles bin tests tools
```

```bash
/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict
```
