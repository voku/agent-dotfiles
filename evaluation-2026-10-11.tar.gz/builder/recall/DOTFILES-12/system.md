# L2 Meta-Prompt Briefing for Task: DOTFILES-12
> Recall bundle SHA-256: 0b4d3f8f64b2741059ce045ec893e157c79b1c9cbb4799e15fcf4e59db6c6962

## Task Description
Execute independent governed native/CLI/profile maintenance comparisons and second fresh held-out consumers; improve the agent shell environment only from validated findings, preserving optionality and exact evidence.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `agent_dotfiles`
- File/path: `tests`
- File/path: `docs`
- File/path: `.github/workflows`
- Scope: `agent_dotfiles`
- Scope: `tests`
- Scope: `docs`
- Scope: `.github/workflows`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Record frozen runtimes, task manifests and private independent oracles; complete first and second fresh three-way consumer maintenance runs with independent validation and honest metrics/limitations.
- Implement the smallest measured shell/context improvement through governed Learning, independent review and exact-commit GitHub Actions; demonstrate cold pinned consumption and safe rollback without changing running tools.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No mandatory default activation, global installation/PATH/Git changes, synthetic PHP lookup substituted for real maintenance, fabricated telemetry, or injected defect on production main.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2