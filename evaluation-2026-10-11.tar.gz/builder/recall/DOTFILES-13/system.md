# L2 Meta-Prompt Briefing for Task: DOTFILES-13
> Recall bundle SHA-256: dcd4be10ef998c72d1c7cbfe7da885f1f24298d21f778547636dc3a4a6167c48

## Task Description
Complete approved agent-shell evaluation with correctly scoped governance, retain only validated shell and regression improvements, publish reviewable evidence and independently validated pinned release.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `agent_dotfiles`
- File/path: `tests`
- File/path: `docs`
- File/path: `.github/workflows`
- File/path: `README.md`
- File/path: `CHANGELOG.md`
- File/path: `install.sh`
- File/path: `.bashrc`
- File/path: `.zshrc`
- File/path: `.shellrc`
- File/path: `.functions`
- File/path: `.exports`
- File/path: `tools`
- Scope: `agent_dotfiles`
- Scope: `tests`
- Scope: `docs`
- Scope: `.github/workflows`
- Scope: `README.md`
- Scope: `CHANGELOG.md`
- Scope: `install.sh`
- Scope: `.bashrc`
- Scope: `.zshrc`
- Scope: `.shellrc`
- Scope: `.functions`
- Scope: `.exports`
- Scope: `tools`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Complete fresh held-out native/CLI/profile repairs with independent oracles; disclose all setup/scope failures, quality outcomes, unavailable telemetry and confounded timings.
- Independent final review, exact-commit GitHub Python/Bashunit/shell and focused mutation checks, cold pinned install/doctor/profile/deactivation/uninstall/rollback evidence and resumable owner learning.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No global environment changes, installed consumer tool replacement, injected production defect, fabricated scope approval or claimed productivity benefit without evidence.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2