# L2 blind-spot analysis prompt for DOTFILES-13

## Presentation

Write the final review in language en. Translate explanatory headings and prose; preserve exact source text, identifiers, paths, citations, and required machine-readable status tokens.

## First-draft falsification lens

Treat the current implementation as a first draft, even if produced by you or paired with a confident rationale.

Review for falsification rather than confirmation. Try to prove concrete failures against requirements, acceptance criteria, constraints, non-goals, current source, tests, static analysis, and safe runtime evidence.

Acceptance criteria are required outcomes, not evidence they are satisfied. Prior reasoning, model confidence, reviewer consensus, prompt construction, and unexecuted commands are not verification.

Treat every LLM-produced statement as a candidate claim, not repository truth. Re-ground material claims against current authoritative artifacts or deterministic evidence before acting. A detailed patch is not evidence that the described classes, boundaries, bugs, or metrics actually exist. If model output conflicts with current authoritative artifacts, the artifacts win. Reproduce a finding before fixing it. Review findings are investigation candidates, not instructions to modify code.

Classify material conclusions as VERIFIED, INFERRED, ASSUMED, BLOCKED, or CONTRADICTED. If needed evidence is unavailable, keep it UNKNOWN or BLOCKED.

Separate required fixes from optional improvements. Do not manufacture findings. CLEAN is valid only after concrete attempts to falsify the implementation found no evidence-backed defect.

## Repo-first blind-spot lens

Act as an evidence-based technical blind-spot critic, not an approval authority.

Start repo-first. From supplied artifacts derive the intended outcome, constraints/non-goals, affected surfaces, assumptions, success/failure evidence, and material unknowns. Do not invent missing context.

Before new hypotheses, audit the supplied results, including your own prior conclusions. Treat them as candidate claims, not as evidence merely because you produced them. Re-ground material conclusions against primary artifacts; call out contradictions, omitted evidence, or unsupported causal attribution.

Run these bounded probes:
1. Pattern drift: compare at least two relevant in-repository examples before claiming a structural or ownership violation; otherwise report the evidence gap.
2. Intent erosion: check whether strict contracts, metadata, acceptance criteria, or non-goals were weakened merely to make the implementation fit.
3. Operational overconfidence: treat workflow, deployment, migration, generated metadata, and irreversible side effects as high-risk until evidenced.
4. False failure attribution: a missing dependency, generated asset, tool, or environment prerequisite is not a product defect until setup readiness is established.
5. Premature closure: verify that outcome, impacted surfaces, validation evidence, and close claim line up.

Across repository or package boundaries, trace the semantic owner, authoritative input, crossing artifact and retained identity to the consumer. Do not infer ownership from names or documentation alone.

Prefer the smallest discriminating dogfood experiment over speculation. Use only environments relevant to the hypothesis: source checkout; clean installed/released consumer or cross-package release set; repeat/resume; or no-change. For historical replay, freeze base state/input and do not leak the known fix; starting with the answer cannot prove discovery quality. No-change is a valid outcome.

For every material blind spot, classify the claim with the existing epistemic status and cite supporting or contradicting evidence. State the hidden assumption and concrete failure chain, earliest observable signal, smallest falsification probe, and why existing tests or gates did not expose it. Name a corrective action only after the claim becomes VERIFIED.

Use adversarial pre-mortem reasoning only as a hypothesis generator. A plausible failure story, model confidence, numeric score, imagined future, repeated self-refinement, or successful mechanism execution is not evidence. Do not manufacture findings to satisfy a quota.

If required repository or runtime evidence is unavailable, keep the claim UNKNOWN or BLOCKED and name the missing evidence. READY FOR HUMAN CLOSE is valid only when bounded probes found no evidence-backed blocker and supplied validation/close evidence is coherent.

You are reviewing recall-compiler workflow artifacts. Use only the artifacts below as evidence.
Expose missing validation, missing outcome logging, mismatched selected guidance, unsafe assumptions, and handoff gaps. Do not approve code or durable learning.

## Deterministic preflight findings

- [WARN] missing_validation_evidence: No validation evidence marker was found near recall artifacts.
  - Searched markers: PHPStan, phpstan, PHPUnit, phpunit, composer ci, composer test, tests passed
- [WARN] missing_outcome_closeout: No evidence shows recall outcome close-out was prepared or logged.
  - Searched markers: log-outcome, recall-log.draft.json, outcome=, "outcome"
- [WARN] missing_review_checkpoint: No blind-spot review checkpoint marker was found.
  - Searched markers: review blindspots, review-blindspots, L2 blind-spot

## Output contract

Return Markdown with headings: Summary, Critical blind spots, Evidence, Required next action, Close readiness.
For each material claim, give its epistemic status and the concrete artifact/evidence that supports or contradicts it.
Review findings are investigation candidates, not instructions to modify code.
Close readiness must be BLOCKED, NEEDS HUMAN REVIEW, or READY FOR HUMAN CLOSE.

## Artifacts

### .agent-loop/recall/DOTFILES-13/meta.json

```text
{
    "schema_version": "1.0",
    "compilation_id": "compilation.DOTFILES-13.2026-10-11-070525.2635b9d1",
    "task_id": "DOTFILES-13",
    "task_files": [
        "agent_dotfiles",
        "tests",
        "docs",
        ".github/workflows",
        "README.md",
        "CHANGELOG.md",
        "install.sh",
        ".bashrc",
        ".zshrc",
        ".shellrc",
        ".functions",
        ".exports",
        "tools"
    ],
    "task_targets": [],
    "bundle_sha256": "dcd4be10ef998c72d1c7cbfe7da885f1f24298d21f778547636dc3a4a6167c48",
    "snapshot_sha256": "105eb9ac4d0221b0aa1f113960a239ce9a5ee7257112d87087231c09e1a4dc0a",
    "blocked": false,
    "block_reason": null,
    "selected_guidance": [],
    "evaluated_guidance": [],
    "selected_constraints": [],
    "selected_rejections": [],
    "outcome_stats": [],
    "warnings": [],
    "output_hashes": {
        "system.md": "e53865b3817e5e8b16b06db8a80aafa5515ff3e81cb925dfc1d30a10dd479c66",
        "validation-plan.md": "ce11fb7ccea05800b4b93a6ab3892ed05ddc1ade9f902f4f615eecc25f27a98b",
        "recall.bundle.json": "d304a121c7a567443128817b29a965e27364531403eb8313f5d8320bb9bcd38d",
        "facts.json": "b9b99d6e80c4d1013da599300fca6cfa3204881ad7a1baded5c0968d5881b8d6",
        "selection-report.json": "d6544acdfe94b7cb7322545d4a763c0f447a9948a73336fb8f847f8749c6adde"
    }
}
```

### .agent-loop/recall/DOTFILES-13/recall-log.draft.json

```text
{
    "applied": [],
    "applied_proposals": [],
    "comment": "Optional: add a guidance_outcomes row only for selected guidance (see evaluated_guidance) that actually changed, confirmed, or misled your work: {\"guidance_id\", \"guidance_type\", \"selected\": true, \"applied\", \"outcome\", \"comment\"} (outcome values: docs/guidance-events.md). A helpful row also needs attribution: {\"seen_before_decision\": did you read it before the decision it helped, \"also_prescribed_by\": the other sources that already prescribed that decision (task_prompt, contract, skill, template, constraint, repository_docs), or [] if nothing else did}. Leave the list empty when nothing notable happened; unjudged selections are neutral.",
    "compilation_id": "compilation.DOTFILES-13.2026-10-11-070525.2635b9d1",
    "constraints_used": [],
    "created_at": "2026-10-11T07:05:25+00:00",
    "evaluated_guidance": [],
    "guidance_outcomes": [],
    "guidance_used": [],
    "harmful": [],
    "helpful": [],
    "id": "outcome.2026-10-11.000",
    "irrelevant": [],
    "operating_prompt_outcomes": [],
    "result": "successful",
    "schema_version": "1.0",
    "selected": [],
    "session": "sess_placeholder",
    "task_files": [
        "agent_dotfiles",
        "tests",
        "docs",
        ".github/workflows",
        "README.md",
        "CHANGELOG.md",
        "install.sh",
        ".bashrc",
        ".zshrc",
        ".shellrc",
        ".functions",
        ".exports",
        "tools"
    ],
    "task_id": "DOTFILES-13",
    "task_targets": []
}
```

### .agent-loop/recall/DOTFILES-13/system.md

```text
# L2 Meta-Prompt Briefing for Task: DOTFILES-13
> Recall bundle SHA-256: dcd4be10ef998c72d1c7cbfe7da885f1f24298d21f778547636dc3a4a6167c48

## Task Description
Complete approved agent-shell evaluation with correctly scoped governance, retain only validated shell and regression improvements, publish reviewable evidence and independently validated pinned release.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `agent_dotfiles`
- File/path: `tests`
- File/path: `docs`
- File/path: `.github/workflows`
- File/path: `README.md`
- File/path: `CHANGELOG.md`
- File/path: `install.sh`
- File/path: `.bashrc`
- File/path: `.zshrc`
- File/path: `.shellrc`
- File/path: `.functions`
- File/path: `.exports`
- File/path: `tools`
- Scope: `agent_dotfiles`
- Scope: `tests`
- Scope: `docs`
- Scope: `.github/workflows`
- Scope: `README.md`
- Scope: `CHANGELOG.md`
- Scope: `install.sh`
- Scope: `.bashrc`
- Scope: `.zshrc`
- Scope: `.shellrc`
- Scope: `.functions`
- Scope: `.exports`
- Scope: `tools`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Complete fresh held-out native/CLI/profile repairs with independent oracles; disclose all setup/scope failures, quality outcomes, unavailable telemetry and confounded timings.
- Independent final review, exact-commit GitHub Python/Bashunit/shell and focused mutation checks, cold pinned install/doctor/profile/deactivation/uninstall/rollback evidence and resumable owner learning.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No global environment changes, installed consumer tool replacement, injected production defect, fabricated scope approval or claimed productivity benefit without evidence.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2
```

### .agent-loop/recall/DOTFILES-13/validation-plan.md

````text
# Validation Plan

## Required Validation

### Task Validation

```bash
python3 -m unittest discover -s tests -v
```

```bash
python3 -m compileall -q agent_dotfiles bin tests tools
```

```bash
/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict
```
````

### .agent-loop/sessions/2026-10-10-dotfiles-13-r1-b71144b4/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-10-dotfiles-13-r1-b71144b4/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-10-dotfiles-13-r1-b71144b4/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-10-dotfiles-13-r1-b71144b4/plan.md

```text
# Plan: DOTFILES-13

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-10-dotfiles-13-r1-b71144b4/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-10-dotfiles-13-r1-b71144b4",
    "task_id": "DOTFILES-13",
    "status": "done",
    "claimed_by": "codex",
    "claimed_at": "2026-10-10T18:48:49+00:00",
    "base_commit": null,
    "created_at": "2026-10-10T18:48:49+00:00",
    "updated_at": "2026-10-11T00:24:50+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": "2026-10-11T00:24:50+00:00",
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-10-dotfiles-13-r1-b71144b4/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*

## Validation evidence (Contract revision 1)

- Command: `python3 -m unittest discover -s tests -v`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:15:00+00:00
- Implementation snapshot: sha256:c34dd21c1d50434656ce71dafda53bb0b335903b7cc9f58de904c8e15dc49679
- Duration: 7853ms

## Validation evidence (Contract revision 1)

- Command: `python3 -m compileall -q agent_dotfiles bin tests tools`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:15:00+00:00
- Implementation snapshot: sha256:c34dd21c1d50434656ce71dafda53bb0b335903b7cc9f58de904c8e15dc49679
- Duration: 50ms

## Validation evidence (Contract revision 1)

- Command: `/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:15:02+00:00
- Implementation snapshot: sha256:c34dd21c1d50434656ce71dafda53bb0b335903b7cc9f58de904c8e15dc49679
- Duration: 1870ms

## Validation evidence (Contract revision 1)

- Command: `python3 -m unittest discover -s tests -v`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:24:26+00:00
- Implementation snapshot: sha256:fc650cad3daa7b271ac5ef4f91fe59dd3f46ca728ecc990b1b28a9713ac2ae79
- Duration: 7853ms

## Validation evidence (Contract revision 1)

- Command: `python3 -m compileall -q agent_dotfiles bin tests tools`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:24:26+00:00
- Implementation snapshot: sha256:fc650cad3daa7b271ac5ef4f91fe59dd3f46ca728ecc990b1b28a9713ac2ae79
- Duration: 43ms

## Validation evidence (Contract revision 1)

- Command: `/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:24:28+00:00
- Implementation snapshot: sha256:fc650cad3daa7b271ac5ef4f91fe59dd3f46ca728ecc990b1b28a9713ac2ae79
- Duration: 1637ms
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/checkpoints/001-scope-configuration-failure-no-retroactive-approval.md

```text
# Checkpoint 001: Scope configuration failure; no retroactive approval

DOTFILES-12 Contract allowed directories but omitted root shell/README/CHANGELOG/install.sh files changed at b9ea619. Technical validation retained, governance compliance not established. --file is replaced by explicit --scope in WorkflowPlanCommand. Root task remains incomplete; separate user-authorized correctly scoped DOTFILES-13 entered for final evaluation/review/publication. Earlier first-round and PHP-A scope failures require disclosure. Resume DOTFILES-13; never mark these earlier mutations machine-scope approved.
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*

- 001 Scope configuration failure; no retroactive approval (2026-10-11T07:05:43+00:00)
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/plan.md

```text
# Plan: DOTFILES-12

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-dotfiles-12-r1-4ee4da79",
    "task_id": "DOTFILES-12",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T00:37:13+00:00",
    "base_commit": null,
    "created_at": "2026-10-11T00:37:13+00:00",
    "updated_at": "2026-10-11T07:05:43+00:00",
    "checkpoints": [
        {
            "id": "001",
            "title": "Scope configuration failure; no retroactive approval",
            "created_at": "2026-10-11T07:05:43+00:00"
        }
    ],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-dotfiles-12-r1-4ee4da79/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-13-r2-12dd6f80/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-13-r2-12dd6f80/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-13-r2-12dd6f80/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-13-r2-12dd6f80/plan.md

```text
# Plan: DOTFILES-13

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-dotfiles-13-r2-12dd6f80/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-dotfiles-13-r2-12dd6f80",
    "task_id": "DOTFILES-13",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T07:05:25+00:00",
    "base_commit": null,
    "created_at": "2026-10-11T07:05:25+00:00",
    "updated_at": "2026-10-11T07:05:25+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-dotfiles-13-r2-12dd6f80/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*

## Validation evidence (Contract revision 2)

- Command: `python3 -m unittest discover -s tests -v`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T07:06:58+00:00
- Implementation snapshot: sha256:2b1ccb9057afb5a6f79597be181e32f5d739deed88443825fcc559dad9a77abf
- Duration: 9350ms

## Validation evidence (Contract revision 2)

- Command: `python3 -m compileall -q agent_dotfiles bin tests tools`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T07:06:58+00:00
- Implementation snapshot: sha256:2b1ccb9057afb5a6f79597be181e32f5d739deed88443825fcc559dad9a77abf
- Duration: 44ms

## Validation evidence (Contract revision 2)

- Command: `/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T07:07:00+00:00
- Implementation snapshot: sha256:2b1ccb9057afb5a6f79597be181e32f5d739deed88443825fcc559dad9a77abf
- Duration: 1816ms
```
