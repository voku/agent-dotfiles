import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
trace = [json.loads(line) for line in (root / "receipt/trace.jsonl").read_text().splitlines()]
manifest = json.loads((root / ".agent-loop/runs/TASK-1243/manifest.json").read_text())
result = {
    "arm": "C2-valid/profile", "task_id": "TASK-1243",
    "commit": "5a51932bf809c4faad048dbecfb08a6b9811afa7",
    "branch": "repair/TASK-1243", "remote_writes": False,
    "diagnosis": "str.splitlines(keepends=True) counted non-LF separators, disagreeing with native Git/ripgrep LF positions.",
    "source_positions": {"defect": "agent_dotfiles/cli.py:249", "repair": "agent_dotfiles/cli.py:249-252", "regression": "tests/test_cli.py:184", "safety_regression": "tests/test_cli.py:205"},
    "changed_files": ["agent_dotfiles/cli.py", "tests/test_cli.py"],
    "regression": "All non-LF splitlines control/Unicode separators, CRLF, final-LF/no-LF, partial/full ranges, bytes/hash, invalid start, empty and binary sources.",
    "checks": {"initial_cli": {"status": "expected_RED", "exit": 1, "tests": 33}, "new_cli": {"status": "expected_RED", "exit": 1, "tests": 35}, "full_before_repair": {"status": "expected_RED", "exit": 1, "tests": 88}, "python": {"status": "passed", "exit": 0, "tests": 88}, "compile": {"status": "passed", "exit": 0}, "bashunit": {"status": "passed", "exit": 0, "tests": 9, "version": "0.50.1"}, "native": {"status": "passed", "exit": 0}},
    "independent_evidence": {"script": "receipt/native-check.py", "Git_rg_line": 2, "sed_bytes_equal": True, "ranges": [[1,1],[2,2],[1,2]], "whole_file_sha256": "95798c6a33aff6aca55081e5c60d773425afd90e6e8ee33324183751c4ff7075", "parent_review": "PASS before reviewed commit"},
    "context": {"relevant": ["consumer protocol/task/guidance", "AGENTS.md", "canonical Loop skill/help", "cli.py read implementation", "tests/test_cli.py read contracts"], "missed": [], "irrelevant": ["PHP-specific marker warnings in deterministic review"], "repeated_retrieval_reasons": ["actual contract confirmed scope mismatch", "r2 approval/enter verified before product mutation", "compile repeated alone to recover individual status", "source coordinates confirmed with nl", "report read before exact acknowledgement", "own trace read for receipt"]},
    "tool_uptake": {"profile_activated": False, "reason": "Known source location used native rg/read per frozen guidance; no repeated discovery to invoke optional helpers", "native_tools": ["rg", "git", "sed", "sha256sum", "nl"], "task_cli": "own repaired checkout"},
    "friction": ["Root initially prepared approved r1 scope tests only; paused product mutation, root superseded/approved r2 with cli.py+tests scope. Pre-r2 regression work retained, no retroactive approval claim; totals unsuitable clean causal efficiency comparison.", "CLI generic help omits positional finding-transition/classify syntax; recorded rejected guesses", "unbound learn capture finding could not close run; recaptured with explicit current session", "single-file rg omitted filename; native harness corrected with -Hn", "batched compile+Bashunit hid compile status; standalone repeat exit0", "tool display truncates long output, tracer preserves full output"],
    "errors": [{"trace_index_1based": i+1, "argv": row["argv"], "exit": row["exit_code"], "stderr": row.get("stderr", ""), "stdout_tail": row.get("stdout", "")[-800:]} for i,row in enumerate(trace) if row["exit_code"] != 0],
    "first_relevant_trace_index_1based": next(i+1 for i,row in enumerate(trace) if "splitlines" in row.get("stdout", "") and "rg -n" in " ".join(row["argv"])),
    "trace_metrics": {"count_before_result": len(trace), "shell_elapsed_seconds": sum(row["elapsed_seconds"] for row in trace), "wall_span_seconds": trace[-1]["started_utc_epoch"]-trace[0]["started_utc_epoch"], "phase_boundaries": "Trace argv identifies bootstrap/source reads, direct apply_patch mutation, parallel validation, owner closeout. Direct edit timing unavailable."},
    "direct_edits": ["tests/test_cli.py regression via apply_patch", "agent_dotfiles/cli.py repair via apply_patch after r2 scope verified", "receipt/native-check.py and write-result.py via apply_patch"],
    "batching": "All shell calls tracer-v2; bash -c batches protocol/source/help reads, validation owner records, commit/finish. Native evidence script nests native/tool subprocesses under traced Python; validation gates parallelized as separate traced commands.",
    "workflow": {"state": manifest["state"], "next_action_kind": manifest["next_action_kind"], "run_id": manifest["run_id"], "contract_revision": 2, "learning_finding": "finding.2026-10-11.a0935f", "unused_unbound_finding": "finding.2026-10-11.40798a", "review_sha256": "7cd60b76e56ab8ed1e105aa0bddfbfd060f1c7c71e9381c9db4532705d3a5394", "manifest": ".agent-loop/runs/TASK-1243/manifest.json", "verification": ".agent-loop/runs/TASK-1243/verification.json", "learning": ".agent-loop/learning/history/run-learning/06d72bd1512506a24033917ee89edd6061accd2479297cd716b4ef1204aef79a.json"},
    "actual_state": "Local reviewed repair committed; tracked worktree clean; untracked .agent-loop/ and receipt/ retained; complete/none. No remote CI claimed.",
    "estimated_model_tokens": None,
}
(root / "receipt/result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"receipt": str(root / "receipt/result.json"), "state": result["workflow"]["state"], "next": result["workflow"]["next_action_kind"]}))
