import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

project = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    source = root / "source.php"
    raw = "comment \r \v \f \x1c \x1d \x1e \x85 \u2028 \u2029\r\ntarget\n".encode()
    source.write_bytes(raw)
    digest = subprocess.run(["sha256sum", str(source)], capture_output=True, check=True).stdout.decode().split()[0]
    rg = subprocess.run(["rg", "-Hn", "target", str(source)], capture_output=True, check=True)
    assert rg.stdout.endswith(b":2:target\n"), rg.stdout
    subprocess.run(["git", "init", "-q", str(root)], check=True)
    subprocess.run(["git", "-C", str(root), "add", "source.php"], check=True)
    git = subprocess.run(["git", "-C", str(root), "grep", "-n", "--cached", "target"], capture_output=True, check=True)
    assert git.stdout == b"source.php:2:target\n", git.stdout
    evidence = []
    for start, end in ((1, 1), (2, 2), (1, 2)):
        run = subprocess.run([str(project / "bin/agent-dotfiles"), "read", "source.php", "--root", str(root), "--start", str(start), "--end", str(end)], capture_output=True, check=True)
        report = json.loads(run.stdout)
        expected = subprocess.run(["sed", "-n", f"{start},{end}p", str(source)], capture_output=True, check=True).stdout
        assert report["content"].encode() == expected
        assert report["sha256"] == digest == hashlib.sha256(raw).hexdigest()
        assert report["total_lines"] == 2
        evidence.append({"start": start, "end": end, "sha256": digest, "native_byte_match": True})
    print(json.dumps({"rg": rg.stdout.decode().strip(), "git": git.stdout.decode().strip(), "ranges": evidence}))
