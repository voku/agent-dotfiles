import json
from pathlib import Path

rows = [json.loads(line) for line in Path('receipt/trace.jsonl').read_text().splitlines()]
final = next(json.loads(row['stdout']) for row in reversed(rows)
             if row['argv'][0].endswith('/loop') and '"complete": true' in row['stdout'])
result = {
    'task': 'TASK-1203', 'arm': 'C1', 'commit': '655cfed87ede7756fa5244a2d940fec8e72a6188',
    'branch': 'fix/TASK-1203-source-digest', 'estimated_model_tokens': None,
    'diagnosis': 'agent_dotfiles/cli.py:264 hashes selected content_bytes instead of whole raw source bytes; raw read at line 241.',
    'changed_files': ['agent_dotfiles/cli.py', 'tests/test_cli.py'],
    'regression': 'tests/test_cli.py:184 tests three partial ranges plus full range, CRLF, Unicode separator, missing terminal newline, EOF coordinates, byte count and flags. Before repair three new partial subtests and existing partial test failed (34 tests, 4 failures).',
    'checks': [{'command': row['argv'], 'exit_code': row['exit_code'], 'trace_index': i + 1}
               for i, row in enumerate(rows) if row['argv'][0] in ('python3', '/workspace/scratch/dotfiles-mission/bashunit/bashunit')],
    'validation_summary': 'Explicit rerun: 87 Python tests exit0; compileall including tools exit0; Bashunit 0.50.1 9 tests /20 assertions exit0. First post-repair batch also passed tests; batch exit1 was finish routing review.',
    'independent_evidence': 'receipt/independent.py: native sha256sum equals 98420b3101428aab4303168269a1db940375189d6ff901b09fe464da6cd5824d for all three selected ranges; exact bytes checked. Parent independent review PASS before closeout.',
    'first_relevant_trace_index': 3,
    'phases': {'source_read_trace_indexes': [1,2,3,4], 'implementation': 'direct apply_patch after trace5; regression added before trace6; fix after trace6', 'validation': 'trace7 batch plus explicit independent checks and repeated per-command gates', 'closeout': 'canonical exact report acknowledgement, owner Learning capture/validation then finish complete'},
    'direct_edits': ['tests/test_cli.py regression', 'agent_dotfiles/cli.py digest input', 'receipt/independent.py', 'receipt/write_result.py'],
    'untraced_shell_calls': [],
    'context': {'relevant': ['native rg identified cli.py:264; native sed full function and tests; defect reproduced through checkout CLI partial ranges'],
                'missed': ['optional agent_search limit12 truncated before reaching cli.py; native rg already found it'],
                'irrelevant': ['optional search matches install hashes and git-patch hashes', 'PHP-oriented blindspot validation marker warning in Python repository'],
                'false': ['none treated as source instructions'],
                'repetitions': ['Full tests repeated to prove individual subcommand statuses after batch ambiguity', 'review report reread exact identity before acknowledgement', 'receipt trace dump unnecessarily verbose and truncated in UI; full preserved file remains']},
    'tool_friction': ['Optional helper activation worked in fresh env -u BASH_ENV bash --noprofile --norc; agent_search used once and truncated exit3 inside batch (outer status masked). Native tools used for diagnosis and maintained CLI for reproduction.',
                      'learn capture extension ignored session linkage; validated finding was rejected for task/session lineage. Corrected via generic finding-capture --session and validation. Initial finding remains evidence of unsuccessful attempt.',
                      'finding-transition --help did not show command-specific help and returned positional-argument errors twice. Namespace help plus errors established positional ID/status.',
                      'UI outputs sometimes truncated; complete stdout/stderr retained by tracer.'],
    'errors': [{'trace_index': i+1, 'argv': row['argv'], 'exit_code': row['exit_code'], 'stderr': row['stderr'], 'stdout': row['stdout']}
               for i, row in enumerate(rows) if row['exit_code'] != 0],
    'workflow': final,
    'learning': {'finding': 'finding.2026-10-11.2cacdd', 'unused_initial_finding': 'finding.2026-10-11.b2a4ac', 'decision': 'findings_recorded'},
    'remote': 'No remote writes; parent handles GitHub and CI.'
}
Path('receipt/result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'commit': result['commit'], 'state': final['manifest']['state'], 'next_action': final['next_action'], 'result': 'receipt/result.json'}))
