import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

with tempfile.TemporaryDirectory() as directory:
    raw = b"one\r\ntwo \xe2\x80\xa8\nlast"
    source = Path(directory, "source.txt")
    source.write_bytes(raw)
    digest = subprocess.check_output(["sha256sum", str(source)], text=True).split()[0]
    assert digest == hashlib.sha256(raw).hexdigest()
    for start, end, expected in ((1, 1, b"one\r\n"), (2, 2, b"two \xe2\x80\xa8\n"), (3, 8, b"last")):
        result = subprocess.run(["./bin/agent-dotfiles", "read", "source.txt", "--root", directory,
                                 "--start", str(start), "--end", str(end)], capture_output=True, check=True)
        report = json.loads(result.stdout)
        assert report["sha256"] == digest
        assert report["content"].encode() == expected
        assert report["content_bytes"] == len(expected)
        assert report["actual_end"] == min(end, 3)
        assert report["start"] == start and report["requested_end"] == end
        assert not report["complete_file"] and not report["truncated"]
        print(json.dumps({"range": [start, end], "sha256": digest, "content_hex": expected.hex(), "status": 0}))
