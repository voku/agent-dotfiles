# L2 Meta-Prompt Briefing for Task: TASK-1222
> Recall bundle SHA-256: a748e013e7dd454c8140f9b676d42e9a9c23659795664d462bfd73cb5591fc72

## Task Description
Repair exact source-line evidence disagreement while preserving bytes, safety and whole-source identity; validate and complete governed maintenance.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `agent_dotfiles/cli.py`
- File/path: `tests`
- Scope: `agent_dotfiles/cli.py`
- Scope: `tests`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Native LF positions preserved across Unicode/control separators and CRLF; meaningful failing regression, repository gates, independent review and owner run-bound Learning.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- Global configuration, unrelated product changes, oracle access, remote writes.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2