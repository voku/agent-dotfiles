# L2 blind-spot analysis prompt for EVAL12-A1

## Presentation

Write the final review in language en. Translate explanatory headings and prose; preserve exact source text, identifiers, paths, citations, and required machine-readable status tokens.

## First-draft falsification lens

Treat the current implementation as a first draft, even if produced by you or paired with a confident rationale.

Review for falsification rather than confirmation. Try to prove concrete failures against requirements, acceptance criteria, constraints, non-goals, current source, tests, static analysis, and safe runtime evidence.

Acceptance criteria are required outcomes, not evidence they are satisfied. Prior reasoning, model confidence, reviewer consensus, prompt construction, and unexecuted commands are not verification.

Treat every LLM-produced statement as a candidate claim, not repository truth. Re-ground material claims against current authoritative artifacts or deterministic evidence before acting. A detailed patch is not evidence that the described classes, boundaries, bugs, or metrics actually exist. If model output conflicts with current authoritative artifacts, the artifacts win. Reproduce a finding before fixing it. Review findings are investigation candidates, not instructions to modify code.

Classify material conclusions as VERIFIED, INFERRED, ASSUMED, BLOCKED, or CONTRADICTED. If needed evidence is unavailable, keep it UNKNOWN or BLOCKED.

Separate required fixes from optional improvements. Do not manufacture findings. CLEAN is valid only after concrete attempts to falsify the implementation found no evidence-backed defect.

## Repo-first blind-spot lens

Act as an evidence-based technical blind-spot critic, not an approval authority.

Start repo-first. From supplied artifacts derive the intended outcome, constraints/non-goals, affected surfaces, assumptions, success/failure evidence, and material unknowns. Do not invent missing context.

Before new hypotheses, audit the supplied results, including your own prior conclusions. Treat them as candidate claims, not as evidence merely because you produced them. Re-ground material conclusions against primary artifacts; call out contradictions, omitted evidence, or unsupported causal attribution.

Run these bounded probes:
1. Pattern drift: compare at least two relevant in-repository examples before claiming a structural or ownership violation; otherwise report the evidence gap.
2. Intent erosion: check whether strict contracts, metadata, acceptance criteria, or non-goals were weakened merely to make the implementation fit.
3. Operational overconfidence: treat workflow, deployment, migration, generated metadata, and irreversible side effects as high-risk until evidenced.
4. False failure attribution: a missing dependency, generated asset, tool, or environment prerequisite is not a product defect until setup readiness is established.
5. Premature closure: verify that outcome, impacted surfaces, validation evidence, and close claim line up.

Across repository or package boundaries, trace the semantic owner, authoritative input, crossing artifact and retained identity to the consumer. Do not infer ownership from names or documentation alone.

Prefer the smallest discriminating dogfood experiment over speculation. Use only environments relevant to the hypothesis: source checkout; clean installed/released consumer or cross-package release set; repeat/resume; or no-change. For historical replay, freeze base state/input and do not leak the known fix; starting with the answer cannot prove discovery quality. No-change is a valid outcome.

For every material blind spot, classify the claim with the existing epistemic status and cite supporting or contradicting evidence. State the hidden assumption and concrete failure chain, earliest observable signal, smallest falsification probe, and why existing tests or gates did not expose it. Name a corrective action only after the claim becomes VERIFIED.

Use adversarial pre-mortem reasoning only as a hypothesis generator. A plausible failure story, model confidence, numeric score, imagined future, repeated self-refinement, or successful mechanism execution is not evidence. Do not manufacture findings to satisfy a quota.

If required repository or runtime evidence is unavailable, keep the claim UNKNOWN or BLOCKED and name the missing evidence. READY FOR HUMAN CLOSE is valid only when bounded probes found no evidence-backed blocker and supplied validation/close evidence is coherent.

You are reviewing recall-compiler workflow artifacts. Use only the artifacts below as evidence.
Expose missing validation, missing outcome logging, mismatched selected guidance, unsafe assumptions, and handoff gaps. Do not approve code or durable learning.

## Deterministic preflight findings

- [WARN] missing_validation_evidence: No validation evidence marker was found near recall artifacts.
  - Searched markers: PHPStan, phpstan, PHPUnit, phpunit, composer ci, composer test, tests passed
- [WARN] missing_outcome_closeout: No evidence shows recall outcome close-out was prepared or logged.
  - Searched markers: log-outcome, recall-log.draft.json, outcome=, "outcome"
- [WARN] missing_review_checkpoint: No blind-spot review checkpoint marker was found.
  - Searched markers: review blindspots, review-blindspots, L2 blind-spot

## Output contract

Return Markdown with headings: Summary, Critical blind spots, Evidence, Required next action, Close readiness.
For each material claim, give its epistemic status and the concrete artifact/evidence that supports or contradicts it.
Review findings are investigation candidates, not instructions to modify code.
Close readiness must be BLOCKED, NEEDS HUMAN REVIEW, or READY FOR HUMAN CLOSE.

## Artifacts

### .agent-loop/recall/EVAL12-A1/meta.json

```text
{
    "schema_version": "1.0",
    "compilation_id": "compilation.EVAL12-A1.2026-10-11-003927.4f760c25",
    "task_id": "EVAL12-A1",
    "task_files": [
        "tests"
    ],
    "task_targets": [],
    "bundle_sha256": "b964bab2447ede827670aa60fdd5f7fec2f7f09c817e8f37593d2a74e9d8089b",
    "snapshot_sha256": "9525ca1c0a709dfe1193c5cd2736637c7782656d3026b35db0be8e51000d4399",
    "blocked": false,
    "block_reason": null,
    "selected_guidance": [],
    "evaluated_guidance": [],
    "selected_constraints": [],
    "selected_rejections": [],
    "outcome_stats": [],
    "warnings": [],
    "output_hashes": {
        "system.md": "b8dca152563f813b83b6ff232b31495d59bd6678c141d95ac22910c4397fbdc7",
        "validation-plan.md": "ce11fb7ccea05800b4b93a6ab3892ed05ddc1ade9f902f4f615eecc25f27a98b",
        "recall.bundle.json": "83711b16e88819016e5e3d4181429017d91b520925406672cf21ed498616cfae",
        "facts.json": "1416f6f414ccf290e97495e3ef37b80761702ee1d704ce6eaa32ceb7d7b73e53",
        "selection-report.json": "de80b3a02b9a2c2d50405047fd004d23b9861ecab86386a28d98fbc105f3737a"
    }
}
```

### .agent-loop/recall/EVAL12-A1/recall-log.draft.json

```text
{
    "applied": [],
    "applied_proposals": [],
    "comment": "Optional: add a guidance_outcomes row only for selected guidance (see evaluated_guidance) that actually changed, confirmed, or misled your work: {\"guidance_id\", \"guidance_type\", \"selected\": true, \"applied\", \"outcome\", \"comment\"} (outcome values: docs/guidance-events.md). A helpful row also needs attribution: {\"seen_before_decision\": did you read it before the decision it helped, \"also_prescribed_by\": the other sources that already prescribed that decision (task_prompt, contract, skill, template, constraint, repository_docs), or [] if nothing else did}. Leave the list empty when nothing notable happened; unjudged selections are neutral.",
    "compilation_id": "compilation.EVAL12-A1.2026-10-11-003927.4f760c25",
    "constraints_used": [],
    "created_at": "2026-10-11T00:39:27+00:00",
    "evaluated_guidance": [],
    "guidance_outcomes": [],
    "guidance_used": [],
    "harmful": [],
    "helpful": [],
    "id": "outcome.2026-10-11.000",
    "irrelevant": [],
    "operating_prompt_outcomes": [],
    "result": "successful",
    "schema_version": "1.0",
    "selected": [],
    "session": "sess_placeholder",
    "task_files": [
        "tests"
    ],
    "task_id": "EVAL12-A1",
    "task_targets": []
}
```

### .agent-loop/recall/EVAL12-A1/system.md

```text
# L2 Meta-Prompt Briefing for Task: EVAL12-A1
> Recall bundle SHA-256: b964bab2447ede827670aa60fdd5f7fec2f7f09c817e8f37593d2a74e9d8089b

## Task Description
Diagnose and narrowly repair contradictory source-range digest evidence in the supplied real agent-dotfiles checkout; independently validate and complete governed maintenance.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tests`
- Scope: `tests`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Whole-file source digest is stable across ranges; exact content/positions/errors remain correct; meaningful regression tests and repository checks pass; maintain full evidence and governed review/Learning closeout.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- Do not inspect evaluator/oracle/otherconsumer directories, alter installed tools, source interactive profiles, weaken tests, or change unrelated product code.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2
```

### .agent-loop/recall/EVAL12-A1/validation-plan.md

````text
# Validation Plan

## Required Validation

### Task Validation

```bash
python3 -m unittest discover -s tests -v
```

```bash
python3 -m compileall -q agent_dotfiles bin tests tools
```

```bash
/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict
```
````

### .agent-loop/sessions/2026-10-11-eval12-a1-r1-455e5871/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-eval12-a1-r1-455e5871/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-11-eval12-a1-r1-455e5871/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-eval12-a1-r1-455e5871/plan.md

```text
# Plan: EVAL12-A1

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-eval12-a1-r1-455e5871/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-eval12-a1-r1-455e5871",
    "task_id": "EVAL12-A1",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T00:39:27+00:00",
    "base_commit": null,
    "created_at": "2026-10-11T00:39:27+00:00",
    "updated_at": "2026-10-11T00:39:27+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-eval12-a1-r1-455e5871/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*

## Validation evidence (Contract revision 1)

- Command: `python3 -m unittest discover -s tests -v`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:40:59+00:00
- Implementation snapshot: sha256:54012b52c692a9ea79c750890ae39f7d7b63be930da888a12ec4ea64b7e9be63
- Duration: 9885ms

## Validation evidence (Contract revision 1)

- Command: `python3 -m compileall -q agent_dotfiles bin tests tools`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:40:59+00:00
- Implementation snapshot: sha256:54012b52c692a9ea79c750890ae39f7d7b63be930da888a12ec4ea64b7e9be63
- Duration: 45ms

## Validation evidence (Contract revision 1)

- Command: `/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T00:41:01+00:00
- Implementation snapshot: sha256:54012b52c692a9ea79c750890ae39f7d7b63be930da888a12ec4ea64b7e9be63
- Duration: 1980ms
```
