# L2 Meta-Prompt Briefing for Task: EVAL12-A1
> Recall bundle SHA-256: b964bab2447ede827670aa60fdd5f7fec2f7f09c817e8f37593d2a74e9d8089b

## Task Description
Diagnose and narrowly repair contradictory source-range digest evidence in the supplied real agent-dotfiles checkout; independently validate and complete governed maintenance.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tests`
- Scope: `tests`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Whole-file source digest is stable across ranges; exact content/positions/errors remain correct; meaningful regression tests and repository checks pass; maintain full evidence and governed review/Learning closeout.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- Do not inspect evaluator/oracle/otherconsumer directories, alter installed tools, source interactive profiles, weaken tests, or change unrelated product code.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2