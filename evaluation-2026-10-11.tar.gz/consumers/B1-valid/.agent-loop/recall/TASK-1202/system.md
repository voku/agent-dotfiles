# L2 Meta-Prompt Briefing for Task: TASK-1202
> Recall bundle SHA-256: 370e5b963bcbdb82d7ef2f4c357572179e66b9c6aa4b67e9df103682cae7a33b

## Task Description
Diagnose and narrowly repair contradictory source-range digest evidence in agent-dotfiles, preserve contracts, validate and finish actual governed maintenance.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tests`
- Scope: `tests`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Whole-source digest stable across ranges; exact source positions/content/errors preserved; meaningful regression and all repository checks pass; independent verification, actual review and run-boundLearning closeout.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No oracle/otherconsumer/previousresults access, installedtool changes, interactiveprofile sourcing, weakenedtests or unrelatedproduct edits.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2