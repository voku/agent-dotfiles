# L2 Meta-Prompt Briefing for Task: TASK-1211
> Recall bundle SHA-256: 1e16132dded806133b0edf104e54e4bcc9ec9250f29bf69c1e4036cd7d4839ac

## Task Description
Prepare a self-contained durable handoff for task TASK-1211.

Current-session handoff notes supplied explicitly by the acting host. Treat these as candidate context, not durable authority; re-ground every material claim against repository/owner evidence before persisting it:
S0 committed 3ea0ab0: actual PR758 diff reproduces classifier RuntimeException; existing negative gate unchanged. Parent reviewed diagnostic and owner-boundary doc with no blocking production concern. Full issue761 remains unresolved: semantic-review owner receipt and actual acceptance/negative cases remain S1/S2 prerequisites. Next canonical gate is run-bound Learning disposition; composer ci attempt is being recorded separately.

Current governed Session identity/metadata:
```json
{
    "schema_version": "1.1",
    "id": "2026-10-11-task-1211-r1-04c78ccc",
    "task_id": "TASK-1211",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T00:45:36+00:00",
    "base_commit": null,
    "created_at": "2026-10-11T00:45:36+00:00",
    "updated_at": "2026-10-11T00:45:36+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

Current durable Contract evidence:
```json
{
    "schema_version": "1.0",
    "kind": "task_contract",
    "task_id": "TASK-1211",
    "goal": "Complete bounded actual PHP maintenance S0 for agent-loop#761: exact real acceptance-case reproduction, owner/caller/API investigation, meaningful regression evidence and safe next slice; only implement a complete owner-correct fix if feasible.",
    "scope": [
        "tools/Dogfood",
        "tests/Dogfood",
        "docs"
    ],
    "non_goals": [
        "No ownerprivateJSON/Markdown parser bypass, inventedsemanticapproval/Finding, runtime/vendor changes, duplicateproductionmerge, oracle/otherarm access or claimS0meansfullissueclosed."
    ],
    "validation": [
        "/workspace/.cloud-setup/bin/php vendor/bin/phpunit tests/Dogfood/SelfShapeEvidenceTest.php"
    ],
    "acceptance_criteria": [
        "Reproduce actual#758classificationerror, distinguish existingreviewedmaintenance from unreviewedpromotion, identify ownerpublicAPIs and consumers, preserve failclosedinvariants, document and validate owner-correct nextslice with actualPHPchecks and independentreview."
    ],
    "acceptance_observations": [],
    "tags": [],
    "behavior_anchors": [],
    "operating_prompt_manifest": null,
    "operating_prompts": [],
    "status": "approved",
    "revision": 1,
    "planned_by": "codex",
    "base_commit": null,
    "approved_by": "user",
    "approved_at": "2026-10-11T00:45:36+00:00",
    "created_at": "2026-10-11T00:45:36+00:00",
    "updated_at": "2026-10-11T00:45:36+00:00"
}
```

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Repository Global Memory (`MEMORY.md`)
# Repository memory

This file contains reviewed, durable rules for `voku/agent-loop`. Raw observations belong in `.agent-loop/learning/findings/`; repeatable behavior belongs in tests, dogfood runners, or static rules. A row here is deliberately short because memory is an index into executable truth, not a replacement for it.

## Durable repository rules

| Subject | Durable rule | Canonical home |
| --- | --- | --- |
| Internal package boundaries | Workflow orchestration calls focused-package typed PHP APIs when they exist. User-facing package CLI delegation stays at the Dispatcher boundary; do not reconstruct focused-package argv inside `voku\\AgentLoop\\Workflow`. | `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php` and workflow tests |
| Workflow session invariant | Governed workflow orchestration has at most one active session per task. Start/plan may reuse that session; if more than one active session already exists, fail before further task work. Retries after partial failure must not allocate another active session. | `WorkflowStartCommand`, `WorkflowPlanCommand`, and workflow tests |
| Dogfood entrypoints | Repository self-dogfood executes `php bin/agent-loop`; installed-consumer dogfood separately proves `vendor/bin/agent-loop`. They are different packaging contracts and both remain covered. | `tools/self-shape-dogfood.php` and `tools/release-set-dogfood.php` |
| Pull-request dogfood credentials | A PR self-shape job needs repository history, not write access. Keep its `GITHUB_TOKEN` at `contents: read` and use checkout with `persist-credentials: false` so PR-controlled code does not inherit a persisted repository credential. | `.github/workflows/ci.yml` and `.agent-loop/learning/findings/validated/finding.2026-08-07.007.json` |
| Self-review close-out | An exploratory blind-spot review may warn while work is open. Before close, run `recall log-outcome` and record a checkpoint that evidences both outcome close-out and `review blindspots`. `workflow close` owns the gate: it refuses a missing, invalid or `fail` report and admits a `warn`, because advisory findings such as `security_sensitive_context` fire on any diff that mentions security terms and cannot be resolved by working harder. CLI exit 0 alone is not sufficient evidence, so the residual status is recorded as close-out evidence rather than inferred from the exit code. | `WorkflowCloseCommand::checkReviewGate()`, `tests/WorkflowCloseCommandTest.php`, and `tools/self-shape-dogfood.php` |
| Tooling test isolation | Project-specific PHPStan rule fixtures run in a separate PHPStan process. Do not load `PHPStan\\Testing\\RuleTestCase` into agent-loop's normal PHPUnit process while `agent-map` also performs Composer-based PHPStan discovery there. | `phpstan/Rules/NoInProcessPhpstanRuleTestCaseRule.php` and `tools/project-phpstan-rules.php` |
| Git repository detection | Repository state is asked of Git, never inferred from the shape of `.git`. A linked worktree stores `.git` as a file, which silently turned `init doctor` and `init sync-githooks` into no-ops for a valid checkout. | `phpstan/Rules/NoGitDirectoryShapeAssumptionRule.php`, `src/GitWorkTree.php`, and `tests/GitWorkTreeDetectionTest.php` |
| CI ownership | GitHub Actions executes the repository dogfood runner; it does not duplicate the governed lifecycle or maintain a second hard-coded changed-file list. The runner derives PR scope from Git. | `tools/self-shape-dogfood.php` and `.github/workflows/ci.yml` |
| Learning decision consistency | The self-shape learning decision follows the durable evidence in the actual PR diff. If project findings or `MEMORY.md` are changed, record `findings_recorded`; otherwise record `no_durable_learning`. Do not close with a learning state that contradicts the repository evidence produced by the task. | `tools/self-shape-dogfood.php` and `.agent-loop/learning/findings/validated/finding.2026-08-07.006.json` |
| Derived state paths | A repository-local derived path has one owner for reading *and* writing. `ProjectLayout::mapSearchIndex()` was read by `workflow approve` and written by nothing, so ranked map evidence silently never reached the governed context. When a decisive-evidence channel is unavailable, the workflow says so rather than compiling a quietly narrower context. | `src/Dispatcher.php`, `tests/MapSearchIndexOwnershipTest.php`, and `tests/WorkflowApproveSearchIndexEvidenceTest.php` |
| Memory follows executable truth | When a `MEMORY.md` row and its named canonical home disagree, correct the row towards what the code enforces; do not add a second enforcement point to make the prose true. | `.agent-loop/learning/findings/validated/finding.2026-08-14.007.json` and `docs/dogfood/2026-08-14-second-learning-pass.md` |
| Blind-spot review of a diff | Read a change for what it removed, not only for what it added. An invariant that held by construction needs an explicit assertion once its construction changes; a random source is injected rather than sampled by a test; a process call is not a drop-in for a filesystem check, because it can fail in ways that print. | `.agent-loop/learning/findings/consolidated/finding.2026-08-14.015.json` and `src/GitWorkTree.php` |
| Runtime dependency boundary | A package cannot be dev-only while a class `agent-loop` publishes depends on it: `ArchitectureRules` ships in `src/` and implements `ItpContext\\Contract\\RuleIdentifier`, so anything reflecting over production classes fatals without it. Loading a shipped class is not the same as running a command, so a CLI smoke test cannot decide a dependency boundary. | `tests/RealIssueEvidenceToolBoundaryTest.php` and `docs/dogfood/real-issue-acceptance.md` |
| Governed context evidence conservation | When decisive evidence is missing from a governed context, first establish where it was lost along map discovery, Recall selection and context projection. Widening search, changing ranking or raising the context budget is a last resort and must be recorded in the frozen replay. | `tests/FrozenReplayEvidenceChainTest.php` and `tests/WorkflowApproveSearchIndexEvidenceTest.php` |
| Learning evidence detection | Detect learning evidence by finding identity across every findings state directory, not by the directory a finding currently occupies. A `MEMORY.md` change with no finding evidence fails the gate rather than selecting a status around it. | `tools/self-shape-dogfood.php` and its tests |
| Tool-coupled instruction assets | Machine-readable instruction assets coupled to a tool's CLI, schema or output contract ship from the repository that owns the tool and are tested with it. A general skill collection may reference or install tool-owned assets but must not keep a second canonical copy. | `resources/prompts/operating-prompts.json` and `.agent-loop/learning/findings/consolidated/finding.2026-08-14.005.json` |
| Host guidance ownership | `init install-assets` projects first-party package assets. A project that declares `package_skills=false` and its own `paths.skills_root` projects that root through `sync-skills`, so it does not acquire a competing package copy of the same rule. | `resources/skills/agent-guidance-maintenance/SKILL.md`, `InitMultiSkillSourceTest.php`, and `docs/contributing/repository-layout.md` |
| Lifecycle routing | A router may select the smallest relevant specialist, but only the current `enter`/`finish` result selects governed lifecycle work; it must not invent task-start, Recall, repair, Learning, review, or close phases. | `resources/instructions/project-instructions.md`, `resources/skills/agent-loop-workflow/SKILL.md`, and `HostLifecycleGuidanceAuthorityTest.php` |
| Dogfood runners are orchestration only | Runners orchestrate; every decision they make lives in a tested class under `src/Dogfood/`. Convert a shell runner for testability rather than portability - Git for Windows ships bash. A static rule carries the scope it was earned in: `-n` belongs to validation subprocesses, not to invoking our own CLI, which needs the extensions `php.ini` loads. | `src/Dogfood/SelfShapeEvidence.php` and `tests/SelfShapeEvidenceTest.php` |
| Learning promotion | Findings are evidence, not durable memory. Promote only reviewed lessons; when a rule is objectively detectable, back the memory entry with a test, dogfood gate, or static-analysis rule. | `docs/workflow/learning-boundary.md` and `.agent-loop/learning/` |

## Archived task learning

| Archived on | Task | Summary | Archive reason | Durable lesson candidate | Promoted to |
| --- | --- | --- | --- | --- | --- |
| 2026-08-07 | `SELF-SHAPE` / PR #28 | Shaped workflow/session boundaries while `agent-loop` governed and reviewed its own change, then incorporated independent security and data-integrity review findings. | The task-specific evidence is captured by validated findings and CI artifacts; only stable rules belong above. | Prefer typed package APIs for internal orchestration, preserve one active session per governed task, keep PR dogfood credentials read-only/non-persistent, keep repository and consumer dogfood entrypoints distinct, isolate tooling tests, make final self-review evidence-complete with machine-readable status `ok`, and keep the learning decision consistent with the durable evidence actually produced. | `MEMORY.md`; `docs/dogfood/self-shaping.md`; `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php`; workflow tests; `.github/workflows/ci.yml`; `tools/project-phpstan-rules.php`; `tools/self-shape-dogfood.php` |

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### constraint.agent-loop.phpstan.in-process-rule-test-case
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap
- **Source**: proposal.2026-09-13.2acd04

### constraint.workflow.recovery.next-action-must-advance
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap
- **Source**: proposal.2026-08-20.c2a001

### proposal.2026-08-14.001
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.003
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.007
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.011
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.013
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.015
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.c969ec
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.d7d793
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-20.c2a001
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-09-13.2acd04
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### todo-card-handoff (L2)
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The task explicitly selected this reusable operating-prompt recipe.
- **How**: Resolved from the supplied manifest with template SHA-256 219b05d4d6c6cc0f997e332def936a7dc895a77029bd9a6b13495f0a5d0d88ab.
- **Authority**: task_input
- **Use**: construct_project_specific_l1_contract
- **Source**: /workspace/scratch/dotfiles-mission/loop-runtime/vendor/voku/agent-recall-compiler/resources/skills/agent-recall-consumer/operating-prompts.json#todo-card-handoff

### composer ci
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The repository declares this Composer script, so the command is an exact project-native entry point rather than an inferred tool invocation.
- **How**: Read directly from composer.json scripts.ci.
- **Authority**: project_metadata
- **Use**: verification_candidate
- **Source**: /workspace/scratch/evaluation-12/PHP-A1/composer.json

### PHP runtime constraint ^8.3
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The supported runtime constrains valid implementation syntax and dependencies.
- **How**: Read directly from composer.json require.php.
- **Authority**: project_metadata
- **Use**: implementation_constraint
- **Source**: /workspace/scratch/evaluation-12/PHP-A1/composer.json

### Omitted Project Capabilities
- **Omitted from runtime context**: 35
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 15
- **configuration_anchor**: 3
- **repository_command**: 14
- **tool_presence**: 3

## L2 Operational Prompt Construction

The selected recipes below are meta-prompts, not implementation instructions. Use them to synthesize project-specific L1 operational prompts from the compiled recall context in this briefing.

For each recipe, produce exactly these five sections:
1. **Goal** — a concrete outcome with every supplied measurable floor preserved.
2. **Context** — exact project anchors already supported by recall evidence: files, symbols, callers, tests, repository patterns, task state, and known constraints.
3. **Constraints** — invariants and scope boundaries that shrink the search space without inventing new policy.
4. **Verification** — exact repository-supported commands, probes, or other measurement procedures that will test the contract.
5. **Done When** — observable results and stopping conditions that those measurements must produce before success may be claimed.

Construction rules:
- Prefer repository-specific facts over generic advice. If recall already knows an exact path, symbol, command, or contract, name it.
- Do not leave generic placeholders such as `<file>`, `<test command>`, or "follow best practices" when the compiled context contains a concrete replacement.
- Preserve numeric floors and explicit stop conditions from the selected recipe. Do not weaken them into suggestions.
- Preserve task acceptance criteria as required outcomes, never as evidence that they are satisfied. The generated contract must account for them without manufacturing a pass verdict from their presence.
- Preserve explicit non-goals and task scope. Context selected for understanding, dependency analysis, or verification does not grant edit permission and must not silently widen the task.
- Keep Verification and Done When distinct: Verification names how reality is measured; Done When names the acceptable observed result.
- If required verification cannot be performed or observed under the current constraints, keep the result `UNKNOWN` or `BLOCKED` and name the missing evidence. Do not weaken acceptance criteria, scope, or non-goals to manufacture success. Changing task policy belongs to its owner; in a governed run that requires a separate approved re-plan.
- Never treat prior model reasoning, model confidence, reviewer consensus, prompt construction, or an unexecuted command as verification.
- Never invent repository commands, tools, APIs, or architectural rules. Mark missing evidence as `UNKNOWN` or make evidence discovery part of the generated Context section.
- Use imperative language. Remove hedges such as "maybe", "try to", "consider", "if possible", and "should probably".

Delegated execution continuation rules:
- Apply these continuation rules only to contracts that execute work. A durable planning/work-package recipe such as `todo-card-handoff` is not executable authority and must not inherit automatic continuation merely because it is rendered beside execution guidance.
- When the authorized work contains multiple TODOs or milestones, define bounded executable slices before implementation. For each slice name the objective, dependencies, expected change or artifact, and the verification/checkpoint that can justify continuing.
- After each slice, run the relevant available validation and perform an internal continuation check against current task/run/contract authority, observed evidence, remaining dependencies, and blocker scope. This is not approval and must never substitute for a human, owner, reviewer, accepted-risk, destructive, irreversible, or security decision.
- Continue automatically across remaining authorized independent slices when the current authority and evidence still support them. A discovered blocker stops only the affected slice and work that actually depends on it unless every remaining safe slice is transitively blocked.
- When practical, compare failing validation with known baseline evidence and distinguish `PRE_EXISTING`, `INTRODUCED`, and `UNKNOWN_ORIGIN`. Do not attribute an old failure to the current slice or stop unrelated authorized work merely because a baseline gate was already red; unresolved required gates still prevent final success.
- A handoff described as production-ready must not delegate execution when current authoritative evidence already proves a required hard prerequisite is missing, the worker is not authorized to satisfy it, and execution depends on it. Render that handoff `NOT_READY_TO_DELEGATE` with the prerequisite, owner, verification probe, and current evidence instead of spending an execution run to rediscover it.
- Treat executor completion prose as a claim. Before final success, reconcile it with available authoritative artifacts and evidence such as actual head/base/diff, changed files or artifacts, validation results, review findings, and remaining blockers; real evidence wins on disagreement.
- The L2 pass ends after producing the project-specific L1 prompt. Do not implement the task during prompt construction.

### todo-card-handoff (L2)
- **Source**: /workspace/scratch/dotfiles-mission/loop-runtime/vendor/voku/agent-recall-compiler/resources/skills/agent-recall-consumer/operating-prompts.json#todo-card-handoff

Create a project-specific durable work-package planning prompt that turns the current task and repository evidence into self-contained TODO or work cards for a coding agent that has no access to the current chat, Session-private context, hidden reasoning, or prior agent memory. Use the repository's existing durable task/card format and owner from recall context; if that authority is missing or conflicting, return BLOCKED instead of inventing a new task system. Treat the generated cards as work-package candidates, not approved Contract/Run authority, and do not persist or mutate them except through the owning task/Kanban workflow. Each card must stand on its own and record the intended outcome, why it matters, VERIFIED current state and already-completed work, exact repository anchors needed to resume such as files, symbols, issues, pull requests, commits, contracts, runs, or artifacts, scope and non-goals, bounded milestones/slices, dependencies and ordering, the smallest concrete next implementation steps, exact repository-supported verification commands or evidence probes, observable acceptance criteria and Done When, and remaining blockers or UNKNOWNs. Keep durable content portable and environment-agnostic where practical: reference authoritative artifacts instead of copying whole histories, and do not persist transient host availability, giant environment snapshots, secrets, tokens, credentials, or speculative future-VM facts. Replace conversational references such as 'as discussed above', 'continue from here', or 'we already found' with durable evidence a fresh agent can resolve. Keep VERIFIED facts separate from INFERRED or UNKNOWN claims. Preserve package and workflow owner boundaries, and reference existing upstream work instead of duplicating it. Update an existing matching card when one already owns the work; create a new card only for independently executable work with a distinct outcome or an explicit dependency. Do not manufacture backlog, decisions, commands, paths, or architecture merely to make the handoff look complete. Do not manufacture cards merely to consume a future-work budget. The generated prompt must leave enough concrete context that the next coding agent can begin with bounded verification rather than rediscovering the entire history; final host-specific execution belongs in a later explicit dispatch step.