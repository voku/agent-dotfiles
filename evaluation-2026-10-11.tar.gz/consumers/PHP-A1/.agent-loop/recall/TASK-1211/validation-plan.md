# Validation Plan

## Required Validation

### Task Validation

```bash
/workspace/.cloud-setup/bin/php vendor/bin/phpunit tests/Dogfood/SelfShapeEvidenceTest.php
```

## Guidance: proposal.2026-08-14.001
- vendor/bin/phpunit --filter ProjectLayoutOwnershipTest
- vendor/bin/phpunit --filter MapSearchIndexOwnershipTest

## Guidance: proposal.2026-08-14.c969ec
- vendor/bin/phpunit --filter RealIssueEvidenceToolBoundaryTest
