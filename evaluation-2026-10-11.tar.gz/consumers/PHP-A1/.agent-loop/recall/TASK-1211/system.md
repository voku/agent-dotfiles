# L2 Meta-Prompt Briefing for Task: TASK-1211
> Recall bundle SHA-256: 71a1899ac67b5cea768350812dca5c3e9554576bb416f1e61b735982662ace0f

## Task Description
Complete bounded actual PHP maintenance S0 for agent-loop#761: exact real acceptance-case reproduction, owner/caller/API investigation, meaningful regression evidence and safe next slice; only implement a complete owner-correct fix if feasible.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tools/Dogfood`
- File/path: `tests/Dogfood`
- File/path: `docs`
- Scope: `tools/Dogfood`
- Scope: `tests/Dogfood`
- Scope: `docs`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Reproduce actual#758classificationerror, distinguish existingreviewedmaintenance from unreviewedpromotion, identify ownerpublicAPIs and consumers, preserve failclosedinvariants, document and validate owner-correct nextslice with actualPHPchecks and independentreview.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No ownerprivateJSON/Markdown parser bypass, inventedsemanticapproval/Finding, runtime/vendor changes, duplicateproductionmerge, oracle/otherarm access or claimS0meansfullissueclosed.

## Repository Global Memory (`MEMORY.md`)
# Repository memory

This file contains reviewed, durable rules for `voku/agent-loop`. Raw observations belong in `.agent-loop/learning/findings/`; repeatable behavior belongs in tests, dogfood runners, or static rules. A row here is deliberately short because memory is an index into executable truth, not a replacement for it.

## Durable repository rules

| Subject | Durable rule | Canonical home |
| --- | --- | --- |
| Internal package boundaries | Workflow orchestration calls focused-package typed PHP APIs when they exist. User-facing package CLI delegation stays at the Dispatcher boundary; do not reconstruct focused-package argv inside `voku\\AgentLoop\\Workflow`. | `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php` and workflow tests |
| Workflow session invariant | Governed workflow orchestration has at most one active session per task. Start/plan may reuse that session; if more than one active session already exists, fail before further task work. Retries after partial failure must not allocate another active session. | `WorkflowStartCommand`, `WorkflowPlanCommand`, and workflow tests |
| Dogfood entrypoints | Repository self-dogfood executes `php bin/agent-loop`; installed-consumer dogfood separately proves `vendor/bin/agent-loop`. They are different packaging contracts and both remain covered. | `tools/self-shape-dogfood.php` and `tools/release-set-dogfood.php` |
| Pull-request dogfood credentials | A PR self-shape job needs repository history, not write access. Keep its `GITHUB_TOKEN` at `contents: read` and use checkout with `persist-credentials: false` so PR-controlled code does not inherit a persisted repository credential. | `.github/workflows/ci.yml` and `.agent-loop/learning/findings/validated/finding.2026-08-07.007.json` |
| Self-review close-out | An exploratory blind-spot review may warn while work is open. Before close, run `recall log-outcome` and record a checkpoint that evidences both outcome close-out and `review blindspots`. `workflow close` owns the gate: it refuses a missing, invalid or `fail` report and admits a `warn`, because advisory findings such as `security_sensitive_context` fire on any diff that mentions security terms and cannot be resolved by working harder. CLI exit 0 alone is not sufficient evidence, so the residual status is recorded as close-out evidence rather than inferred from the exit code. | `WorkflowCloseCommand::checkReviewGate()`, `tests/WorkflowCloseCommandTest.php`, and `tools/self-shape-dogfood.php` |
| Tooling test isolation | Project-specific PHPStan rule fixtures run in a separate PHPStan process. Do not load `PHPStan\\Testing\\RuleTestCase` into agent-loop's normal PHPUnit process while `agent-map` also performs Composer-based PHPStan discovery there. | `phpstan/Rules/NoInProcessPhpstanRuleTestCaseRule.php` and `tools/project-phpstan-rules.php` |
| Git repository detection | Repository state is asked of Git, never inferred from the shape of `.git`. A linked worktree stores `.git` as a file, which silently turned `init doctor` and `init sync-githooks` into no-ops for a valid checkout. | `phpstan/Rules/NoGitDirectoryShapeAssumptionRule.php`, `src/GitWorkTree.php`, and `tests/GitWorkTreeDetectionTest.php` |
| CI ownership | GitHub Actions executes the repository dogfood runner; it does not duplicate the governed lifecycle or maintain a second hard-coded changed-file list. The runner derives PR scope from Git. | `tools/self-shape-dogfood.php` and `.github/workflows/ci.yml` |
| Learning decision consistency | The self-shape learning decision follows the durable evidence in the actual PR diff. If project findings or `MEMORY.md` are changed, record `findings_recorded`; otherwise record `no_durable_learning`. Do not close with a learning state that contradicts the repository evidence produced by the task. | `tools/self-shape-dogfood.php` and `.agent-loop/learning/findings/validated/finding.2026-08-07.006.json` |
| Derived state paths | A repository-local derived path has one owner for reading *and* writing. `ProjectLayout::mapSearchIndex()` was read by `workflow approve` and written by nothing, so ranked map evidence silently never reached the governed context. When a decisive-evidence channel is unavailable, the workflow says so rather than compiling a quietly narrower context. | `src/Dispatcher.php`, `tests/MapSearchIndexOwnershipTest.php`, and `tests/WorkflowApproveSearchIndexEvidenceTest.php` |
| Memory follows executable truth | When a `MEMORY.md` row and its named canonical home disagree, correct the row towards what the code enforces; do not add a second enforcement point to make the prose true. | `.agent-loop/learning/findings/validated/finding.2026-08-14.007.json` and `docs/dogfood/2026-08-14-second-learning-pass.md` |
| Blind-spot review of a diff | Read a change for what it removed, not only for what it added. An invariant that held by construction needs an explicit assertion once its construction changes; a random source is injected rather than sampled by a test; a process call is not a drop-in for a filesystem check, because it can fail in ways that print. | `.agent-loop/learning/findings/consolidated/finding.2026-08-14.015.json` and `src/GitWorkTree.php` |
| Runtime dependency boundary | A package cannot be dev-only while a class `agent-loop` publishes depends on it: `ArchitectureRules` ships in `src/` and implements `ItpContext\\Contract\\RuleIdentifier`, so anything reflecting over production classes fatals without it. Loading a shipped class is not the same as running a command, so a CLI smoke test cannot decide a dependency boundary. | `tests/RealIssueEvidenceToolBoundaryTest.php` and `docs/dogfood/real-issue-acceptance.md` |
| Governed context evidence conservation | When decisive evidence is missing from a governed context, first establish where it was lost along map discovery, Recall selection and context projection. Widening search, changing ranking or raising the context budget is a last resort and must be recorded in the frozen replay. | `tests/FrozenReplayEvidenceChainTest.php` and `tests/WorkflowApproveSearchIndexEvidenceTest.php` |
| Learning evidence detection | Detect learning evidence by finding identity across every findings state directory, not by the directory a finding currently occupies. A `MEMORY.md` change with no finding evidence fails the gate rather than selecting a status around it. | `tools/self-shape-dogfood.php` and its tests |
| Tool-coupled instruction assets | Machine-readable instruction assets coupled to a tool's CLI, schema or output contract ship from the repository that owns the tool and are tested with it. A general skill collection may reference or install tool-owned assets but must not keep a second canonical copy. | `resources/prompts/operating-prompts.json` and `.agent-loop/learning/findings/consolidated/finding.2026-08-14.005.json` |
| Host guidance ownership | `init install-assets` projects first-party package assets. A project that declares `package_skills=false` and its own `paths.skills_root` projects that root through `sync-skills`, so it does not acquire a competing package copy of the same rule. | `resources/skills/agent-guidance-maintenance/SKILL.md`, `InitMultiSkillSourceTest.php`, and `docs/contributing/repository-layout.md` |
| Lifecycle routing | A router may select the smallest relevant specialist, but only the current `enter`/`finish` result selects governed lifecycle work; it must not invent task-start, Recall, repair, Learning, review, or close phases. | `resources/instructions/project-instructions.md`, `resources/skills/agent-loop-workflow/SKILL.md`, and `HostLifecycleGuidanceAuthorityTest.php` |
| Dogfood runners are orchestration only | Runners orchestrate; every decision they make lives in a tested class under `src/Dogfood/`. Convert a shell runner for testability rather than portability - Git for Windows ships bash. A static rule carries the scope it was earned in: `-n` belongs to validation subprocesses, not to invoking our own CLI, which needs the extensions `php.ini` loads. | `src/Dogfood/SelfShapeEvidence.php` and `tests/SelfShapeEvidenceTest.php` |
| Learning promotion | Findings are evidence, not durable memory. Promote only reviewed lessons; when a rule is objectively detectable, back the memory entry with a test, dogfood gate, or static-analysis rule. | `docs/workflow/learning-boundary.md` and `.agent-loop/learning/` |

## Archived task learning

| Archived on | Task | Summary | Archive reason | Durable lesson candidate | Promoted to |
| --- | --- | --- | --- | --- | --- |
| 2026-08-07 | `SELF-SHAPE` / PR #28 | Shaped workflow/session boundaries while `agent-loop` governed and reviewed its own change, then incorporated independent security and data-integrity review findings. | The task-specific evidence is captured by validated findings and CI artifacts; only stable rules belong above. | Prefer typed package APIs for internal orchestration, preserve one active session per governed task, keep PR dogfood credentials read-only/non-persistent, keep repository and consumer dogfood entrypoints distinct, isolate tooling tests, make final self-review evidence-complete with machine-readable status `ok`, and keep the learning decision consistent with the durable evidence actually produced. | `MEMORY.md`; `docs/dogfood/self-shaping.md`; `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php`; workflow tests; `.github/workflows/ci.yml`; `tools/project-phpstan-rules.php`; `tools/self-shape-dogfood.php` |

## Scoped Project Documents
### ADR: adr.agent-loop-pre-1.0-compatibility
- **Source**: policies/pre-1.0-compatibility.md
````text
# Pre-1.0 compatibility policy

Status: accepted project-wide policy for the current `agent-loop` release line.

`agent-loop` and its first-party `agent-*` packages are still before 1.0. Backward
compatibility is therefore not the default goal when it would preserve duplicate
ownership, a false-green path, or a legacy layer that exists only for another
first-party package in the same coordinated release set.

For an affected first-party contract:

1. identify the owning package and every in-scope first-party consumer;
2. prefer changing the owner and consumers together, updating dependency
   constraints, and deleting the obsolete path;
3. prove the coordinated migration through package tests and the installed
   release-set gate;
4. accept an alias, adapter, fallback, dual-read, or legacy layer only when a
   verified external consumer or an explicit compatibility promise requires it.

Breaking change is not permission for speculative redesign. The change must
remove a demonstrated contradiction, defect, duplicate rule, or wrong ownership
boundary. Historical evidence remains readable, and unrelated public contracts
remain out of scope.

If a narrower directory or module policy conflicts with this project-wide
default, stop and surface the conflict instead of guessing which contract wins.
````

### Skill: skill.agent-loop-self-shaping
- **Source**: dogfood/self-shaping.md
- **Excerpt**: deterministically truncated by the Git-tracked manifest.
````text
# Self-shaping dogfood

`agent-loop` should be able to govern changes to `agent-loop` without inventing a privileged shortcut for its own repository.

The repository therefore keeps a first-party self-shaping scenario that runs the same public workflow used by consumers, while preserving the one packaging distinction that cannot be identical: the root checkout invokes `php bin/agent-loop`, whereas the installed-consumer gate invokes `vendor/bin/agent-loop`.

The self-shape job also contains one deliberately narrower preflight: `tools/self-edit-dogfood.php` creates an isolated linked Git worktree and lets `agent-loop edit --runner=mechanical` change a tiny tracked fixture in its own repository. The probe then requires Git-observed `changed_files` evidence for exactly that fixture and proves that no external model was invoked. The worktree is discarded afterward; the PR checkout is never mechanically rewritten by CI.

That distinction matters. The normal self-shape lifecycle governs the real PR diff. The self-edit probe separately proves that the product can actually execute and observe one edit against itself rather than merely review a diff produced by something else.

The self-shape lifecycle is intentionally observational. It may exercise a transition, generate review input, and preserve evidence, but it must not upgrade those actions into stronger claims than the evidence supports. In particular, CI cannot manufacture independent human approval or an independent correctness review merely because the corresponding workflow transition exists.

## Evidence chain

The validated source findings live under `.agent-loop/learning/findings/validated/`:

- `finding.2026-08-07.001`: internal workflow orchestration through focused-package CLIs duplicated argv, path, default, and failure knowledge that typed package APIs already owned;
- `finding.2026-08-07.002`: repository-under-development and installed-consumer execution have different binary entrypoints and must be tested separately;
- `finding.2026-08-07.003`: final blind-spot acceptance requires complete close-out evidence and machine-readable status `ok`; process exit success alone may still represent `warn`;
- `finding.2026-08-07.004`: GitHub Actions executes the local self-shape runner; the runner owns the lifecycle and derives the changed-file scope from Git so PLAN and REPORT share one source of truth;
- `finding.2026-08-07.005`: project-specific PHPStan rules must be tested in an isolated PHPStan process because loading `PHPStan\\Testing\\RuleTestCase` into normal PHPUnit polluted the runtime used by agent-map's Composer-based PHPStan discovery;
- `finding.2026-08-07.006`: the self-shape learning decision must agree with durable evidence in the real PR diff, using `findings_recorded` when findings or `MEMORY.md` are changed and `no_durable_learning` otherwise;
- `finding.2026-08-07.007`: pull-request self-dogfood needs repository history but no write credential, so its token is read-only and checkout credentials are not persisted into the PR-controlled workspace;
- `finding.2026-08-07.008`: workflow session creation/resume preserves one active session per task; restart reuses the active session and an already-corrupt multi-active state fails before further task work;
- `finding.2026-08-08.001`: linked Git worktrees store `.git` as a file; edit evidence must ask Git rather than infer repository validity from metadata shape, and self-edit dogfood now proves the real mechanical edit path in an isolated worktree;
- `finding.2026-08-08.002`: self-dogfood evidence must be observational rather than ceremonial: real PR intent and changed scope, measured validation duration, explicit approval-fixture semantics, lossless raw-diff evidence, and a boundary between generated review input and independent correctness judgment;
- `finding.2026-08-08.003`: an upstream source recheck is not an adaptation audit; mechanism-level ALREADY/ADAPT/DEFER/REJECT mapping plus concrete local ownership/evidence is required before claiming external coding-agent ideas are represented.

`MEMORY.md` contains only the reviewed durable rules. Objective recurrence prevention is pushed lower where possible:

- `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php` prevents `voku\\AgentLoop\\Workflow` from instantiating focused-package CLIs;
- `tools/project-phpstan-rules.php` proves that rule in a separate PHPStan process without contaminating PHPUnit;
- workflow PHPUnit tests assert persisted session, brief, approval, verification, close behavior, and the one-active-session retry invariant instead of adapter argv;
- `WorkingTreeSnapshotter` asks Git whether a path is a working tree instead of assuming `.git` must be a directory, so linked worktrees retain observed-diff evidence;
- `tools/self-edit-dogfood.php` performs one deterministic mechanical edit in an isolated linked worktree and verifies the observed edit evidence;
- `tools/self-shape-dogfood.php` owns the repeatable repository lifecycle, derives changed-file scope from Git, records the real PR goal when CI provides it, preserves a complete raw diff, measures validation duration, and separates generated review input from external correctness review;
- `.github/workflows/ci.yml` runs the isolated self-edit probe and then the normal self-shape runner with read-only/non-persisted repository credentials, passing only PR metadata already present in the event payload and uploading the evidence rather than granting either step write access;
- `tools/release-set-dogfood.php` remains the separate installed-consumer contract.

## Self-edit preflight

The self-edit probe intentionally does less than the governed lifecycle and more than a unit test:

1. create a detached linked worktree at the PR `HEAD`;
2. expose the already-installed Composer dependency tree without installing a second package set;
3. invoke the real `agent-loop edit` command against `SelfEditProbe::value`;
4. route through the mechanical runner with one exact replacement;
5. require PHP lint success from the runner;
6. require `agent-result.json` to report `changed_files_source=git_status_diff`;
7. require exactly `tests/fixtures/self-shape/SelfEditProbe.php` as the observed changed file;
8. require the execution artifact to prove the mechanical runner was used with zero model tokens/tool calls and `external_model_invoked=false`;
9. copy bounded JSON evidence into `build/` and delete the worktree.

It does not run `edit verify`: verifier-owned knowledge answers must not be copied from the private key merely to make a self-test green. The installed release-set work tracks full mechanical edit verification separately. Self-dogfood is not an excuse to let the product grade its own answers.

## Pull-request input contract

The GitHub Actions wrapper passes three pieces of event metadata into the runner:

- `SELF_SHAPE_GOAL`: the pull-request title;
- `SELF_SHAPE_APPROVER`: the pull-request author login;
- `SELF_SHAPE_PR_NUMBER`: the pull-request number.

They are passed as data, never evaluated as shell code. The runner also accepts explicit `--goal=`, `--approver=`, and `--pr-number=` overrides for local dogfood.

`build/self-shape-input.json` records the resulting goal, planner identity, approval fixture identity, base/head commits, changed files, and raw-diff path. Its approval section deliberately contains:

```json
{
  "evidence_kind": "ci_pr_author_fixture",
  "independent_human_review": false
}
```

The workflow still exercises its APPROVE transition because the gate mechanics themselves are part of the dogfood contract. The PR author identity is a harness fixture for that transition, not evidence that a separate human reviewed and approved the generated Contract revision. Actual review/merge policy remains outside that claim.

The planner and approval fixture must be different identities. A self-shape run that tries to use the planner as its own approver fails before PLAN.

## Lossless review evidence

The workflow skills tell agents to keep raw evidence lossless even when human-facing review context is bounded. Self-shape now proves that split directly:

- `build/self-shape-raw.diff` is the complete `git diff --no-ext-diff --binary <base> HEAD --` output;
- `review code SELF-SHAPE` generates the bounded L2 code-review prompt from workflow/recall artifacts;
- `build/self-shape-review-evidence.json` stores SHA-256 hashes for both artifacts;
- the same evidence JSON records `correctness_review.status=external_required`.

Generating a review prompt is not the same event as performing an independent correctness review. CI therefore preserves the complete input and identifies the missing external judgment instead of converting “prompt exists” into “review passed”. Pull-request review remains a separate merge input.

## Self-shape lifecycle

The runner performs this sequence against the real diff from the merge-base to `HEAD`:

1. validate the repository-owned `agent-learning` root;
2. derive the actual changed files and the matching learning decision from Git;
3. preserve the complete raw Git diff before any summary or bounded prompt is generated;
4. persist `self-shape-input.json` with base/head, real PR goal when available, changed files, planner, and approval-fixture boundary;
5. PLAN the actual changed files with explicit goal, non-goal, base commit, validation contract, and behavior anchor;
6. APPROVE with the distinct CI approval fixture and checkpoint that this exercises mechanics rather than proving independent human review;
7. render bounded context;
8. run `composer ci`, measure elapsed wall-clock milliseconds, and record that observed duration with the validation result;
9. run an exploratory deterministic blind-spot review;
10. run `recall log-outcome`;
11. record a checkpoint explicitly evidencing both `log-outcome` and `review blindspots` close-out;
12. record `findings_recorded` or `no_durable_learning` according to the durable evidence in the diff;
13. run the final blind-spot review and require its JSON report status to be exactly `ok`;
14. generate the L2 code-review prompt, hash it together with the complete raw diff, and explicitly leave correctness review as `external_required`;
15. review `MEMORY.md` promotion state;
16. persist the manifest, run `agent-loop verify`, and render the completion report;
17. CLOSE through the current deterministic workflow gates, persist final status, and require the final projection to be `complete` with `next_action=none`, session `done`, review `ok`, and the expected learning state.

The initial review may warn while the lifecycle is incomplete. The final deterministic blind-spot review may not. The CLI exit code is not the semantic gate because `warn` can still be a successfully executed review command; the runner reads `SELF-SHAPE.blindspots.json` and accepts only `status=ok`. Likewise, successful `workflow close` is not enough by itself: the persisted final projection is checked as machine-readable evidence before the dogfood run prints `PASSED`.

The deterministic close currently models the gates the product can verify itself. `self-shape-review-evidence.json` prevents that deterministic completion from being misreported as an independent correctness approval. The separate pull-request review/merge decision remains intentionally outside the self-issued evidence chain.

The CI wrapper is deliberately less privileged than the code it tests: the pull-request self-shape job declares `contents: read` and checks out with `persist-credentials: false`. Neither the self-edit probe nor the lifecycle runner needs a repository write credential. The linked worktree is local process state, not a hidden push path.

## Promotion rule

Do not automatically turn every self-run observation into memory. The project follows the normal learning boundary:

```text
runtime observation
  -> candidate / validated finding
  -> human-reviewed durable memory or guidance
  -> executable test / dogfood /
[truncated by document manifest]
````

## Selected Active Guidance
### Guidance: proposal.2026-08-14.001
- **Target**: Derived state paths
- **Scope**: src/ProjectLayout.php, src/Dispatcher.php, docs/compact-layout.md
- **Boundary**: Applies to repository-local workflow and derived state. It does not apply to source, vendor, or paths a focused package CLI is explicitly asked to use.

#### Directive:
```text
A repository-local derived path has one owner for reading and writing. Where an upstream package hardcodes a path we cannot redirect, name the exception in docs/compact-layout.md rather than letting the mapping claim completeness.
```

### Guidance: proposal.2026-08-14.c969ec
- **Target**: Runtime dependency boundary
- **Scope**: composer.json, docs/agents/dogfood/real-issue-acceptance.md
- **Boundary**: Applies to dependencies reachable from published classes. Genuinely external tools installed from their own Composer project, such as slop-scan, are unaffected.

#### Directive:
```text
A package cannot be dev-only while a class agent-loop publishes depends on it. Loading a shipped class is not the same as running a command, so a CLI smoke test cannot decide a dependency boundary. When a follow-up names two possible wrong sides, falsify the cheaper one before changing it.
```

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### constraint.agent-loop.phpstan.in-process-rule-test-case
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap
- **Source**: proposal.2026-09-13.2acd04

### constraint.workflow.recovery.next-action-must-advance
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap
- **Source**: proposal.2026-08-20.c2a001

### proposal.2026-08-14.001
- **State**: VERIFIED
- **Selected**: yes
- **Why**: RecallDecisionEngine selected this guidance: scope_overlap.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: active_guidance

### proposal.2026-08-14.003
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.007
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.011
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.013
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: canonical_home_loaded

### proposal.2026-08-14.015
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.c969ec
- **State**: VERIFIED
- **Selected**: yes
- **Why**: RecallDecisionEngine selected this guidance: scope_overlap.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: active_guidance

### proposal.2026-08-14.d7d793
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-20.c2a001
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-09-13.2acd04
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### PHP runtime constraint ^8.3
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The supported runtime constrains valid implementation syntax and dependencies.
- **How**: Read directly from composer.json require.php.
- **Authority**: project_metadata
- **Use**: implementation_constraint
- **Source**: /workspace/scratch/evaluation-12/PHP-A1/composer.json

### docs/policies/pre-1.0-compatibility.md
- **State**: VERIFIED
- **Selected**: yes
- **Why**: project-wide document policy
- **How**: ScopedDocumentRecallProvider selection using path scope, task tags, or project-wide policy.
- **Authority**: project_adr
- **Use**: architecture_constraint
- **Source**: docs/policies/pre-1.0-compatibility.md

### docs/dogfood/self-shaping.md
- **State**: VERIFIED
- **Selected**: yes
- **Why**: scope overlap with tools/Dogfood
- **How**: ScopedDocumentRecallProvider selection using path scope, task tags, or project-wide policy.
- **Authority**: project_skill
- **Use**: project_instruction
- **Source**: docs/dogfood/self-shaping.md

### Omitted Project Capabilities
- **Omitted from runtime context**: 36
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 15
- **configuration_anchor**: 3
- **repository_command**: 15
- **tool_presence**: 3