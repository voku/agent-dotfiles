`init scaffold` exits successfully but its fresh Learning directory is rejected by the Learning owner before any Finding exists. This blocked a fresh maintenance consumer in the agent-dotfiles three-way evaluation; do not weaken owner validation or fabricate Learning records to bypass it.

Independently reproduced with agent-loop source `97e41c72539b95abf9636b25f551c20da683fbef`, PHP 8.4.26 and its locked dependencies, as well as frozen workflow runtime `15507c3a313693eed45e2b1c98eda9c3aae7a7ef`.

In a fresh empty project, using the pinned Loop absolute executable:

```sh
agent-loop init scaffold
agent-loop learn validate --root .agent-loop/learning
```

The first command exits 0 and creates `.agent-loop/learning/`; the second reports `directory is not an agent-learning root`. Creating only the empty `.agent-loop/learning/findings/` directory makes owner validation succeed with zero Findings/Proposals. Existing LearningRootResolver recognizes that minimum storage; no existing record is required.

Smallest owner follow-up: initialize owner-recognizable storage through the existing Learning API if available; cover canonical scaffold -> owner validate -> first run-bound Finding capture on an empty project. Preserve optional host/board behavior and do not accept arbitrary empty directories in the owner resolver. The evaluation uses a disclosed explicit preflight correction, not a product fix. No Loop implementation is included in this issue.

Source receipts and final experiment report will be linked from agent-dotfiles #12 / PR #16. This is a measured bootstrap gap, separate from self-shape semantic approval issue #761.
