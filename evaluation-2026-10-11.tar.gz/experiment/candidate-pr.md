The current shared profiles fail ShellCheck, and Linux activation tests can skip Zsh. This change validates the existing root dotfiles layout on Linux, removes an unused Zsh expression, and keeps narrowly explained annotations for shell-specific builtins. It salvages the useful validation from conflicting PR #14 without adopting its alternative layout.

The first three fresh agent-loop maintenance consumers completed the same seeded source-digest repair correctly. The profile consumer performed an avoidable broad search that truncated before the already-known implementation. Add selective, scoped retrieval guidance and preserve the cross-range digest regression; main already hashes the correct whole-file bytes. No productivity improvement is claimed.

Local validation: 87 Python tests, compileall, 9 Bashunit tests/20 assertions, ShellCheck0.10.0, Bash/Zsh syntax, and seven actual activation contracts requiring Zsh pass. Independent review passed. GitHub validation and second fresh held-out consumers remain pending; final evaluation evidence will be added before completion.

Tracks #12.
