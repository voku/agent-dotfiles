#!/usr/bin/env python3
"""Independent external source-range oracle: no use of implementation internals."""
import hashlib,json,pathlib,subprocess,sys,tempfile
cli=pathlib.Path(sys.argv[1]).resolve()/'bin/agent-dotfiles'
round_name=sys.argv[2] if len(sys.argv)>2 else 'all'
cases=[]
if round_name in ('round1','all'):
 cases += [('ordinary.php', b'<?php\nfunction first() {}\nfunction second() {}\n',2,2,b'function first() {}\n',3,2),('crlf.php', b'<?php\r\n// selected\r\n// tail',2,2,b'// selected\r\n',3,2),('empty.php',b'',1,1,b'',0,0),('unterminated.php',b'one\ntwo',2,2,b'two',2,2)]
if round_name in ('round2','all'):
 cases += [('unicode.php','<?php\n// keep\u2028this\u2029and\x85that\nreturn 42;\n'.encode(),2,2,'// keep\u2028this\u2029and\x85that\n'.encode(),3,2),('cronly.php',b'<?php\n// x\rstill same line\nreturn 7;',2,2,b'// x\rstill same line\n',3,2),('formfeed.php',b'first\nsecond\x0cstill second\nthird\n',2,2,b'second\x0cstill second\n',3,2)]
results=[]
with tempfile.TemporaryDirectory(prefix='external-read-oracle-') as d:
 for name,raw,start,end,expected,total,actual in cases:
  pathlib.Path(d,name).write_bytes(raw)
  p=subprocess.run([str(cli),'read','--root',d,name,'--start',str(start),'--end',str(end)],capture_output=True,text=True)
  failures=[]
  try:
   obj=json.loads(p.stdout)
   for key,value in [('sha256',hashlib.sha256(raw).hexdigest()),('content',expected.decode()),('content_bytes',len(expected)),('total_lines',total),('actual_end',actual),('truncated',False)]:
    if obj.get(key)!=value: failures.append(key)
   if p.returncode:failures.append('exit')
  except Exception as e:failures.append(type(e).__name__)
  results.append({'case':name,'passed':not failures,'failures':failures})
print(json.dumps({'results':results,'passed':all(x['passed'] for x in results)},indent=2))
sys.exit(0 if all(x['passed'] for x in results) else 1)
