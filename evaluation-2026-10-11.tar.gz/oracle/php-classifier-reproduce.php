<?php
declare(strict_types=1);
require $argv[1] . '/tools/Dogfood/SelfShapeEvidence.php';
$input = json_decode(file_get_contents(__DIR__ . '/php-reproduction-input.json'), true, flags: JSON_THROW_ON_ERROR);
$evidence = new \voku\AgentLoop\Dogfood\SelfShapeEvidence($input['findings_changed'], $input['memory_changed']);
try { echo $evidence->learningStatus() . PHP_EOL; } catch (RuntimeException $e) { fwrite(STDERR, $e->getMessage() . PHP_EOL); exit(1); }
