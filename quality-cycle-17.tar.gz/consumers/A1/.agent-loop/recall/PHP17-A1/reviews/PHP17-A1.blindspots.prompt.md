# L2 blind-spot analysis prompt for PHP17-A1

## Presentation

Write the final review in language en. Translate explanatory headings and prose; preserve exact source text, identifiers, paths, citations, and required machine-readable status tokens.

## First-draft falsification lens

Treat the current implementation as a first draft, even if produced by you or paired with a confident rationale.

Review for falsification rather than confirmation. Try to prove concrete failures against requirements, acceptance criteria, constraints, non-goals, current source, tests, static analysis, and safe runtime evidence.

Acceptance criteria are required outcomes, not evidence they are satisfied. Prior reasoning, model confidence, reviewer consensus, prompt construction, and unexecuted commands are not verification.

Treat every LLM-produced statement as a candidate claim, not repository truth. Re-ground material claims against current authoritative artifacts or deterministic evidence before acting. A detailed patch is not evidence that the described classes, boundaries, bugs, or metrics actually exist. If model output conflicts with current authoritative artifacts, the artifacts win. Reproduce a finding before fixing it. Review findings are investigation candidates, not instructions to modify code.

Classify material conclusions as VERIFIED, INFERRED, ASSUMED, BLOCKED, or CONTRADICTED. If needed evidence is unavailable, keep it UNKNOWN or BLOCKED.

Separate required fixes from optional improvements. Do not manufacture findings. CLEAN is valid only after concrete attempts to falsify the implementation found no evidence-backed defect.

## Repo-first blind-spot lens

Act as an evidence-based technical blind-spot critic, not an approval authority.

Start repo-first. From supplied artifacts derive the intended outcome, constraints/non-goals, affected surfaces, assumptions, success/failure evidence, and material unknowns. Do not invent missing context.

Before new hypotheses, audit the supplied results, including your own prior conclusions. Treat them as candidate claims, not as evidence merely because you produced them. Re-ground material conclusions against primary artifacts; call out contradictions, omitted evidence, or unsupported causal attribution.

Run these bounded probes:
1. Pattern drift: compare at least two relevant in-repository examples before claiming a structural or ownership violation; otherwise report the evidence gap.
2. Intent erosion: check whether strict contracts, metadata, acceptance criteria, or non-goals were weakened merely to make the implementation fit.
3. Operational overconfidence: treat workflow, deployment, migration, generated metadata, and irreversible side effects as high-risk until evidenced.
4. False failure attribution: a missing dependency, generated asset, tool, or environment prerequisite is not a product defect until setup readiness is established.
5. Premature closure: verify that outcome, impacted surfaces, validation evidence, and close claim line up.

Across repository or package boundaries, trace the semantic owner, authoritative input, crossing artifact and retained identity to the consumer. Do not infer ownership from names or documentation alone.

Prefer the smallest discriminating dogfood experiment over speculation. Use only environments relevant to the hypothesis: source checkout; clean installed/released consumer or cross-package release set; repeat/resume; or no-change. For historical replay, freeze base state/input and do not leak the known fix; starting with the answer cannot prove discovery quality. No-change is a valid outcome.

For every material blind spot, classify the claim with the existing epistemic status and cite supporting or contradicting evidence. State the hidden assumption and concrete failure chain, earliest observable signal, smallest falsification probe, and why existing tests or gates did not expose it. Name a corrective action only after the claim becomes VERIFIED.

Use adversarial pre-mortem reasoning only as a hypothesis generator. A plausible failure story, model confidence, numeric score, imagined future, repeated self-refinement, or successful mechanism execution is not evidence. Do not manufacture findings to satisfy a quota.

If required repository or runtime evidence is unavailable, keep the claim UNKNOWN or BLOCKED and name the missing evidence. READY FOR HUMAN CLOSE is valid only when bounded probes found no evidence-backed blocker and supplied validation/close evidence is coherent.

You are reviewing recall-compiler workflow artifacts. Use only the artifacts below as evidence.
Expose missing validation, missing outcome logging, mismatched selected guidance, unsafe assumptions, and handoff gaps. Do not approve code or durable learning.

## Deterministic preflight findings

- [INFO] no_findings: No deterministic findings were produced.

## Output contract

Return Markdown with headings: Summary, Critical blind spots, Evidence, Required next action, Close readiness.
For each material claim, give its epistemic status and the concrete artifact/evidence that supports or contradicts it.
Review findings are investigation candidates, not instructions to modify code.
Close readiness must be BLOCKED, NEEDS HUMAN REVIEW, or READY FOR HUMAN CLOSE.

## Artifacts

### .agent-loop/recall/PHP17-A1/meta.json

```text
{
    "schema_version": "1.0",
    "compilation_id": "compilation.PHP17-A1.2026-10-11-124443.82170bbe",
    "task_id": "PHP17-A1",
    "task_files": [
        "src/Init/InitToolsCommand.php",
        "tests/InitToolsCommandTest.php"
    ],
    "task_targets": [],
    "bundle_sha256": "4907c70f35f819cba1ff7eaaf749ad2da98d1a21a692ce256551ba65f56c4cba",
    "snapshot_sha256": "f7b39732c53d1fbb328d319ef8905ac040ca0ab957d864696ad4f9cad2b7f79f",
    "blocked": false,
    "block_reason": null,
    "selected_guidance": [],
    "evaluated_guidance": [
        {
            "guidance_id": "constraint.agent-loop.phpstan.in-process-rule-test-case",
            "guidance_type": "constraint",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": [],
            "source_proposal": "proposal.2026-09-13.2acd04"
        },
        {
            "guidance_id": "constraint.workflow.recovery.next-action-must-advance",
            "guidance_type": "constraint",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": [],
            "source_proposal": "proposal.2026-08-20.c2a001"
        },
        {
            "guidance_id": "proposal.2026-08-14.001",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.003",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.007",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.011",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.013",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.015",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.c969ec",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-14.d7d793",
            "guidance_type": "memory",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-08-20.c2a001",
            "guidance_type": "constraint",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        },
        {
            "guidance_id": "proposal.2026-09-13.2acd04",
            "guidance_type": "constraint",
            "eligible": false,
            "selected": false,
            "selection_reason": null,
            "exclusion_reason": "no_scope_overlap",
            "task_files": []
        }
    ],
    "selected_constraints": [],
    "selected_rejections": [],
    "outcome_stats": [],
    "warnings": [],
    "output_hashes": {
        "system.md": "9e4df4fda995519cea979949a56fa63b2776f047c6be4de06bbfb2f6183c7d01",
        "validation-plan.md": "5b6bba010539dec535d3c650929bfe08186579945b9090a92bc5eab8e4dd4cdc",
        "recall.bundle.json": "9f53b8e4b7a6204df7eea3a65e9bda166b9291a6d8691ed55046b906affc2fc6",
        "facts.json": "b8ac4975989109ddb2135f127e1ceaba0b6e3ead2f2f9184f54d0f350741b322",
        "selection-report.json": "6b298cabdcaa1253945ffa4d73b3e8cbc2760c46001f943776d3b3366e7eebaf"
    }
}
```

### .agent-loop/recall/PHP17-A1/recall-log.draft.json

```text
{
    "applied": [],
    "applied_proposals": [],
    "comment": "Optional: add a guidance_outcomes row only for selected guidance (see evaluated_guidance) that actually changed, confirmed, or misled your work: {\"guidance_id\", \"guidance_type\", \"selected\": true, \"applied\", \"outcome\", \"comment\"} (outcome values: docs/guidance-events.md). A helpful row also needs attribution: {\"seen_before_decision\": did you read it before the decision it helped, \"also_prescribed_by\": the other sources that already prescribed that decision (task_prompt, contract, skill, template, constraint, repository_docs), or [] if nothing else did}. Leave the list empty when nothing notable happened; unjudged selections are neutral.",
    "compilation_id": "compilation.PHP17-A1.2026-10-11-124443.82170bbe",
    "constraints_used": [],
    "created_at": "2026-10-11T12:44:43+00:00",
    "evaluated_guidance": [
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "constraint.agent-loop.phpstan.in-process-rule-test-case",
            "guidance_type": "constraint",
            "selected": false,
            "selection_reason": null,
            "source_proposal": "proposal.2026-09-13.2acd04",
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "constraint.workflow.recovery.next-action-must-advance",
            "guidance_type": "constraint",
            "selected": false,
            "selection_reason": null,
            "source_proposal": "proposal.2026-08-20.c2a001",
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.001",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.003",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.007",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.011",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.013",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.015",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.c969ec",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-14.d7d793",
            "guidance_type": "memory",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-08-20.c2a001",
            "guidance_type": "constraint",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        },
        {
            "eligible": false,
            "exclusion_reason": "no_scope_overlap",
            "guidance_id": "proposal.2026-09-13.2acd04",
            "guidance_type": "constraint",
            "selected": false,
            "selection_reason": null,
            "task_files": []
        }
    ],
    "guidance_outcomes": [],
    "guidance_used": [],
    "harmful": [],
    "helpful": [],
    "id": "outcome.2026-10-11.000",
    "irrelevant": [],
    "operating_prompt_outcomes": [],
    "result": "successful",
    "schema_version": "1.0",
    "selected": [],
    "session": "sess_placeholder",
    "task_files": [
        "src/Init/I
[truncated]
```

### .agent-loop/recall/PHP17-A1/system.md

```text
# L2 Meta-Prompt Briefing for Task: PHP17-A1
> Recall bundle SHA-256: 4907c70f35f819cba1ff7eaaf749ad2da98d1a21a692ce256551ba65f56c4cba

## Task Description
Repair the tool-inventory CLI so a fresh cache created by an older version cannot hide newly supported external evidence tools. A project with all six native-tool entries cached, but no external-tool entries, currently reports the cache as reused and omits a project-installed slop-scan. It must re-probe and expose the installed external tool, while a complete fresh cache must still be reused and --refresh must still work. Add a focused regression test and run the existing tool-inventory tests. Keep project-local tool precedence and optional-tool semantics unchanged. This is a privately seeded regression in real production PHP code, not a claim about a production defect.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `src/Init/InitToolsCommand.php`
- File/path: `tests/InitToolsCommandTest.php`
- Scope: `src/Init/InitToolsCommand.php`
- Scope: `tests/InitToolsCommandTest.php`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Correct old-cache re-probe and retained complete-cache reuse/refresh, meaningful regression and current validation, review and Learning; inspect original evidence through assigned interface.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No release, push, global configuration, dependencies, production checkout or fixture/oracle access.

## Repository Global Memory (`MEMORY.md`)
# Repository memory

This file contains reviewed, durable rules for `voku/agent-loop`. Raw observations belong in `.agent-loop/learning/findings/`; repeatable behavior belongs in tests, dogfood runners, or static rules. A row here is deliberately short because memory is an index into executable truth, not a replacement for it.

## Durable repository rules

| Subject | Durable rule | Canonical home |
| --- | --- | --- |
| Internal package boundaries | Workflow orchestration calls focused-package typed PHP APIs when they exist. User-facing package CLI delegation stays at the Dispatcher boundary; do not reconstruct focused-package argv inside `voku\\AgentLoop\\Workflow`. | `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php` and workflow tests |
| Workflow session invariant | Governed workflow orchestration has at most one active session per task. Start/plan may reuse that session; if more than one active session already exists, fail before further task work. Retries after partial failure must not allocate another active session. | `WorkflowStartCommand`, `WorkflowPlanCommand`, and workflow tests |
| Dogfood entrypoints | Repository self-dogfood executes `php bin/agent-loop`; installed-consumer dogfood separately proves `vendor/bin/agent-loop`. They are different packaging contracts and both remain covered. | `tools/self-shape-dogfood.php` and `tools/release-set-dogfood.php` |
| Pull-request dogfood credentials | A PR self-shape job needs repository history, not write access. Keep its `GITHUB_TOKEN` at `contents: read` and use checkout with `persist-credentials: false` so PR-controlled code does not inherit a persisted repository credential. | `.github/workflows/ci.yml` and `.agent-loop/learning/findings/validated/finding.2026-08-07.007.json` |
| Self-review close-out | An exploratory blind-spot review may warn while work is open. Before close, run `recall log-outcome` and record a checkpoint that evidences both outcome close-out and `review blindspots`. `workflow close` owns the gate: it refuses a missing, invalid or `fail` report and admits a `warn`, because advisory findings such as `security_sensitive_context` fire on any diff that mentions security terms and cannot be resolved by working harder. CLI exit 0 alone is not sufficient evidence, so the residual status is recorded as close-out evidence rather than inferred from the exit code. | `WorkflowCloseCommand::checkReviewGate()`, `tests/WorkflowCloseCommandTest.php`, and `tools/self-shape-dogfood.php` |
| Tooling test isolation | Project-specific PHPStan rule fixtures run in a separate PHPStan process. Do not load `PHPStan\\Testing\\RuleTestCase` into agent-loop's normal PHPUnit process while `agent-map` also performs Composer-based PHPStan discovery there. | `phpstan/Rules/NoInProcessPhpstanRuleTestCaseRule.php` and `tools/project-phpstan-rules.php` |
| Git repository detection | Repository state is as
[truncated]
```

### .agent-loop/recall/PHP17-A1/validation-plan.md

````text
# Validation Plan

## Required Validation

### Task Validation

```bash
env -u CODEX_HOME vendor/bin/phpunit tests/InitToolsCommandTest.php
```

```bash
env -u CODEX_HOME composer ci
```
````

### .agent-loop/sessions/2026-10-11-php17-a1-r1-bb0664cb/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-php17-a1-r1-bb0664cb/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-11-php17-a1-r1-bb0664cb/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-php17-a1-r1-bb0664cb/plan.md

```text
# Plan: PHP17-A1

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-php17-a1-r1-bb0664cb/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-php17-a1-r1-bb0664cb",
    "task_id": "PHP17-A1",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T12:44:43+00:00",
    "base_commit": "33b46b83526f1fe5301cd36b97a212cb19d20b9a",
    "created_at": "2026-10-11T12:44:43+00:00",
    "updated_at": "2026-10-11T12:44:43+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-php17-a1-r1-bb0664cb/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*

## Validation evidence (Contract revision 1)

- Command: `env -u CODEX_HOME vendor/bin/phpunit tests/InitToolsCommandTest.php`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T12:47:09+00:00
- Implementation snapshot: sha256:5f643d5651afed3e72b26cbda7ae47971fac2607db39ac4b3082f71e9cd2b4b3

## Validation evidence (Contract revision 1)

- Command: `env -u CODEX_HOME composer ci`
- Status: failed
- Exit: 124
- Executed: 2026-10-11T12:49:32+00:00
- Implementation snapshot: sha256:5f643d5651afed3e72b26cbda7ae47971fac2607db39ac4b3082f71e9cd2b4b3
- Note: Trace wrapper timeout at 180 seconds during final slop scan

## Validation evidence (Contract revision 1)

- Command: `env -u CODEX_HOME composer ci`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T12:52:27+00:00
- Implementation snapshot: sha256:5f643d5651afed3e72b26cbda7ae47971fac2607db39ac4b3082f71e9cd2b4b3
- Duration: 157595ms
```
