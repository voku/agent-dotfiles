# L2 Meta-Prompt Briefing for Task: PHP17-B1
> Recall bundle SHA-256: b35fcd9b7ca36b58f17a13c897093e8b00cd4445b5a9ce41db92589013bed225

## Task Description
Repair the tool-inventory CLI so a fresh cache created by an older version cannot hide newly supported external evidence tools. A project with all six native-tool entries cached, but no external-tool entries, currently reports the cache as reused and omits a project-installed slop-scan. It must re-probe and expose the installed external tool, while a complete fresh cache must still be reused and --refresh must still work. Add a focused regression test and run the existing tool-inventory tests. Keep project-local tool precedence and optional-tool semantics unchanged. This is a privately seeded regression in real production PHP code, not a claim about a production defect.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `src/Init/InitToolsCommand.php`
- File/path: `tests/InitToolsCommandTest.php`
- Scope: `src/Init/InitToolsCommand.php`
- Scope: `tests/InitToolsCommandTest.php`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Correct old-cache re-probe and retained complete-cache reuse/refresh, meaningful regression and current validation, review and Learning; inspect original evidence through assigned interface.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No release, push, global configuration, dependencies, production checkout or fixture/oracle access.

## Repository Global Memory (`MEMORY.md`)
# Repository memory

This file contains reviewed, durable rules for `voku/agent-loop`. Raw observations belong in `.agent-loop/learning/findings/`; repeatable behavior belongs in tests, dogfood runners, or static rules. A row here is deliberately short because memory is an index into executable truth, not a replacement for it.

## Durable repository rules

| Subject | Durable rule | Canonical home |
| --- | --- | --- |
| Internal package boundaries | Workflow orchestration calls focused-package typed PHP APIs when they exist. User-facing package CLI delegation stays at the Dispatcher boundary; do not reconstruct focused-package argv inside `voku\\AgentLoop\\Workflow`. | `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php` and workflow tests |
| Workflow session invariant | Governed workflow orchestration has at most one active session per task. Start/plan may reuse that session; if more than one active session already exists, fail before further task work. Retries after partial failure must not allocate another active session. | `WorkflowStartCommand`, `WorkflowPlanCommand`, and workflow tests |
| Dogfood entrypoints | Repository self-dogfood executes `php bin/agent-loop`; installed-consumer dogfood separately proves `vendor/bin/agent-loop`. They are different packaging contracts and both remain covered. | `tools/self-shape-dogfood.php` and `tools/release-set-dogfood.php` |
| Pull-request dogfood credentials | A PR self-shape job needs repository history, not write access. Keep its `GITHUB_TOKEN` at `contents: read` and use checkout with `persist-credentials: false` so PR-controlled code does not inherit a persisted repository credential. | `.github/workflows/ci.yml` and `.agent-loop/learning/findings/validated/finding.2026-08-07.007.json` |
| Self-review close-out | An exploratory blind-spot review may warn while work is open. Before close, run `recall log-outcome` and record a checkpoint that evidences both outcome close-out and `review blindspots`. `workflow close` owns the gate: it refuses a missing, invalid or `fail` report and admits a `warn`, because advisory findings such as `security_sensitive_context` fire on any diff that mentions security terms and cannot be resolved by working harder. CLI exit 0 alone is not sufficient evidence, so the residual status is recorded as close-out evidence rather than inferred from the exit code. | `WorkflowCloseCommand::checkReviewGate()`, `tests/WorkflowCloseCommandTest.php`, and `tools/self-shape-dogfood.php` |
| Tooling test isolation | Project-specific PHPStan rule fixtures run in a separate PHPStan process. Do not load `PHPStan\\Testing\\RuleTestCase` into agent-loop's normal PHPUnit process while `agent-map` also performs Composer-based PHPStan discovery there. | `phpstan/Rules/NoInProcessPhpstanRuleTestCaseRule.php` and `tools/project-phpstan-rules.php` |
| Git repository detection | Repository state is asked of Git, never inferred from the shape of `.git`. A linked worktree stores `.git` as a file, which silently turned `init doctor` and `init sync-githooks` into no-ops for a valid checkout. | `phpstan/Rules/NoGitDirectoryShapeAssumptionRule.php`, `src/GitWorkTree.php`, and `tests/GitWorkTreeDetectionTest.php` |
| CI ownership | GitHub Actions executes the repository dogfood runner; it does not duplicate the governed lifecycle or maintain a second hard-coded changed-file list. The runner derives PR scope from Git. | `tools/self-shape-dogfood.php` and `.github/workflows/ci.yml` |
| Learning decision consistency | The self-shape learning decision follows the durable evidence in the actual PR diff. If project findings or `MEMORY.md` are changed, record `findings_recorded`; otherwise record `no_durable_learning`. Do not close with a learning state that contradicts the repository evidence produced by the task. | `tools/self-shape-dogfood.php` and `.agent-loop/learning/findings/validated/finding.2026-08-07.006.json` |
| Derived state paths | A repository-local derived path has one owner for reading *and* writing. `ProjectLayout::mapSearchIndex()` was read by `workflow approve` and written by nothing, so ranked map evidence silently never reached the governed context. When a decisive-evidence channel is unavailable, the workflow says so rather than compiling a quietly narrower context. | `src/Dispatcher.php`, `tests/MapSearchIndexOwnershipTest.php`, and `tests/WorkflowApproveSearchIndexEvidenceTest.php` |
| Memory follows executable truth | When a `MEMORY.md` row and its named canonical home disagree, correct the row towards what the code enforces; do not add a second enforcement point to make the prose true. | `.agent-loop/learning/findings/validated/finding.2026-08-14.007.json` and `docs/dogfood/2026-08-14-second-learning-pass.md` |
| Blind-spot review of a diff | Read a change for what it removed, not only for what it added. An invariant that held by construction needs an explicit assertion once its construction changes; a random source is injected rather than sampled by a test; a process call is not a drop-in for a filesystem check, because it can fail in ways that print. | `.agent-loop/learning/findings/consolidated/finding.2026-08-14.015.json` and `src/GitWorkTree.php` |
| Runtime dependency boundary | A package cannot be dev-only while a class `agent-loop` publishes depends on it: `ArchitectureRules` ships in `src/` and implements `ItpContext\\Contract\\RuleIdentifier`, so anything reflecting over production classes fatals without it. Loading a shipped class is not the same as running a command, so a CLI smoke test cannot decide a dependency boundary. | `tests/RealIssueEvidenceToolBoundaryTest.php` and `docs/dogfood/real-issue-acceptance.md` |
| Governed context evidence conservation | When decisive evidence is missing from a governed context, first establish where it was lost along map discovery, Recall selection and context projection. Widening search, changing ranking or raising the context budget is a last resort and must be recorded in the frozen replay. | `tests/FrozenReplayEvidenceChainTest.php` and `tests/WorkflowApproveSearchIndexEvidenceTest.php` |
| Learning evidence detection | Detect learning evidence by finding identity across every findings state directory, not by the directory a finding currently occupies. A `MEMORY.md` change with no finding evidence fails the gate rather than selecting a status around it. | `tools/self-shape-dogfood.php` and its tests |
| Tool-coupled instruction assets | Machine-readable instruction assets coupled to a tool's CLI, schema or output contract ship from the repository that owns the tool and are tested with it. A general skill collection may reference or install tool-owned assets but must not keep a second canonical copy. | `resources/prompts/operating-prompts.json` and `.agent-loop/learning/findings/consolidated/finding.2026-08-14.005.json` |
| Host guidance ownership | `init install-assets` projects first-party package assets. A project that declares `package_skills=false` and its own `paths.skills_root` projects that root through `sync-skills`, so it does not acquire a competing package copy of the same rule. | `resources/skills/agent-guidance-maintenance/SKILL.md`, `InitMultiSkillSourceTest.php`, and `docs/contributing/repository-layout.md` |
| Lifecycle routing | A router may select the smallest relevant specialist, but only the current `enter`/`finish` result selects governed lifecycle work; it must not invent task-start, Recall, repair, Learning, review, or close phases. | `resources/instructions/project-instructions.md`, `resources/skills/agent-loop-workflow/SKILL.md`, and `HostLifecycleGuidanceAuthorityTest.php` |
| Dogfood runners are orchestration only | Runners orchestrate; every decision they make lives in a tested class under `src/Dogfood/`. Convert a shell runner for testability rather than portability - Git for Windows ships bash. A static rule carries the scope it was earned in: `-n` belongs to validation subprocesses, not to invoking our own CLI, which needs the extensions `php.ini` loads. | `src/Dogfood/SelfShapeEvidence.php` and `tests/SelfShapeEvidenceTest.php` |
| Learning promotion | Findings are evidence, not durable memory. Promote only reviewed lessons; when a rule is objectively detectable, back the memory entry with a test, dogfood gate, or static-analysis rule. | `docs/workflow/learning-boundary.md` and `.agent-loop/learning/` |

## Archived task learning

| Archived on | Task | Summary | Archive reason | Durable lesson candidate | Promoted to |
| --- | --- | --- | --- | --- | --- |
| 2026-08-07 | `SELF-SHAPE` / PR #28 | Shaped workflow/session boundaries while `agent-loop` governed and reviewed its own change, then incorporated independent security and data-integrity review findings. | The task-specific evidence is captured by validated findings and CI artifacts; only stable rules belong above. | Prefer typed package APIs for internal orchestration, preserve one active session per governed task, keep PR dogfood credentials read-only/non-persistent, keep repository and consumer dogfood entrypoints distinct, isolate tooling tests, make final self-review evidence-complete with machine-readable status `ok`, and keep the learning decision consistent with the durable evidence actually produced. | `MEMORY.md`; `docs/dogfood/self-shaping.md`; `phpstan/Rules/NoFocusedPackageCliInWorkflowRule.php`; workflow tests; `.github/workflows/ci.yml`; `tools/project-phpstan-rules.php`; `tools/self-shape-dogfood.php` |

## Navigation Facts
- `src/Init/InitToolsCommand.php`
  - class `voku\AgentLoop\Init\InitToolsCommand` (lines 18-508)
    - `__construct()` (lines 73-75)
    - `run()` (lines 80-115)
    - `probe()` (lines 120-152)
    - `resolveExternalTool()` (lines 157-174)
    - `resolveBinary()` (lines 176-199)
    - `readCache()` (lines 204-222)
    - `coversEveryKnownTool()` (lines 230-239)
    - `isFresh()` (lines 244-252)
    - `writeCache()` (lines 257-271)
    - `render()` (lines 276-307)
    - `renderProjectComposerTools()` (lines 309-345)
    - `projectComposerToolRequirements()` (lines 350-395)
    - `formatAge()` (lines 397-412)
    - `resolveCachePath()` (lines 415-420)
    - `resolvePath()` (lines 422-429)
    - `validateTokens()` (lines 434-467)
    - `readMaxAge()` (lines 472-480)
    - `usage()` (lines 482-507)
- `tests/InitToolsCommandTest.php`
  - class `voku\AgentLoop\Tests\InitToolsCommandTest` (lines 15-354)
    - `setUp()` (lines 23-32)
    - `tearDown()` (lines 34-42)
    - `testProbeReportsAvailableToolAndWritesCache()` (lines 44-66)
    - `testExternalEvidenceToolIsFoundInAnIsolatedToolProject()` (lines 68-79)
    - `testExternalEvidenceToolIsFoundInTheProjectVendorBin()` (lines 81-92)
    - `testExternalEvidenceToolIsFoundInItsOwnToolProject()` (lines 95-106)
    - `testPinnedProjectInstallationWinsOverAnAmbientPathBuild()` (lines 108-121)
    - `testExternalEvidenceToolFallsBackToPath()` (lines 123-131)
    - `testMissingExternalEvidenceToolIsReportedWithoutWarning()` (lines 133-142)
    - `testCacheWrittenBeforeAToolWasKnownIsReprobed()` (lines 144-163)
    - `testProbeReportsMissingToolAsWarning()` (lines 165-173)
    - `testProbeReportsMissingAgentMapIndex()` (lines 175-182)
    - `testProbeReportsPresentAgentMapIndex()` (lines 184-193)
    - `testBuiltMapIndexIsFoundWhereTheLayoutOwnerPutsIt()` (lines 199-212)
    - `testMapIndexFollowsAConfiguredStateRoot()` (lines 214-228)
    - `testFreshCacheIsReusedWithoutReprobing()` (lines 230-242)
    - `testRefreshForcesReprobeEvenWithFreshCache()` (lines 244-255)
    - `testMaxAgeZeroForcesReprobeOnEveryRun()` (lines 257-268)
    - `testCustomCachePathIsHonored()` (lines 270-280)
    - `testMalformedCacheFileIsTreatedAsMissing()` (lines 282-292)
    - `testUnknownOptionFails()` (lines 294-299)
    - `runTools()` (lines 306-315)
    - `makeProjectFile()` (lines 318-328)
    - `makeFakeExecutable()` (lines 330-335)
    - `removeDirectory()` (lines 337-353)

## Scoped Project Documents
### ADR: adr.agent-loop-pre-1.0-compatibility
- **Source**: policies/pre-1.0-compatibility.md
````text
# Pre-1.0 compatibility policy

Status: accepted project-wide policy for the current `agent-loop` release line.

`agent-loop` and its first-party `agent-*` packages are still before 1.0. Backward
compatibility is therefore not the default goal when it would preserve duplicate
ownership, a false-green path, or a legacy layer that exists only for another
first-party package in the same coordinated release set.

For an affected first-party contract:

1. identify the owning package and every in-scope first-party consumer;
2. prefer changing the owner and consumers together, updating dependency
   constraints, and deleting the obsolete path;
3. prove the coordinated migration through package tests and the installed
   release-set gate;
4. accept an alias, adapter, fallback, dual-read, or legacy layer only when a
   verified external consumer or an explicit compatibility promise requires it.

Breaking change is not permission for speculative redesign. The change must
remove a demonstrated contradiction, defect, duplicate rule, or wrong ownership
boundary. Historical evidence remains readable, and unrelated public contracts
remain out of scope.

If a narrower directory or module policy conflicts with this project-wide
default, stop and surface the conflict instead of guessing which contract wins.
````

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### constraint.agent-loop.phpstan.in-process-rule-test-case
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap
- **Source**: proposal.2026-09-13.2acd04

### constraint.workflow.recovery.next-action-must-advance
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap
- **Source**: proposal.2026-08-20.c2a001

### proposal.2026-08-14.001
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.003
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.007
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.011
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.013
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.015
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.c969ec
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-14.d7d793
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-08-20.c2a001
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### proposal.2026-09-13.2acd04
- **State**: VERIFIED
- **Selected**: no
- **Why**: RecallDecisionEngine evaluated this guidance for the current task.
- **How**: Deterministic guidance eligibility and task-scope selection.
- **Authority**: guidance_selection
- **Use**: excluded_guidance_do_not_apply
- **Why not**: no_scope_overlap

### composer ci
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The repository declares this Composer script, so the command is an exact project-native entry point rather than an inferred tool invocation.
- **How**: Read directly from composer.json scripts.ci.
- **Authority**: project_metadata
- **Use**: verification_candidate
- **Source**: /workspace/scratch/quality-cycle-17/B1/composer.json

### PHP runtime constraint ^8.3
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The supported runtime constrains valid implementation syntax and dependencies.
- **How**: Read directly from composer.json require.php.
- **Authority**: project_metadata
- **Use**: implementation_constraint
- **Source**: /workspace/scratch/quality-cycle-17/B1/composer.json

### docs/policies/pre-1.0-compatibility.md
- **State**: VERIFIED
- **Selected**: yes
- **Why**: project-wide document policy
- **How**: ScopedDocumentRecallProvider selection using path scope, task tags, or project-wide policy.
- **Authority**: project_adr
- **Use**: architecture_constraint
- **Source**: docs/policies/pre-1.0-compatibility.md

### Omitted Project Capabilities
- **Omitted from runtime context**: 36
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 16
- **configuration_anchor**: 3
- **repository_command**: 14
- **tool_presence**: 3