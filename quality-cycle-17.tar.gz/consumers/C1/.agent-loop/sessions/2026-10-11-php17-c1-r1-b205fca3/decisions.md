# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*

## Decision: Cache coverage follows both probe inventories

Original InitToolsCommand.php:123-130 probes native and external inventories; :232 checks only native keys. Existing regression :144-163 cached only rg, so could not expose omission when all native keys exist. Strengthened fixture to all six native keys, reproduced failure, then included external keys in completeness. No tool resolution or optionality changes.
