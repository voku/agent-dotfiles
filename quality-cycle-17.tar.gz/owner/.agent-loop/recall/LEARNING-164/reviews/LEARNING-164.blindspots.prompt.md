# L2 blind-spot analysis prompt for LEARNING-164

## Presentation

Write the final review in language en. Translate explanatory headings and prose; preserve exact source text, identifiers, paths, citations, and required machine-readable status tokens.

## First-draft falsification lens

Treat the current implementation as a first draft, even if produced by you or paired with a confident rationale.

Review for falsification rather than confirmation. Try to prove concrete failures against requirements, acceptance criteria, constraints, non-goals, current source, tests, static analysis, and safe runtime evidence.

Acceptance criteria are required outcomes, not evidence they are satisfied. Prior reasoning, model confidence, reviewer consensus, prompt construction, and unexecuted commands are not verification.

Treat every LLM-produced statement as a candidate claim, not repository truth. Re-ground material claims against current authoritative artifacts or deterministic evidence before acting. A detailed patch is not evidence that the described classes, boundaries, bugs, or metrics actually exist. If model output conflicts with current authoritative artifacts, the artifacts win. Reproduce a finding before fixing it. Review findings are investigation candidates, not instructions to modify code.

Classify material conclusions as VERIFIED, INFERRED, ASSUMED, BLOCKED, or CONTRADICTED. If needed evidence is unavailable, keep it UNKNOWN or BLOCKED.

Separate required fixes from optional improvements. Do not manufacture findings. CLEAN is valid only after concrete attempts to falsify the implementation found no evidence-backed defect.

## Repo-first blind-spot lens

Act as an evidence-based technical blind-spot critic, not an approval authority.

Start repo-first. From supplied artifacts derive the intended outcome, constraints/non-goals, affected surfaces, assumptions, success/failure evidence, and material unknowns. Do not invent missing context.

Before new hypotheses, audit the supplied results, including your own prior conclusions. Treat them as candidate claims, not as evidence merely because you produced them. Re-ground material conclusions against primary artifacts; call out contradictions, omitted evidence, or unsupported causal attribution.

Run these bounded probes:
1. Pattern drift: compare at least two relevant in-repository examples before claiming a structural or ownership violation; otherwise report the evidence gap.
2. Intent erosion: check whether strict contracts, metadata, acceptance criteria, or non-goals were weakened merely to make the implementation fit.
3. Operational overconfidence: treat workflow, deployment, migration, generated metadata, and irreversible side effects as high-risk until evidenced.
4. False failure attribution: a missing dependency, generated asset, tool, or environment prerequisite is not a product defect until setup readiness is established.
5. Premature closure: verify that outcome, impacted surfaces, validation evidence, and close claim line up.

Across repository or package boundaries, trace the semantic owner, authoritative input, crossing artifact and retained identity to the consumer. Do not infer ownership from names or documentation alone.

Prefer the smallest discriminating dogfood experiment over speculation. Use only environments relevant to the hypothesis: source checkout; clean installed/released consumer or cross-package release set; repeat/resume; or no-change. For historical replay, freeze base state/input and do not leak the known fix; starting with the answer cannot prove discovery quality. No-change is a valid outcome.

For every material blind spot, classify the claim with the existing epistemic status and cite supporting or contradicting evidence. State the hidden assumption and concrete failure chain, earliest observable signal, smallest falsification probe, and why existing tests or gates did not expose it. Name a corrective action only after the claim becomes VERIFIED.

Use adversarial pre-mortem reasoning only as a hypothesis generator. A plausible failure story, model confidence, numeric score, imagined future, repeated self-refinement, or successful mechanism execution is not evidence. Do not manufacture findings to satisfy a quota.

If required repository or runtime evidence is unavailable, keep the claim UNKNOWN or BLOCKED and name the missing evidence. READY FOR HUMAN CLOSE is valid only when bounded probes found no evidence-backed blocker and supplied validation/close evidence is coherent.

You are reviewing recall-compiler workflow artifacts. Use only the artifacts below as evidence.
Expose missing validation, missing outcome logging, mismatched selected guidance, unsafe assumptions, and handoff gaps. Do not approve code or durable learning.

## Deterministic preflight findings

- [WARN] missing_outcome_closeout: No evidence shows recall outcome close-out was prepared or logged.
  - Searched markers: log-outcome, recall-log.draft.json, outcome=, "outcome"
- [WARN] missing_review_checkpoint: No blind-spot review checkpoint marker was found.
  - Searched markers: review blindspots, review-blindspots, L2 blind-spot

## Output contract

Return Markdown with headings: Summary, Critical blind spots, Evidence, Required next action, Close readiness.
For each material claim, give its epistemic status and the concrete artifact/evidence that supports or contradicts it.
Review findings are investigation candidates, not instructions to modify code.
Close readiness must be BLOCKED, NEEDS HUMAN REVIEW, or READY FOR HUMAN CLOSE.

## Artifacts

### .agent-loop/recall/LEARNING-164/meta.json

```text
{
    "schema_version": "1.0",
    "compilation_id": "compilation.LEARNING-164.2026-10-11-125616.8229aa42",
    "task_id": "LEARNING-164",
    "task_files": [
        "src/Cli.php",
        "src/FindingTransitionManager.php",
        "tests/FindingCreateCliTest.php"
    ],
    "task_targets": [],
    "bundle_sha256": "4b43926251ef0ab0660386e9d1c65094365f62a9209f8242569446e6ea9ba943",
    "snapshot_sha256": "75254ec09ea18a0f703fa9eee4dba0e4675dfb636d913db6bd5e7e403f3c2039",
    "blocked": false,
    "block_reason": null,
    "selected_guidance": [],
    "evaluated_guidance": [],
    "selected_constraints": [],
    "selected_rejections": [],
    "outcome_stats": [],
    "warnings": [],
    "output_hashes": {
        "system.md": "5395114c7949cd6fb733b6911bbfa013395072a21ba633c6bd84eb7e2cfe40d9",
        "validation-plan.md": "5affa8c2c9c48a47b3efb8f0cb75cfda73c893c4c0eaa5fce98bafcfbc57a85a",
        "recall.bundle.json": "c71cece9bfe65858a1a0b65c844161ee3436ddb5adc929d94bb1f03544eeaf91",
        "facts.json": "6354de704966ecba177ff7149cf473b2825a56175ce509f36373ca61316c8bf0",
        "selection-report.json": "873174e9ab4613e54f1d2bbab3acebe52fa567b54463cb66c40b0b0e3e597b1e"
    }
}
```

### .agent-loop/recall/LEARNING-164/recall-log.draft.json

```text
{
    "applied": [],
    "applied_proposals": [],
    "comment": "Optional: add a guidance_outcomes row only for selected guidance (see evaluated_guidance) that actually changed, confirmed, or misled your work: {\"guidance_id\", \"guidance_type\", \"selected\": true, \"applied\", \"outcome\", \"comment\"} (outcome values: docs/guidance-events.md). A helpful row also needs attribution: {\"seen_before_decision\": did you read it before the decision it helped, \"also_prescribed_by\": the other sources that already prescribed that decision (task_prompt, contract, skill, template, constraint, repository_docs), or [] if nothing else did}. Leave the list empty when nothing notable happened; unjudged selections are neutral.",
    "compilation_id": "compilation.LEARNING-164.2026-10-11-125616.8229aa42",
    "constraints_used": [],
    "created_at": "2026-10-11T12:56:16+00:00",
    "evaluated_guidance": [],
    "guidance_outcomes": [],
    "guidance_used": [],
    "harmful": [],
    "helpful": [],
    "id": "outcome.2026-10-11.000",
    "irrelevant": [],
    "operating_prompt_outcomes": [],
    "result": "successful",
    "schema_version": "1.0",
    "selected": [],
    "session": "sess_placeholder",
    "task_files": [
        "src/Cli.php",
        "src/FindingTransitionManager.php",
        "tests/FindingCreateCliTest.php"
    ],
    "task_id": "LEARNING-164",
    "task_targets": []
}
```

### .agent-loop/recall/LEARNING-164/system.md

```text
# L2 Meta-Prompt Briefing for Task: LEARNING-164
> Recall bundle SHA-256: 4b43926251ef0ab0660386e9d1c65094365f62a9209f8242569446e6ea9ba943

## Task Description
Honor explicitly configured task pattern consistently during Finding state transition, preserving default strict validation and rollback.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `src/Cli.php`
- File/path: `src/FindingTransitionManager.php`
- File/path: `tests/FindingCreateCliTest.php`
- Scope: `src/Cli.php`
- Scope: `src/FindingTransitionManager.php`
- Scope: `tests/FindingCreateCliTest.php`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Customcapturethen transition passes; incompatiblepattern rollback unchanged; same-status response consistent; default tests and strictCI pass, independentreview and Dream include dogfood.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No release, runtime upgrade, widened default regex, workflow authority or guidance promotion.

## Repository Global Memory (`MEMORY.md`)
# Agent Learning Project Memory

Durable rules and boundaries for every coding session working on the `voku/agent-learning` package:

## 1. Governance Boundary
* **Do not absorb task management or session recording**: This package must govern learning only. It is a firewall between untrusted LLM output and durable storage.
* **Keep layers separate**:
  * Findings under `findings/` represent raw experience.
  * Proposals under `proposals/` manage transitions.
  * Outcomes under `history/outcomes.jsonl` measure helpfulness/harmfulness.
* **Expose typed owner operations when lifecycle hosts need to write Learning state**: orchestrators should call owner APIs such as `FindingCreator` instead of hand-authoring Learning JSON or depending on storage-directory choreography.

## 2. Invariants & Validations
* **Status Invariants**: `validation_status` must strictly align with the `status` enum (e.g., `REJECTED` status must be `validated` or `invalidated`, never `unverified`).
* **Evidence Validation**: All findings require concrete, commit-safe evidence (e.g., test command, line reference, manual verification summary).
* **Scope Invariants**:
  * Proposal scope cannot be broadened compared to the source finding evidence unless a justification of at least 15 characters is provided in the `reason` field.
  * Disjoint scope extensions (unrelated directory paths) must be treated as broadened scopes.
* **Redaction Guard**: Use `RedactionGuard` on the Learning boundaries that explicitly opt into secret scanning; do not assume every parser or lifecycle file mutation is guarded when executable code does not route it through that owner.
* **Constraint adoption proves reuse, not validation execution**: `adopt_existing` is valid only when the configured target and every registration file already exist. Constraint activation remains an explicit authority-bearing transition and validates the configured files/approval state that the activator actually checks; do not claim that activation itself executed or proved arbitrary validation commands unless executable behavior provides that evidence.

## 3. Transitions
* **Atomic Rollbacks**: Proposal/Finding status transitions that modify existing lifecycle records (approve, reject, acknowledge, retire, apply, and Finding status moves) must restore touched record/history files when repository validation fails; do not leave Learning state partially transitioned.
* **Judgment is not automation**: proposal approval, rejection, acknowledgement, and Constraint activation remain explicit authority-bearing transitions. A candidate must not become approved or active merely because generation/export/validation succeeded.
* **`NO_DURABLE_LEARNING` is a valid conclusion**: acknowledge it when the analysis is accepted; do not misuse rejection to make a correct conservative result look like maintainer disagreement.

## 4. Refactoring Boundary
* **Refactor invariants at their owner**: reduce duplicated transition mechanics only where behavior is demonstrably the same. Keep Finding/Proposal policy decisions explicit and separate from persistence mechanics.
* **Do not manufacture architecture to remove duplication**: prefer an owner-local extraction before introducing a shared abstraction. A generic transaction framework, new lifecycle layer, or cross-package orchestration helper requires independent evidence beyond naming/style pre
[truncated]
```

### .agent-loop/recall/LEARNING-164/validation-plan.md

````text
# Validation Plan

## Required Validation

### Task Validation

```bash
env -u CODEX_HOME composer ci
```
````

### .agent-loop/sessions/2026-10-11-learning-164-r1-b8c568ff/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-learning-164-r1-b8c568ff/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-11-learning-164-r1-b8c568ff/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-learning-164-r1-b8c568ff/plan.md

```text
# Plan: LEARNING-164

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-learning-164-r1-b8c568ff/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-learning-164-r1-b8c568ff",
    "task_id": "LEARNING-164",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T12:56:16+00:00",
    "base_commit": "0995ce4fb26329088883c8b52259f5ed48875e05",
    "created_at": "2026-10-11T12:56:16+00:00",
    "updated_at": "2026-10-11T12:56:16+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-learning-164-r1-b8c568ff/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*

## Validation evidence (Contract revision 1)

- Command: `env -u CODEX_HOME composer ci`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T12:58:55+00:00
- Implementation snapshot: sha256:f3d11652ee5491e27dc00fcc16097259f59cb4b145e919a3569fe04e8672ec84
- Note: Actual fullCI470tests1771assertions PHPStan0; learning-ci-fixed.log. Earlier regression red and testerror preserved.
```
