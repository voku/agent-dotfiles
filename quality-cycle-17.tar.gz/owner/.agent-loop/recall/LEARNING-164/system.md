# L2 Meta-Prompt Briefing for Task: LEARNING-164
> Recall bundle SHA-256: 4b43926251ef0ab0660386e9d1c65094365f62a9209f8242569446e6ea9ba943

## Task Description
Honor explicitly configured task pattern consistently during Finding state transition, preserving default strict validation and rollback.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `src/Cli.php`
- File/path: `src/FindingTransitionManager.php`
- File/path: `tests/FindingCreateCliTest.php`
- Scope: `src/Cli.php`
- Scope: `src/FindingTransitionManager.php`
- Scope: `tests/FindingCreateCliTest.php`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Customcapturethen transition passes; incompatiblepattern rollback unchanged; same-status response consistent; default tests and strictCI pass, independentreview and Dream include dogfood.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No release, runtime upgrade, widened default regex, workflow authority or guidance promotion.

## Repository Global Memory (`MEMORY.md`)
# Agent Learning Project Memory

Durable rules and boundaries for every coding session working on the `voku/agent-learning` package:

## 1. Governance Boundary
* **Do not absorb task management or session recording**: This package must govern learning only. It is a firewall between untrusted LLM output and durable storage.
* **Keep layers separate**:
  * Findings under `findings/` represent raw experience.
  * Proposals under `proposals/` manage transitions.
  * Outcomes under `history/outcomes.jsonl` measure helpfulness/harmfulness.
* **Expose typed owner operations when lifecycle hosts need to write Learning state**: orchestrators should call owner APIs such as `FindingCreator` instead of hand-authoring Learning JSON or depending on storage-directory choreography.

## 2. Invariants & Validations
* **Status Invariants**: `validation_status` must strictly align with the `status` enum (e.g., `REJECTED` status must be `validated` or `invalidated`, never `unverified`).
* **Evidence Validation**: All findings require concrete, commit-safe evidence (e.g., test command, line reference, manual verification summary).
* **Scope Invariants**:
  * Proposal scope cannot be broadened compared to the source finding evidence unless a justification of at least 15 characters is provided in the `reason` field.
  * Disjoint scope extensions (unrelated directory paths) must be treated as broadened scopes.
* **Redaction Guard**: Use `RedactionGuard` on the Learning boundaries that explicitly opt into secret scanning; do not assume every parser or lifecycle file mutation is guarded when executable code does not route it through that owner.
* **Constraint adoption proves reuse, not validation execution**: `adopt_existing` is valid only when the configured target and every registration file already exist. Constraint activation remains an explicit authority-bearing transition and validates the configured files/approval state that the activator actually checks; do not claim that activation itself executed or proved arbitrary validation commands unless executable behavior provides that evidence.

## 3. Transitions
* **Atomic Rollbacks**: Proposal/Finding status transitions that modify existing lifecycle records (approve, reject, acknowledge, retire, apply, and Finding status moves) must restore touched record/history files when repository validation fails; do not leave Learning state partially transitioned.
* **Judgment is not automation**: proposal approval, rejection, acknowledgement, and Constraint activation remain explicit authority-bearing transitions. A candidate must not become approved or active merely because generation/export/validation succeeded.
* **`NO_DURABLE_LEARNING` is a valid conclusion**: acknowledge it when the analysis is accepted; do not misuse rejection to make a correct conservative result look like maintainer disagreement.

## 4. Refactoring Boundary
* **Refactor invariants at their owner**: reduce duplicated transition mechanics only where behavior is demonstrably the same. Keep Finding/Proposal policy decisions explicit and separate from persistence mechanics.
* **Do not manufacture architecture to remove duplication**: prefer an owner-local extraction before introducing a shared abstraction. A generic transaction framework, new lifecycle layer, or cross-package orchestration helper requires independent evidence beyond naming/style preference.
* **Memory follows executable truth**: when this file and tested owner behavior disagree, correct this file toward the behavior. Do not add a second enforcement point merely to make prose true.

## Navigation Facts
- `src/Cli.php`
  - class `voku\AgentLearning\Cli` (lines 12-1931)
    - `__construct()` (lines 14-19)
    - `run()` (lines 24-69)
    - `guidanceEvaluateCommand()` (lines 74-139)
    - `guidanceConsistencyCommand()` (lines 146-189)
    - `dreamCommand()` (lines 196-232)
    - `historyRebuildCommand()` (lines 239-268)
    - `lineageRebuildCommand()` (lines 275-285)
    - `historyStatusCommand()` (lines 292-313)
    - `backlogCommand()` (lines 325-373)
    - `proposalQueueCommand()` (lines 382-442)
    - `findingQueueCommand()` (lines 450-506)
    - `findingReconcileCommand()` (lines 514-541)
    - `validateCommand()` (lines 546-563)
    - `constraintLoopCommand()` (lines 568-620)
    - `prepareCommand()` (lines 625-684)
    - `proposalValidateCommand()` (lines 689-705)
    - `proposalImportCommand()` (lines 710-723)
    - `constraintExportCommand()` (lines 728-757)
    - `constraintActivateCommand()` (lines 762-786)
    - `findingCreateCommand()` (lines 793-883)
    - `findingCaptureCommand()` (lines 891-951)
    - `findingClassifyCommand()` (lines 958-1028)
    - `findingIdCommand()` (lines 1040-1053)
    - `findingTransitionCommand()` (lines 1058-1104)
    - `findingIntakeResult()` (lines 1116-1127)
    - `proposalApproveCommand()` (lines 1132-1150)
    - `proposalRejectCommand()` (lines 1155-1177)
    - `proposalAcknowledgeCommand()` (lines 1182-1204)
    - `proposalMarkAppliedCommand()` (lines 1209-1235)
    - `proposalRetireCommand()` (lines 1240-1263)
    - `proposalReanchorCommand()` (lines 1268-1306)
    - `corpusAnalyzeCommand()` (lines 1313-1328)
    - `helpCommand()` (lines 1330-1416)
    - `unknownCommand()` (lines 1418-1424)
    - `validateFindings()` (lines 1429-1432)
    - `resolveProposalPath()` (lines 1434-1448)
    - `resolveProposalPathOrId()` (lines 1450-1457)
    - `resolveHistoryPath()` (lines 1459-1466)
    - `parseOptions()` (lines 1473-1503)
    - `stringOption()` (lines 1508-1519)
    - `positiveIntOption()` (lines 1524-1535)
    - `stringOptions()` (lines 1542-1563)
    - `findingEvidence()` (lines 1570-1608)
    - `boolOption()` (lines 1613-1616)
    - `addOption()` (lines 1622-1646)
    - `findingSelection()` (lines 1652-1669)
    - `uniqueStrings()` (lines 1676-1690)
    - `dateOption()` (lines 1695-1708)
    - `selectFindings()` (lines 1715-1730)
    - `matchesSelection()` (lines 1732-1755)
    - `scopeMatches()` (lines 1761-1772)
    - `appendConsolidationAddendum()` (lines 1774-1787)
    - `dreamReport()` (lines 1789-1835)
    - `dreamDecision()` (lines 1837-1858)
    - `boundedStrings()` (lines 1864-1869)
    - `writeDreamReport()` (lines 1871-1880)
    - `dreamTextReport()` (lines 1885-1920)
    - `write()` (lines 1922-1925)
    - `writeError()` (lines 1927-1930)
- `src/FindingTransitionManager.php`
  - class `voku\AgentLearning\FindingTransitionManager` (lines 13-164)
    - `__construct()` (lines 17-20)
    - `resolveFindingPath()` (lines 30-39)
    - `transition()` (lines 50-144)
    - `validateRepository()` (lines 146-163)
- `tests/FindingCreateCliTest.php`
  - class `voku\AgentLearning\Tests\FindingCreateCliTest` (lines 15-415)
    - `testCreatesValidatedFindingAndMissingTargetDirectory()` (lines 17-50)
    - `testCapturesUnverifiedHumanReportWithoutSessionOrEvidenceJson()` (lines 52-90)
    - `testCaptureRejectsIncompleteHumanReportBeforeWritingCandidate()` (lines 92-105)
    - `testReviewerMustSupplyConclusionBeforeCapturedFindingBecomesValidated()` (lines 107-146)
    - `testHumanIntakeCliIsSelfDescribingAcrossCaptureReviewAndClassification()` (lines 149-202)
    - `testReportsAllMissingRequiredOptionsInOneFailure()` (lines 204-219)
    - `testInvalidFindingLeavesNoPartialTargetDirectory()` (lines 221-239)
    - `testUnsupportedEvidenceTypeListsAcceptedVocabulary()` (lines 241-267)
    - `testCustomTaskPatternIsUsedDuringCreation()` (lines 269-290)
    - `testExplicitDuplicateIdDoesNotOverwriteExistingFinding()` (lines 292-310)
    - `testPublicationDoesNotReplaceUnexpectedExistingTarget()` (lines 312-327)
    - `createFreshLearningRoot()` (lines 329-337)
    - `evidenceJson()` (lines 339-345)
    - `validArguments()` (lines 350-364)
    - `assertNoTemporaryFindingFiles()` (lines 366-371)
    - `runFindingCreate()` (lines 378-381)
    - `runFindingCapture()` (lines 388-391)
    - `runFindingCommand()` (lines 398-414)

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### composer ci
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The repository declares this Composer script, so the command is an exact project-native entry point rather than an inferred tool invocation.
- **How**: Read directly from composer.json scripts.ci.
- **Authority**: project_metadata
- **Use**: verification_candidate
- **Source**: /workspace/agent-learning/composer.json

### PHP runtime constraint ^8.3
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The supported runtime constrains valid implementation syntax and dependencies.
- **How**: Read directly from composer.json require.php.
- **Authority**: project_metadata
- **Use**: implementation_constraint
- **Source**: /workspace/agent-learning/composer.json

### Omitted Project Capabilities
- **Omitted from runtime context**: 9
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 3
- **configuration_anchor**: 2
- **repository_command**: 2
- **tool_presence**: 2