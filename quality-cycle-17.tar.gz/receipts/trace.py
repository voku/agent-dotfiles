import sys,os,json,time,subprocess,hashlib,pathlib
root=pathlib.Path(sys.argv[1]); argv=sys.argv[2:]; start=time.monotonic_ns()
env=os.environ.copy();env["PHPRC"]="/workspace/.cloud-setup/php.ini";env["PATH"]="/workspace/.cloud-setup/bin:"+env.get("PATH","");env.pop("CODEX_HOME",None);env.pop("BASH_ENV",None);env["RIPGREP_CONFIG_PATH"]=os.devnull
try:
 p=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=600)
 row={"argv":argv,"cwd":str(root),"started_ns":start,"elapsed_ns":time.monotonic_ns()-start,"exit":p.returncode,"stdout":p.stdout.decode("utf8","backslashreplace"),"stderr":p.stderr.decode("utf8","backslashreplace"),"stdout_sha256":hashlib.sha256(p.stdout).hexdigest()}
except subprocess.TimeoutExpired as e:
 row={"argv":argv,"cwd":str(root),"started_ns":start,"elapsed_ns":time.monotonic_ns()-start,"exit":None,"timeout":True,"stdout":(e.stdout or b"").decode("utf8","backslashreplace"),"stderr":(e.stderr or b"").decode("utf8","backslashreplace")}
with (root.parent/(root.name+"-trace.jsonl")).open("a") as f:f.write(json.dumps(row)+"\n")
sys.stdout.write(row["stdout"]);sys.stderr.write(row["stderr"]);sys.exit(row["exit"] if row["exit"] is not None else 124)
