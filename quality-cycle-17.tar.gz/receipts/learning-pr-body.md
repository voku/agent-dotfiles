`finding-capture` accepts an explicit custom task pattern, but `finding-transition` silently discarded it and rejected the same candidate during repository validation. Fresh coding-agent maintenance exposed this with `PHP17-B1`; independent reproduction also failed for `custom:27`.

Thread the optional pattern through the transition manager and CLI response validation. Default validation, lifecycle rules and rollback remain unchanged. The CLI regression verifies both custom shapes, byte-for-byte rollback with an incompatible pattern, and an unchanged same-status response.

Validation: full `composer ci` passed (470 tests, 1771 assertions; PHPStan no errors), and independent targeted review passed21 tests/145 assertions. The initial red regression and an intermediate test error are retained as evidence. Governed through frozen agent-loop LEARNING-164; no release or running consumer upgrade.

Fixes #164.
