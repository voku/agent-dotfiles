#!/usr/bin/env python3
import pathlib,tempfile,subprocess,json,os,sys,datetime
repo=pathlib.Path(sys.argv[1]).resolve(); roundno=int(sys.argv[2]); checks=[]
PHP='/workspace/.cloud-setup/bin/php'; AUTO='/workspace/scratch/dotfiles-experiments/loop-current/vendor/autoload.php'
with tempfile.TemporaryDirectory(prefix='private-tool-oracle-') as td:
 t=pathlib.Path(td);root=t/'project Δ with spaces';root.mkdir(); bind=t/'bin';bind.mkdir()
 runner=t/'run.php'; runner.write_text('<?php\nrequire '+json.dumps(str(repo/'src/Init/InitToolsCommand.php'))+';\nrequire '+json.dumps(AUTO)+';\nexit((new \\voku\\AgentLoop\\Init\\InitToolsCommand($argv[1]))->run(array_slice($argv,2)));\n')
 env=dict(os.environ);env['PATH']=str(bind);env['PHPRC']='/workspace/.cloud-setup/php.ini';env.pop('CODEX_HOME',None)
 def run(args):
  p=subprocess.run([PHP,str(runner),str(root),*args],env=env,text=True,capture_output=True);return p
 def check(name,condition,p=None):checks.append({'name':name,'passed':bool(condition),'exit':None if p is None else p.returncode,'stdout':None if p is None else p.stdout,'stderr':None if p is None else p.stderr})
 if roundno==1:
  cache=root/'.agent-loop/tool-inventory.json';cache.parent.mkdir()
  payload={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'max_age_seconds':3600,'tools':{n:{'available':False,'path':None} for n in ['rg','jq','git','php','composer','docker']},'agent_map_index':{'present':False,'path':'.agent-loop/map/index.json','age_seconds':None}}
  cache.write_text(json.dumps(payload));tool=root/'tools/slop-scan/vendor/bin/slop-scan.php';tool.parent.mkdir(parents=True);tool.write_text('<?php\n');tool.chmod(0o755)
  p=run([]);report=json.loads(cache.read_text());check('old cache missing external tools re-probed and installed exact project path exposed',p.returncode==0 and 'cache: refreshed' in p.stdout and report['tools'].get('slop-scan',{}).get('path')==str(tool) and 'itp-context' in report['tools'],p)
  p=run([]);check('complete fresh cache reused',p.returncode==0 and 'cache: reused' in p.stdout,p)
  p=run(['--refresh']);check('explicit refresh forces probe',p.returncode==0 and 'cache: refreshed' in p.stdout,p)
  cache.write_text(json.dumps({**payload,'generated_at':'2000-01-01T00:00:00+00:00'}));p=run([]);check('expired cache refreshed',p.returncode==0 and 'cache: refreshed' in p.stdout,p)
 else:
  target=t/'external Δ cache directory'/'selected tools.json';p=run(['--cache='+str(target)]);wrong=root/str(target).lstrip('/');check('absolute explicit cache exact destination without project-prefixed substitute',p.returncode==0 and target.is_file() and not wrong.exists(),p)
  p=run(['--cache',str(target)]);check('split absolute path reused exactly',p.returncode==0 and target.is_file() and 'cache: reused' in p.stdout,p)
  p=run(['--cache=local Δ cache/tools.json']);check('relative cache remains project relative',p.returncode==0 and (root/'local Δ cache/tools.json').is_file(),p)
  p=run([]);check('default cache remains owner layout',p.returncode==0 and (root/'.agent-loop/tool-inventory.json').is_file(),p)
result={'repository':str(repo),'round':roundno,'checks':checks,'passed':all(x['passed'] for x in checks),'independent_black_box':True,'implementation_text_not_used_as_oracle':True}
print(json.dumps(result,indent=2));sys.exit(0 if result['passed'] else 1)
