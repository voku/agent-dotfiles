import pathlib,json,subprocess,hashlib
p=pathlib.Path('/workspace/scratch/quality-cycle-17');f=p/'round2-grades.json';g=json.loads(f.read_text());summary=[]
for row in g['consumers']:
 x=row['consumer'];repo=p/x;r=json.loads((p/f'{x}-result.json').read_text());sha=hashlib.sha256((repo/'src/Init/InitToolsCommand.php').read_bytes()).hexdigest();assert sha==row['source_sha256']
 row['source_sha256_unchanged_since_independent_oracle']=True;row['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert row['head']==r['commit'];row['consumer_result']=r;row['worktree_status']=subprocess.check_output(['git','status','--short'],cwd=repo,text=True)
 traces=[json.loads(z) for z in (p/f'{x}-trace.jsonl').read_text().splitlines()];last=[t for t in traces if 'finish' in t['argv']][-1];row['last_finish_observed']={'exit':last['exit'],'json':json.loads(last['stdout'])};assert last['exit']==0;row['canonical_finish_exit']=0;row['ci_status']='actual full composer ci exit0; independent code oracle pass; canonical finish complete'
 fid=r.get('learning_finding') or pathlib.Path(r['evidence']['finding']).stem;finding=repo/'.agent-loop/learning/findings/validated'/f'{fid}.json';row['owner_validated_finding']={'path':str(finding),'sha256':hashlib.sha256(finding.read_bytes()).hexdigest(),'record':json.loads(finding.read_text())};row['final_trace_count']=len(traces)
 repeats=[];seen={}
 for i,t in enumerate(traces):
  args=t['argv'];query=args and (args[0] in ['rg','sed','cat'] or any(v in ['agent_read','agent_search','read','search'] for v in args))
  if query:
   key=(tuple(args),t['cwd'])
   if key in seen:repeats.append({'index':i,'previous':seen[key],'argv':args})
   seen[key]=i
 row['strict_identical_search_or_read_repeats']=repeats
 summary.append({'consumer':x,'commit':row['head'],'wall_seconds':r['wall_seconds'],'correctness':'4/4','scope':'pass','governed_closeout':'complete','source_sha256_unchanged':True,'model_tokens':None,'final_identical_query_repeats':len(repeats),'learning_finding':fid})
f.write_text(json.dumps(g,indent=2)+'\n')
first=json.loads((p/'round1-grades.json').read_text());firstr=[]
for row in first['consumers']:
 x=row['consumer'];r=json.loads((p/f'{x}-result.json').read_text());row['consumer_result_final']=r;row['governed_full_cycle_eligible']=False;row['governance_exclusion']='Learning custom taskID pattern blocked canonical closeout; PHP correctness and scope independently pass.'
 wall=r.get('wall_seconds')
 if wall is None:wall=(r.get('end_monotonic_ns',r.get('ended_monotonic_ns'))-r.get('start_monotonic_ns',r.get('started_monotonic_ns')))/1e9
 firstr.append({'consumer':x,'correctness':'4/4','scope':'pass','governed_closeout':'excluded incomplete','wall_seconds':wall,'model_tokens':None})
(p/'round1-grades.json').write_text(json.dumps(first,indent=2)+'\n')
s={'round1':firstr,'heldout_round2':summary,'judgment':g['cross_round_judgment'],'governance_boundary':'First round correct PHP repairs excluded from governed fullcycle demonstration. Heldout tasks completed on unchanged frozen Loop using existing owner APIs; separate Learning PR165 targets documented custompattern defect after trial. C2 needed public typed FindingCreator to bind Session lineage; alias-generated manual candidate retained and rejected, not rewritten. Success with disclosed ownerAPI fallback does not prove CLI alias fixed.','runtime_pin_boundary':'Builder runtime unchanged; dotfiles runtime unchanged between pinned1e6 and793 preflightcandidate. No causal speed/toolquality improvement inferred from harnessfix/taskdifference.'}
(p/'cross-round-independent-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({'round1':firstr,'heldout':summary},indent=2))
