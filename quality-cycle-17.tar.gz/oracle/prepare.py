import pathlib,subprocess,json,os
base=pathlib.Path('/workspace/scratch/dotfiles-experiments/loop-current'); out=pathlib.Path('/workspace/scratch/quality-cycle-17/php-oracle')
source='fad403a209d7d9f4438bf7036ce962780f44938c'
mutations=[("foreach ([...self::KNOWN_TOOLS, ...array_keys(self::EXTERNAL_EVIDENCE_TOOLS)] as $tool)","foreach (self::KNOWN_TOOLS as $tool)"),("        if (str_starts_with($path, '/')) {\n            return $path;\n        }\n\n",'')]
rows=[]
for i,(old,new) in enumerate(mutations,1):
 p=out/f'round{i}-private-seed'; subprocess.run(['git','clone','--no-hardlinks',str(base),str(p)],check=True,capture_output=True)
 subprocess.run(['git','checkout','--detach',source],cwd=p,check=True,capture_output=True)
 f=p/'src/Init/InitToolsCommand.php'; s=f.read_text();assert s.count(old)==1; f.write_text(s.replace(old,new))
 subprocess.run(['git','add','src/Init/InitToolsCommand.php'],cwd=p,check=True)
 subprocess.run(['git','-c','user.name=Evaluation fixture','-c','user.email=fixture@example.invalid','commit','-m',f'Evaluation seed {i}: bounded tool inventory regression'],cwd=p,check=True,capture_output=True)
 sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip(); ref=f'refs/evaluation/round{i}'
 subprocess.run(['git','update-ref',ref,sha],cwd=p,check=True)
 subprocess.run(['git','bundle','create',str(out/f'round{i}-seed.bundle'),ref],cwd=p,check=True,capture_output=True)
 (out/f'round{i}-seed.patch').write_bytes(subprocess.check_output(['git','diff',source,sha],cwd=p))
 rows.append({'round':i,'source':source,'seed':sha,'ref':ref,'seeded_not_production':True,'scope':['src/Init/InitToolsCommand.php','tests/InitToolsCommandTest.php']})
(out/'source.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'public-task1.txt').write_text('Repair the tool-inventory CLI so a fresh cache created by an older version cannot hide newly supported external evidence tools. A project with all six native-tool entries cached, but no external-tool entries, currently reports the cache as reused and omits a project-installed slop-scan. It must re-probe and expose the installed external tool, while a complete fresh cache must still be reused and --refresh must still work. Add a focused regression test and run the existing tool-inventory tests. Keep project-local tool precedence and optional-tool semantics unchanged. This is a privately seeded regression in real production PHP code, not a claim about a production defect.\n')
(out/'public-task2.txt').write_text('Repair the tool-inventory CLI handling of an explicit absolute --cache path. When a caller selects a cache outside the project, the CLI currently writes under the project instead of at that exact selected path. Absolute paths must be respected, including spaces and Unicode; relative cache paths must remain project-relative, and the default owner-defined location must remain unchanged. Add focused regression coverage and run the existing tool-inventory tests. This is a distinct privately seeded regression in real production PHP code, not a claim about a production defect.\n')
