<?php
require "/workspace/scratch/quality-cycle-17/php-oracle/round2-private-seed/src/Init/InitToolsCommand.php";
require "/workspace/scratch/dotfiles-experiments/loop-current/vendor/autoload.php";
