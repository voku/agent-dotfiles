<?php

declare(strict_types=1);

namespace voku\AgentLearning\Tests;

use PHPUnit\Framework\TestCase;
use voku\AgentLearning\EvidenceValidator;
use voku\AgentLearning\FindingRepository;
use voku\AgentLearning\FindingStatus;
use voku\AgentLearning\FindingValidator;
use voku\AgentLearning\LearningClassification;
use voku\AgentLearning\RecordIdGenerator;

final class FindingCreateCliTest extends TestCase
{
    public function testCreatesValidatedFindingAndMissingTargetDirectory(): void
    {
        $root = $this->createFreshLearningRoot();
        self::assertDirectoryDoesNotExist($root . '/findings/validated');

        [$exitCode, $output] = $this->runFindingCreate($root, [
            '--task', 'PROJECT-27',
            '--session', 'session_PROJECT-27',
            '--by', 'agent',
            '--scope', 'src/',
            '--scope', 'tests/',
            '--observation', 'Consumers had to hand-write the first Finding record.',
            '--hypothesis', 'Finding creation belongs behind the package owner boundary.',
            '--conclusion', 'The package owner must create validated Finding records.',
            '--confidence', 'high',
            '--sensitivity', 'public',
            '--evidence-json', $this->evidenceJson(),
        ]);

        self::assertSame(0, $exitCode, $output);
        /** @var array{id: string, path: string} $result */
        $result = json_decode($output, true, 512, JSON_THROW_ON_ERROR);
        self::assertMatchesRegularExpression(RecordIdGenerator::pattern('finding'), $result['id']);
        self::assertSame($root . '/findings/validated/' . $result['id'] . '.json', $result['path']);
        self::assertFileExists($result['path']);

        $finding = (new FindingValidator())->validateFile($result['path']);
        self::assertSame(FindingStatus::VALIDATED, $finding->status);
        self::assertSame('validated', $finding->validationStatus);
        self::assertSame('The package owner must create validated Finding records.', $finding->validatedConclusion);
        self::assertSame(['src/', 'tests/'], $finding->scope);
        self::assertArrayHasKey($finding->id, (new FindingRepository())->loadValidated($root));
        $this->assertNoTemporaryFindingFiles($root);
    }

    public function testCapturesUnverifiedHumanReportWithoutSessionOrEvidenceJson(): void
    {
        $root = $this->createFreshLearningRoot();

        [$exitCode, $output] = $this->runFindingCapture($root, [
            '--task', 'PROJECT-28',
            '--by', 'product-owner',
            '--scope', 'docs/',
            '--observation', 'The onboarding screen does not explain the required approval step.',
            '--hypothesis', 'A missing explanation leaves contributors unable to complete the intended workflow.',
            '--evidence', 'Observed during a product acceptance review with a representative account.',
        ]);

        self::assertSame(0, $exitCode, $output);
        /** @var array{id: string, path: string, status: string, validation_status: string, classification: ?string, available_actions: list<array{id: non-empty-string, requires: list<non-empty-string>}>} $result */
        $result = json_decode($output, true, 512, JSON_THROW_ON_ERROR);
        self::assertMatchesRegularExpression(RecordIdGenerator::pattern('finding'), $result['id']);
        self::assertSame($root . '/findings/candidate/' . $result['id'] . '.json', $result['path']);
        self::assertSame('candidate', $result['status']);
        self::assertSame('unverified', $result['validation_status']);
        self::assertNull($result['classification']);
        self::assertSame([
            ['id' => 'review_validate', 'requires' => ['actor', 'conclusion']],
            ['id' => 'review_invalidate', 'requires' => ['actor']],
            ['id' => 'review_reject', 'requires' => ['actor']],
        ], $result['available_actions']);

        $finding = (new FindingValidator())->validateFile($result['path']);
        self::assertSame(FindingStatus::CANDIDATE, $finding->status);
        self::assertSame('unverified', $finding->validationStatus);
        self::assertNull($finding->validatedConclusion);
        self::assertSame('product-owner', $finding->createdBy);
        self::assertSame('manual:' . $finding->id, $finding->session);
        self::assertSame('low', $finding->confidence);
        self::assertSame('internal', $finding->sensitivity);
        self::assertSame([['type' => 'human_report', 'summary' => 'Observed during a product acceptance review with a representative account.']], $finding->evidence);
        self::assertArrayHasKey($finding->id, (new FindingRepository())->loadAll($root));
        $this->assertNoTemporaryFindingFiles($root);
    }

    public function testCaptureRejectsIncompleteHumanReportBeforeWritingCandidate(): void
    {
        $root = $this->createFreshLearningRoot();

        [$exitCode, $output] = $this->runFindingCapture($root, [
            '--task', 'PROJECT-28',
            '--by', 'tester',
            '--observation', 'A plain report still needs its own hypothesis.',
        ]);

        self::assertSame(1, $exitCode, $output);
        self::assertStringContainsString('finding-capture missing required options: --hypothesis, --evidence', $output);
        self::assertDirectoryDoesNotExist($root . '/findings/candidate');
    }

    public function testReviewerMustSupplyConclusionBeforeCapturedFindingBecomesValidated(): void
    {
        $root = $this->createFreshLearningRoot();
        $id = 'finding.2026-09-19.abc123';

        [$captureExitCode, $captureOutput] = $this->runFindingCapture($root, [
            '--id', $id,
            '--task', 'PROJECT-28',
            '--by', 'developer',
            '--observation', 'The command output omits the validation boundary.',
            '--hypothesis', 'Making the boundary explicit prevents premature policy claims.',
            '--evidence', 'Observed in a documented command walkthrough.',
        ]);

        self::assertSame(0, $captureExitCode, $captureOutput);

        [$missingConclusionExitCode, $missingConclusionOutput] = $this->runFindingCommand($root, 'finding-transition', [
            $id,
            'validated',
            '--by', 'reviewer',
        ]);

        self::assertSame(1, $missingConclusionExitCode, $missingConclusionOutput);
        self::assertStringContainsString('requires an explicit conclusion', $missingConclusionOutput);
        self::assertFileExists($root . '/findings/candidate/' . $id . '.json');

        [$transitionExitCode, $transitionOutput] = $this->runFindingCommand($root, 'finding-transition', [
            $id,
            'validated',
            '--by', 'reviewer',
            '--conclusion', 'The boundary is reproducible and the candidate is ready for learning triage.',
        ]);

        self::assertSame(0, $transitionExitCode, $transitionOutput);
        $finding = (new FindingValidator())->validateFile($root . '/findings/validated/' . $id . '.json');
        self::assertSame(FindingStatus::VALIDATED, $finding->status);
        self::assertSame('validated', $finding->validationStatus);
        self::assertSame('The boundary is reproducible and the candidate is ready for learning triage.', $finding->validatedConclusion);
        self::assertSame('reviewer', $finding->raw['validated_by']);
    }


    public function testHumanIntakeCliIsSelfDescribingAcrossCaptureReviewAndClassification(): void
    {
        $root = $this->createFreshLearningRoot();
        $id = 'finding.2026-09-19.131001';

        [$captureExit, $captureOutput] = $this->runFindingCapture($root, [
            '--id', $id,
            '--task', 'PROJECT-131',
            '--by', 'tester',
            '--observation', 'Successful Finding commands do not expose one coherent continuation envelope.',
            '--hypothesis', 'The Learning owner should project the current intake interaction after each mutation.',
            '--evidence', 'Reproduced through the public CLI.',
        ]);
        self::assertSame(0, $captureExit, $captureOutput);

        /** @var array<string, mixed> $capture */
        $capture = json_decode($captureOutput, true, 512, JSON_THROW_ON_ERROR);
        self::assertSame('candidate', $capture['status']);
        self::assertSame('unverified', $capture['validation_status']);
        self::assertNull($capture['classification']);
        self::assertSame('review_validate', $capture['available_actions'][0]['id'] ?? null);

        [$reviewExit, $reviewOutput] = $this->runFindingCommand($root, 'finding-transition', [
            $id,
            'validated',
            '--by', 'reviewer',
            '--conclusion', 'The inconsistent machine continuation is reproduced and ready for explicit learning triage.',
        ]);
        self::assertSame(0, $reviewExit, $reviewOutput);

        /** @var array<string, mixed> $review */
        $review = json_decode($reviewOutput, true, 512, JSON_THROW_ON_ERROR);
        self::assertSame($id, $review['id']);
        self::assertSame('validated', $review['status']);
        self::assertSame('validated', $review['validation_status']);
        self::assertNull($review['classification']);
        self::assertSame([
            ['id' => 'classify', 'requires' => ['classification']],
        ], $review['available_actions']);

        [$classifyExit, $classifyOutput] = $this->runFindingCommand($root, 'finding-classify', [
            $id,
            LearningClassification::IGNORE->value,
        ]);
        self::assertSame(0, $classifyExit, $classifyOutput);

        /** @var array<string, mixed> $classified */
        $classified = json_decode($classifyOutput, true, 512, JSON_THROW_ON_ERROR);
        self::assertSame($id, $classified['id']);
        self::assertSame('validated', $classified['status']);
        self::assertSame('validated', $classified['validation_status']);
        self::assertSame(LearningClassification::IGNORE->value, $classified['classification']);
        self::assertSame([], $classified['available_actions']);
    }

    public function testReportsAllMissingRequiredOptionsInOneFailure(): void
    {
        $root = $this->createFreshLearningRoot();

        [$exitCode, $output] = $this->runFindingCreate($root, [
            '--task', 'PROJECT-27',
            '--session', 'session_PROJECT-27',
        ]);

        self::assertSame(1, $exitCode, $output);
        self::assertStringContainsString(
            'finding-create missing required options: --by, --observation, --hypothesis, --conclusion, --confidence, --sensitivity, --evidence-json',
            $output,
        );
        self::assertDirectoryDoesNotExist($root . '/findings/validated');
    }

    public function testInvalidFindingLeavesNoPartialTargetDirectory(): void
    {
        $root = $this->createFreshLearningRoot();

        [$exitCode, $output] = $this->runFindingCreate($root, [
            '--task', 'PROJECT-27',
            '--session', 'session_PROJECT-27',
            '--by', 'agent',
            '--observation', 'Evidence is required.',
            '--hypothesis', 'Invalid input must fail before publication.',
            '--conclusion', 'No target file may survive failed validation.',
            '--confidence', 'high',
            '--sensitivity', 'public',
        ]);

        self::assertSame(1, $exitCode, $output);
        self::assertStringContainsString('finding-create missing required options: --evidence-json', $output);
        self::assertDirectoryDoesNotExist($root . '/findings/validated');
    }

    public function testUnsupportedEvidenceTypeListsAcceptedVocabulary(): void
    {
        $root = $this->createFreshLearningRoot();

        [$exitCode, $output] = $this->runFindingCreate($root, [
            '--task', 'PROJECT-27',
            '--session', 'session_PROJECT-27',
            '--by', 'agent',
            '--observation', 'Evidence vocabulary should be discoverable from the failed request.',
            '--hypothesis', 'The validator owns the accepted evidence type vocabulary.',
            '--conclusion', 'Unsupported evidence types should report the accepted owner vocabulary.',
            '--confidence', 'high',
            '--sensitivity', 'public',
            '--evidence-json', json_encode(
                ['type' => 'unsupported_example', 'summary' => 'Invalid on purpose.'],
                JSON_THROW_ON_ERROR,
            ),
        ]);

        self::assertSame(1, $exitCode, $output);
        self::assertStringContainsString('unsupported evidence type at index 0', $output);
        self::assertStringContainsString(
            'accepted types: ' . implode(', ', EvidenceValidator::supportedTypes()),
            $output,
        );
        self::assertDirectoryDoesNotExist($root . '/findings/validated');
    }

    public function testCustomTaskPatternIsUsedDuringCreation(): void
    {
        $root = $this->createFreshLearningRoot();

        [$exitCode, $output] = $this->runFindingCreate($root, [
            '--task', 'custom:27',
            '--task-id-pattern', '/^custom:\\d+$/',
            '--session', 'session_custom_27',
            '--by', 'agent',
            '--observation', 'The consumer uses a custom task identifier.',
            '--hypothesis', 'Creation must use the same task-id override as validation.',
            '--conclusion', 'The owner creation path honors the configured task-id pattern.',
            '--confidence', 'medium',
            '--sensitivity', 'public',
            '--evidence-json', $this->evidenceJson(),
        ]);

        self::assertSame(0, $exitCode, $output);
        /** @var array{id: string, path: string} $result */
        $result = json_decode($output, true, 512, JSON_THROW_ON_ERROR);
        self::assertFileExists($result['path']);
    }

    public function testCustomTaskPatternSurvivesTransitionAndSameStatusResponse(): void
    {
        foreach (['PHP17-B1' => '/^PHP17-[ABC][12]$/', 'custom:27' => '/^custom:\\d+$/'] as $task => $pattern) {
            $root = $this->createFreshLearningRoot();
            [$captureExit, $captureOutput] = $this->runFindingCapture($root, [
                '--task', $task, '--task-id-pattern', $pattern, '--by', 'reviewer',
                '--observation', 'Custom task identity passed capture validation.',
                '--hypothesis', 'Transition should preserve the explicit identity contract.',
                '--evidence', 'Independent capture and transition CLI reproduction.',
            ]);
            self::assertSame(0, $captureExit, $captureOutput);
            /** @var array{id: string, path: string} $captured */
            $captured = json_decode($captureOutput, true, 512, JSON_THROW_ON_ERROR);
            $before = file_get_contents($captured['path']);
            self::assertIsString($before);
            [$rejectedExit] = $this->runFindingCommand($root, 'finding-transition', [
                $captured['id'], 'validated', '--by', 'reviewer',
                '--task-id-pattern', '/^OTHER-\\d+$/', '--conclusion', 'Observed behavior verified.',
            ]);
            self::assertSame(1, $rejectedExit);
            self::assertSame($before, file_get_contents($captured['path']));
            self::assertFileDoesNotExist($root . '/findings/validated/' . $captured['id'] . '.json');

            $arguments = [$captured['id'], 'validated', '--by', 'reviewer',
                '--task-id-pattern', $pattern, '--conclusion', 'Observed behavior verified.'];
            [$transitionExit, $transitionOutput] = $this->runFindingCommand($root, 'finding-transition', $arguments);
            self::assertSame(0, $transitionExit, $transitionOutput);
            /** @var array{status: string, validation_status: string} $transitioned */
            $transitioned = json_decode($transitionOutput, true, 512, JSON_THROW_ON_ERROR);
            self::assertSame('validated', $transitioned['status']);
            self::assertSame('validated', $transitioned['validation_status']);
            self::assertFileDoesNotExist($captured['path']);
            $validatedPath = $root . '/findings/validated/' . $captured['id'] . '.json';
            $validatedBytes = file_get_contents($validatedPath);
            self::assertIsString($validatedBytes);
            [$noOpExit, $noOpOutput] = $this->runFindingCommand($root, 'finding-transition', $arguments);
            self::assertSame(0, $noOpExit, $noOpOutput);
            self::assertSame($validatedBytes, file_get_contents($validatedPath));
        }
    }

    public function testExplicitDuplicateIdDoesNotOverwriteExistingFinding(): void
    {
        $root = $this->createFreshLearningRoot();
        $id = 'finding.2026-08-17.abc123';
        $arguments = $this->validArguments($id);

        [$firstExitCode, $firstOutput] = $this->runFindingCreate($root, $arguments);
        self::assertSame(0, $firstExitCode, $firstOutput);
        /** @var array{id: string, path: string} $firstResult */
        $firstResult = json_decode($firstOutput, true, 512, JSON_THROW_ON_ERROR);
        $before = file_get_contents($firstResult['path']);
        self::assertIsString($before);

        [$secondExitCode, $secondOutput] = $this->runFindingCreate($root, $arguments);
        self::assertSame(1, $secondExitCode, $secondOutput);
        self::assertStringContainsString('duplicate finding ID', $secondOutput);
        self::assertSame($before, file_get_contents($firstResult['path']));
        $this->assertNoTemporaryFindingFiles($root);
    }

    public function testPublicationDoesNotReplaceUnexpectedExistingTarget(): void
    {
        $root = $this->createFreshLearningRoot();
        $directory = $root . '/findings/validated';
        self::assertTrue(mkdir($directory, 0777, true));
        $id = 'finding.2026-08-17.def456';
        $path = $directory . '/' . $id . '.json';
        self::assertSame(0, file_put_contents($path, ''));

        [$exitCode, $output] = $this->runFindingCreate($root, $this->validArguments($id));

        self::assertSame(1, $exitCode, $output);
        self::assertStringContainsString('finding file already exists', $output);
        self::assertSame('', file_get_contents($path));
        $this->assertNoTemporaryFindingFiles($root);
    }

    private function createFreshLearningRoot(): string
    {
        $root = sys_get_temp_dir() . '/agent-learning-finding-create-' . bin2hex(random_bytes(8)) . '/.agent-loop/learning';
        if (!mkdir($root . '/findings', 0777, true) && !is_dir($root . '/findings')) {
            self::fail('Cannot create temporary Learning root.');
        }

        return $root;
    }

    private function evidenceJson(): string
    {
        return json_encode(
            ['type' => 'manual_verification', 'summary' => 'Reproduced in consumer dogfood.'],
            JSON_THROW_ON_ERROR,
        );
    }

    /**
     * @return list<string>
     */
    private function validArguments(string $id): array
    {
        return [
            '--id', $id,
            '--task', 'PROJECT-27',
            '--session', 'session_PROJECT-27',
            '--by', 'agent',
            '--observation', 'The first record must remain unchanged.',
            '--hypothesis', 'Explicit IDs must never permit overwriting evidence.',
            '--conclusion', 'Duplicate Finding IDs are rejected before publication.',
            '--confidence', 'high',
            '--sensitivity', 'public',
            '--evidence-json', $this->evidenceJson(),
        ];
    }

    private function assertNoTemporaryFindingFiles(string $root): void
    {
        $files = glob($root . '/findings/*/.finding.*.tmp.*');
        self::assertIsArray($files);
        self::assertSame([], $files);
    }

    /**
     * @param list<string> $arguments
     *
     * @return array{0: int, 1: string}
     */
    private function runFindingCreate(string $root, array $arguments): array
    {
        return $this->runFindingCommand($root, 'finding-create', $arguments);
    }

    /**
     * @param list<string> $arguments
     *
     * @return array{0: int, 1: string}
     */
    private function runFindingCapture(string $root, array $arguments): array
    {
        return $this->runFindingCommand($root, 'finding-capture', $arguments);
    }

    /**
     * @param list<string> $arguments
     *
     * @return array{0: int, 1: string}
     */
    private function runFindingCommand(string $root, string $findingCommand, array $arguments): array
    {
        $command = [
            PHP_BINARY,
            __DIR__ . '/../bin/agent-learning',
            $findingCommand,
            '--root',
            $root,
            ...$arguments,
        ];
        $escaped = array_map(escapeshellarg(...), $command);
        $output = [];
        $exitCode = 0;
        exec(implode(' ', $escaped) . ' 2>&1', $output, $exitCode);

        return [$exitCode, implode("\n", $output)];
    }
}
