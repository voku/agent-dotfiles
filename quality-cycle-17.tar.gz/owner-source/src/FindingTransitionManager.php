<?php

declare(strict_types=1);

namespace voku\AgentLearning;

use DateTimeImmutable;
use DateTimeInterface;

/**
 * Governs state transitions for Findings.
 */
final class FindingTransitionManager
{
    private readonly FindingLifecycle $lifecycle;

    public function __construct()
    {
        $this->lifecycle = new FindingLifecycle();
    }

    /**
     * Resolve the absolute path of a finding file.
     *
     * @param string $findingId
     * @param string $root
     * @return string
     * @throws ValidationException
     */
    public function resolveFindingPath(string $findingId, string $root): string
    {
        foreach ($this->lifecycle->directories() as $dir) {
            $path = $root . '/findings/' . $dir . '/' . $findingId . '.json';
            if (is_file($path)) {
                return $path;
            }
        }
        throw new ValidationException('', null, $findingId, 'finding file not found: ' . $findingId);
    }

    /**
     * Transition a finding to a new status.
     *
     * @param string        $root
     * @param string        $findingId
     * @param FindingStatus $targetStatus
     * @param string        $actor
     * @throws ValidationException
     */
    public function transition(
        string $root,
        string $findingId,
        FindingStatus $targetStatus,
        string $actor,
        ?string $validatedConclusion = null,
        ?string $reason = null,
        ?string $taskIdPattern = null,
    ): void
    {
        if (trim($actor) === '') {
            throw new ValidationException('', null, $findingId, 'actor name must be explicit');
        }

        $currentPath = $this->resolveFindingPath($findingId, $root);
        $originalContent = file_get_contents($currentPath);
        if ($originalContent === false) {
            throw new ValidationException($currentPath, null, $findingId, 'cannot read finding file');
        }

        $finding = (new FindingParser())->parseFile($currentPath);
        $currentStatus = $finding->status;

        if ($currentStatus === $targetStatus) {
            // Already in target state, no-op
            return;
        }

        if (!in_array($targetStatus, $this->lifecycle->allowedTransitions($currentStatus), true)) {
            throw new ValidationException($currentPath, null, $findingId, sprintf('transition from %s to %s is not allowed', $currentStatus->value, $targetStatus->value));
        }

        // Prepare updated data
        $data = $finding->raw;
        $data['status'] = $targetStatus->value;
        if ($targetStatus === FindingStatus::VALIDATED || $targetStatus === FindingStatus::CONSOLIDATED) {
            $conclusion = $validatedConclusion ?? $finding->validatedConclusion;
            if ($conclusion === null || trim($conclusion) === '') {
                throw new ValidationException($currentPath, null, $findingId, 'validating a candidate requires an explicit conclusion');
            }
            $data['validated_conclusion'] = $conclusion;
            $data['validation_status'] = 'validated';
            // Consolidating records that the finding was handled; it must not rewrite who validated it or when.
            if ($targetStatus === FindingStatus::VALIDATED || !isset($data['validated_by'], $data['validated_at'])) {
                $data['validated_by'] = $actor;
                $data['validated_at'] = (new DateTimeImmutable('now'))->format(DateTimeInterface::ATOM);
            }
        } elseif ($targetStatus === FindingStatus::INVALIDATED) {
            $data['validation_status'] = 'invalidated';
        } elseif ($targetStatus === FindingStatus::REJECTED) {
            if ($finding->validationStatus === 'unverified') {
                $data['validation_status'] = 'invalidated';
            }
        }

        // Why a finding left the backlog (archived as resolved, superseded by another, ...) otherwise lives
        // only in a commit message; keep it with the record, together with who decided and when.
        if ($reason !== null && trim($reason) !== '') {
            $data['status_reason'] = trim($reason);
            $data['status_changed_by'] = $actor;
            $data['status_changed_at'] = (new DateTimeImmutable('now'))->format(DateTimeInterface::ATOM);
        } else {
            unset($data['status_reason'], $data['status_changed_by'], $data['status_changed_at']);
        }

        $targetDir = $root . '/findings/' . $this->lifecycle->directoryFor($targetStatus);
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $targetPath = $targetDir . '/' . $findingId . '.json';

        $updatedContent = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

        // Transaction/atomic block
        try {
            file_put_contents($currentPath, $updatedContent);
            if ($currentPath !== $targetPath) {
                if (is_file($targetPath)) {
                    throw new ValidationException($targetPath, null, $findingId, 'target file already exists');
                }
                if (!rename($currentPath, $targetPath)) {
                    throw new ValidationException($currentPath, null, $findingId, 'failed to move finding file to target directory');
                }
            }

            // Run repository validation
            $this->validateRepository($root, $taskIdPattern);
        } catch (\Throwable $e) {
            // Rollback
            if (is_file($targetPath) && $targetPath !== $currentPath) {
                rename($targetPath, $currentPath);
            }
            file_put_contents($currentPath, $originalContent);
            throw new ValidationException($currentPath, null, $findingId, 'finding transition failed and was rolled back: ' . $e->getMessage());
        }
    }

    private function validateRepository(string $root, ?string $taskIdPattern): void
    {
        // Re-validate all findings, proposals, and history
        $findingsById = [];
        $findingValidator = $taskIdPattern === null
            ? new FindingValidator()
            : new FindingValidator(taskIdPattern: $taskIdPattern);
        foreach ($this->lifecycle->findingFiles($root) as $file) {
            $finding = $findingValidator->validateFile($file);
            $this->lifecycle->assertPathMatchesStatus($finding, $file, $root);
            if (isset($findingsById[$finding->id])) {
                throw new ValidationException($file, null, $finding->id, 'duplicate finding ID');
            }
            $findingsById[$finding->id] = $finding;
        }

        $proposalsById = (new ProposalRepository())->loadAll($root, $findingsById);
        (new DecisionHistoryValidator())->validateHistory($root, $proposalsById);
        (new OutcomeRepository())->loadAll($root, $proposalsById);
    }
}
