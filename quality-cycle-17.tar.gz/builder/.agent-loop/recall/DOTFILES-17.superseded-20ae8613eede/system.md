# L2 Meta-Prompt Briefing for Task: DOTFILES-17
> Recall bundle SHA-256: e67c93cfdb1c8a0f2983601b24d62032cfe434ed29c011884957b62bbb0546f1

## Task Description
Review, correct if needed, integrate and independently validate PR17 real-PHP evidence preflight without claiming agent productivity.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tools/real_php_preflight.py`
- File/path: `.github/workflows/real-php-preflight.yml`
- Scope: `tools/real_php_preflight.py`
- Scope: `.github/workflows/real-php-preflight.yml`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Exact head reviewed independently; meaningful evidence parity and failure receipts; CI before and after reviewed integration; bounded Dream incorporates earlier dogfood.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No releases, default activation, governance bypass or runtime tool replacement.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2