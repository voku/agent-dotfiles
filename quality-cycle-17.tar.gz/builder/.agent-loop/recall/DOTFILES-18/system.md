# L2 Meta-Prompt Briefing for Task: DOTFILES-18
> Recall bundle SHA-256: 2fafe7082024008b19d3bda9f95fad063628640b73d2bc15b6a34aba704d00bf

## Task Description
Run and independently grade fresh guided native/CLI/BashZsh real-PHP maintenance trials, learn from quality and operational defects, repeatheldout, publish exact evidence and honest limits.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `docs/QUALITY_CYCLE_17.md`
- File/path: `README.md`
- Scope: `docs/QUALITY_CYCLE_17.md`
- Scope: `README.md`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Independentblackboxcorrectness, meaningful regressions, source/Contract scopes, actual gates, timing/retrieval/token availability, Dream with prior evidence and no false success; reviewed report and exact-headCI.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No releases, default activation, invented telemetry, active guidance auto-promotion or causal claim unsupported by trials.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### Omitted Project Capabilities
- **Omitted from runtime context**: 3
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 3