# L2 blind-spot analysis prompt for DOTFILES-17

## Presentation

Write the final review in language en. Translate explanatory headings and prose; preserve exact source text, identifiers, paths, citations, and required machine-readable status tokens.

## First-draft falsification lens

Treat the current implementation as a first draft, even if produced by you or paired with a confident rationale.

Review for falsification rather than confirmation. Try to prove concrete failures against requirements, acceptance criteria, constraints, non-goals, current source, tests, static analysis, and safe runtime evidence.

Acceptance criteria are required outcomes, not evidence they are satisfied. Prior reasoning, model confidence, reviewer consensus, prompt construction, and unexecuted commands are not verification.

Treat every LLM-produced statement as a candidate claim, not repository truth. Re-ground material claims against current authoritative artifacts or deterministic evidence before acting. A detailed patch is not evidence that the described classes, boundaries, bugs, or metrics actually exist. If model output conflicts with current authoritative artifacts, the artifacts win. Reproduce a finding before fixing it. Review findings are investigation candidates, not instructions to modify code.

Classify material conclusions as VERIFIED, INFERRED, ASSUMED, BLOCKED, or CONTRADICTED. If needed evidence is unavailable, keep it UNKNOWN or BLOCKED.

Separate required fixes from optional improvements. Do not manufacture findings. CLEAN is valid only after concrete attempts to falsify the implementation found no evidence-backed defect.

## Repo-first blind-spot lens

Act as an evidence-based technical blind-spot critic, not an approval authority.

Start repo-first. From supplied artifacts derive the intended outcome, constraints/non-goals, affected surfaces, assumptions, success/failure evidence, and material unknowns. Do not invent missing context.

Before new hypotheses, audit the supplied results, including your own prior conclusions. Treat them as candidate claims, not as evidence merely because you produced them. Re-ground material conclusions against primary artifacts; call out contradictions, omitted evidence, or unsupported causal attribution.

Run these bounded probes:
1. Pattern drift: compare at least two relevant in-repository examples before claiming a structural or ownership violation; otherwise report the evidence gap.
2. Intent erosion: check whether strict contracts, metadata, acceptance criteria, or non-goals were weakened merely to make the implementation fit.
3. Operational overconfidence: treat workflow, deployment, migration, generated metadata, and irreversible side effects as high-risk until evidenced.
4. False failure attribution: a missing dependency, generated asset, tool, or environment prerequisite is not a product defect until setup readiness is established.
5. Premature closure: verify that outcome, impacted surfaces, validation evidence, and close claim line up.

Across repository or package boundaries, trace the semantic owner, authoritative input, crossing artifact and retained identity to the consumer. Do not infer ownership from names or documentation alone.

Prefer the smallest discriminating dogfood experiment over speculation. Use only environments relevant to the hypothesis: source checkout; clean installed/released consumer or cross-package release set; repeat/resume; or no-change. For historical replay, freeze base state/input and do not leak the known fix; starting with the answer cannot prove discovery quality. No-change is a valid outcome.

For every material blind spot, classify the claim with the existing epistemic status and cite supporting or contradicting evidence. State the hidden assumption and concrete failure chain, earliest observable signal, smallest falsification probe, and why existing tests or gates did not expose it. Name a corrective action only after the claim becomes VERIFIED.

Use adversarial pre-mortem reasoning only as a hypothesis generator. A plausible failure story, model confidence, numeric score, imagined future, repeated self-refinement, or successful mechanism execution is not evidence. Do not manufacture findings to satisfy a quota.

If required repository or runtime evidence is unavailable, keep the claim UNKNOWN or BLOCKED and name the missing evidence. READY FOR HUMAN CLOSE is valid only when bounded probes found no evidence-backed blocker and supplied validation/close evidence is coherent.

You are reviewing recall-compiler workflow artifacts. Use only the artifacts below as evidence.
Expose missing validation, missing outcome logging, mismatched selected guidance, unsafe assumptions, and handoff gaps. Do not approve code or durable learning.

## Deterministic preflight findings

- [WARN] missing_validation_evidence: No validation evidence marker was found near recall artifacts.
  - Searched markers: PHPStan, phpstan, PHPUnit, phpunit, composer ci, composer test, tests passed
- [WARN] missing_outcome_closeout: No evidence shows recall outcome close-out was prepared or logged.
  - Searched markers: log-outcome, recall-log.draft.json, outcome=, "outcome"
- [WARN] missing_review_checkpoint: No blind-spot review checkpoint marker was found.
  - Searched markers: review blindspots, review-blindspots, L2 blind-spot

## Output contract

Return Markdown with headings: Summary, Critical blind spots, Evidence, Required next action, Close readiness.
For each material claim, give its epistemic status and the concrete artifact/evidence that supports or contradicts it.
Review findings are investigation candidates, not instructions to modify code.
Close readiness must be BLOCKED, NEEDS HUMAN REVIEW, or READY FOR HUMAN CLOSE.

## Artifacts

### .agent-loop/recall/DOTFILES-17/meta.json

```text
{
    "schema_version": "1.0",
    "compilation_id": "compilation.DOTFILES-17.2026-10-11-124301.d69d2354",
    "task_id": "DOTFILES-17",
    "task_files": [
        "tools/real_php_preflight.py",
        ".github/workflows/real-php-preflight.yml",
        "tests/test_real_php_preflight.py"
    ],
    "task_targets": [],
    "bundle_sha256": "fb1b785ab2168f3ee16f0a630a106692fc9a9b90be197b68cd02a2ce5228c087",
    "snapshot_sha256": "26b7dff51aae4c059bc70e920b3e7c0dccb398f74bf1167c32cd640b66cf989c",
    "blocked": false,
    "block_reason": null,
    "selected_guidance": [],
    "evaluated_guidance": [],
    "selected_constraints": [],
    "selected_rejections": [],
    "outcome_stats": [],
    "warnings": [],
    "output_hashes": {
        "system.md": "3a70e40173c1471702cc93a5e75f3509378600c467638e933ae878fdf0903ca4",
        "validation-plan.md": "ce11fb7ccea05800b4b93a6ab3892ed05ddc1ade9f902f4f615eecc25f27a98b",
        "recall.bundle.json": "918143b366f02656056e84ad50030d8318a431c5356870232006f4e0b7e1c16b",
        "facts.json": "5f0b99cef8342214d9de8837c1a12f46bce653369602fc0b1fc045e3952346c0",
        "selection-report.json": "baba934580c47fbeded9320cefc91bf51b7325fe37dd3c637f7cdc07753d1962"
    }
}
```

### .agent-loop/recall/DOTFILES-17/recall-log.draft.json

```text
{
    "applied": [],
    "applied_proposals": [],
    "comment": "Optional: add a guidance_outcomes row only for selected guidance (see evaluated_guidance) that actually changed, confirmed, or misled your work: {\"guidance_id\", \"guidance_type\", \"selected\": true, \"applied\", \"outcome\", \"comment\"} (outcome values: docs/guidance-events.md). A helpful row also needs attribution: {\"seen_before_decision\": did you read it before the decision it helped, \"also_prescribed_by\": the other sources that already prescribed that decision (task_prompt, contract, skill, template, constraint, repository_docs), or [] if nothing else did}. Leave the list empty when nothing notable happened; unjudged selections are neutral.",
    "compilation_id": "compilation.DOTFILES-17.2026-10-11-124301.d69d2354",
    "constraints_used": [],
    "created_at": "2026-10-11T12:43:01+00:00",
    "evaluated_guidance": [],
    "guidance_outcomes": [],
    "guidance_used": [],
    "harmful": [],
    "helpful": [],
    "id": "outcome.2026-10-11.000",
    "irrelevant": [],
    "operating_prompt_outcomes": [],
    "result": "successful",
    "schema_version": "1.0",
    "selected": [],
    "session": "sess_placeholder",
    "task_files": [
        "tools/real_php_preflight.py",
        ".github/workflows/real-php-preflight.yml",
        "tests/test_real_php_preflight.py"
    ],
    "task_id": "DOTFILES-17",
    "task_targets": []
}
```

### .agent-loop/recall/DOTFILES-17/system.md

```text
# L2 Meta-Prompt Briefing for Task: DOTFILES-17
> Recall bundle SHA-256: fb1b785ab2168f3ee16f0a630a106692fc9a9b90be197b68cd02a2ce5228c087

## Task Description
Finish PR17: correct independently demonstrated identity, workflow trigger and cleanup gaps, reviewed integration and fresh CI.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tools/real_php_preflight.py`
- File/path: `.github/workflows/real-php-preflight.yml`
- File/path: `tests/test_real_php_preflight.py`
- Scope: `tools/real_php_preflight.py`
- Scope: `.github/workflows/real-php-preflight.yml`
- Scope: `tests/test_real_php_preflight.py`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Reject wrong path/root/requested coordinates with valid bytes; installer changes rerun preflight; attempt safe uninstall independently of verification; reviewed CI and Dream include prior dogfood.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No releases, default activation or governance bypass.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### .github/workflows/real-php-preflight.yml
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The CI workflow file exists, but this provider does not parse it into executable task policy.
- **How**: Detected as a .github/workflows YAML file by the bounded project-capabilities provider.
- **Authority**: project_metadata
- **Use**: navigation_anchor_only
- **Source**: .github/workflows/real-php-preflight.yml

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2
```

### .agent-loop/recall/DOTFILES-17/validation-plan.md

````text
# Validation Plan

## Required Validation

### Task Validation

```bash
python3 -m unittest discover -s tests -v
```

```bash
python3 -m compileall -q agent_dotfiles bin tests tools
```

```bash
/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict
```
````

### .agent-loop/sessions/2026-10-11-dotfiles-17-r1-c92649f6/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r1-c92649f6/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r1-c92649f6/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r1-c92649f6/plan.md

```text
# Plan: DOTFILES-17

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r1-c92649f6/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-dotfiles-17-r1-c92649f6",
    "task_id": "DOTFILES-17",
    "status": "dropped",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T12:41:25+00:00",
    "base_commit": "4c6fdd2c61d31789451f6675e7f2cdf0f209124b",
    "created_at": "2026-10-11T12:41:25+00:00",
    "updated_at": "2026-10-11T12:43:01+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": "2026-10-11T12:43:01+00:00",
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r1-c92649f6/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r2-8e4a7651/assumptions.md

```text
# Assumptions

*Record what you had to assume because the repository did not answer it.*
*Each assumption stays an assumption until validated.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r2-8e4a7651/checkpoints/index.md

```text
# Checkpoints

*Resumable state. Each checkpoint records completed / open / blocked / next action.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r2-8e4a7651/decisions.md

```text
# Decisions

*Record observable decisions (context, decision, reason, validation).*
*Not a transcript of internal reasoning.*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r2-8e4a7651/plan.md

```text
# Plan: DOTFILES-17

## Goal

*What durable intent does this session serve? (mirror the task, do not redefine it)*

## Current checkpoint

*none yet*

## Next action

*the single next concrete step*

## Constraints

- *boundaries that must hold (scope, permissions, types, no unrelated migration)*

## Done when

- *the observable conditions that prove completion*
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r2-8e4a7651/session.json

```text
{
    "schema_version": "1.1",
    "id": "2026-10-11-dotfiles-17-r2-8e4a7651",
    "task_id": "DOTFILES-17",
    "status": "active",
    "claimed_by": "codex",
    "claimed_at": "2026-10-11T12:43:01+00:00",
    "base_commit": "4c6fdd2c61d31789451f6675e7f2cdf0f209124b",
    "created_at": "2026-10-11T12:43:01+00:00",
    "updated_at": "2026-10-11T12:43:01+00:00",
    "checkpoints": [],
    "ephemeral": false,
    "closed_at": null,
    "closed_reason": null
}
```

### .agent-loop/sessions/2026-10-11-dotfiles-17-r2-8e4a7651/validation.md

```text
# Validation

*Commands run and their status. Pending checks are honest, not hidden.*

## Validation evidence (Contract revision 2)

- Command: `python3 -m unittest discover -s tests -v`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T12:46:28+00:00
- Implementation snapshot: sha256:1091af15e7f91384e723ccb7afb5d9dc6c79e25940172862e44d457f4e6eb0ff
- Note: Executed on fixed current source: 92 Python and 9 Bashunit tests; compile exit0; scratch/quality-cycle-17/final logs.

## Validation evidence (Contract revision 2)

- Command: `python3 -m compileall -q agent_dotfiles bin tests tools`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T12:46:28+00:00
- Implementation snapshot: sha256:1091af15e7f91384e723ccb7afb5d9dc6c79e25940172862e44d457f4e6eb0ff
- Note: Executed on fixed current source: 92 Python and 9 Bashunit tests; compile exit0; scratch/quality-cycle-17/final logs.

## Validation evidence (Contract revision 2)

- Command: `/workspace/scratch/dotfiles-mission/bashunit/bashunit test tests/shell --strict`
- Status: passed
- Exit: 0
- Executed: 2026-10-11T12:46:28+00:00
- Implementation snapshot: sha256:1091af15e7f91384e723ccb7afb5d9dc6c79e25940172862e44d457f4e6eb0ff
- Note: Executed on fixed current source: 92 Python and 9 Bashunit tests; compile exit0; scratch/quality-cycle-17/final logs.
```
