# L2 Meta-Prompt Briefing for Task: DOTFILES-17
> Recall bundle SHA-256: fb1b785ab2168f3ee16f0a630a106692fc9a9b90be197b68cd02a2ce5228c087

## Task Description
Finish PR17: correct independently demonstrated identity, workflow trigger and cleanup gaps, reviewed integration and fresh CI.

## Declared Task Scope
These entries come from the task/Contract input. They are scope metadata, not evidence that a path exists. For an approved governed Contract, Recall is reporting the owner's approved scope rather than granting new authority.
- File/path: `tools/real_php_preflight.py`
- File/path: `.github/workflows/real-php-preflight.yml`
- File/path: `tests/test_real_php_preflight.py`
- Scope: `tools/real_php_preflight.py`
- Scope: `.github/workflows/real-php-preflight.yml`
- Scope: `tests/test_real_php_preflight.py`

## Acceptance Criteria
These are required task outcomes, not evidence that they are satisfied.
- Reject wrong path/root/requested coordinates with valid bytes; installer changes rerun preflight; attempt safe uninstall independently of verification; reviewed CI and Dream include prior dogfood.

## Evidence Discipline
Label every material conclusion honestly: **VERIFIED** (direct reproducible evidence), **INFERRED** (derived but not observed), **ASSUMED** (unverified premise), **BLOCKED** (required evidence unavailable), or **CONTRADICTED** (disproved by stronger evidence).
Do not present model confidence, agent consensus, or an unexecuted command as verification.

## Explicit Non-Goals
- No releases, default activation or governance bypass.

## Selected Active Guidance
*No active task-specific guidance matched this task's scope.*

## Context Explain Plan

These explanations describe **context provenance**, not the implementing agent's rationale. Use them to understand why Recall exposed a source, how that relevance was derived, what authority it carries, and what the source may be used for.
The **State** classifies the provenance claim shown here; `VERIFIED` does not mean every statement inside the referenced source is automatically correct.

### .github/workflows/real-php-preflight.yml
- **State**: VERIFIED
- **Selected**: yes
- **Why**: The CI workflow file exists, but this provider does not parse it into executable task policy.
- **How**: Detected as a .github/workflows YAML file by the bounded project-capabilities provider.
- **Authority**: project_metadata
- **Use**: navigation_anchor_only
- **Source**: .github/workflows/real-php-preflight.yml

### Omitted Project Capabilities
- **Omitted from runtime context**: 2
- **Reason**: not referenced by the current task contract or validation.
- **Durable detail**: complete per-capability provenance remains in `selection-report.json.context_explain`.
- **ci_anchor**: 2